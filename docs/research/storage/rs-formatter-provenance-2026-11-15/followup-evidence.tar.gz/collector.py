import csv
import difflib
import hashlib
import io
import json
import re
import subprocess
import tarfile
import urllib.request
import urllib.error
import base64
from pathlib import Path

ROOT = Path('/home/devin-worker/rs-provenance-followup')
REPO = Path('/home/devin-worker/repos/MSD-Linux-rs-provenance')
OUT = ROOT / 'evidence-v2'
OUT.mkdir(exist_ok=True)
manifest = []

def sha(data):
    return hashlib.sha256(data).hexdigest()

def save(path, data, **meta):
    if isinstance(data, str):
        data = data.encode()
    p = OUT / path
    p.parent.mkdir(parents=True, exist_ok=True)
    if p.exists():
        assert p.read_bytes() == data, f'changed evidence: {p}'
    else:
        p.write_bytes(data)
    manifest.append(dict(path=path, bytes=len(data), sha256=sha(data), **meta))
    return data

def git(repo, *args):
    return subprocess.check_output(['git', '-C', str(ROOT / repo), *args])

def source(repo, commit, path):
    data = git(repo, 'show', f'{commit}:{path}')
    base = {'cryptsetup': 'https://github.com/mbroz/cryptsetup',
            'libfec': 'https://github.com/quiet/libfec',
            'aosp-fec': 'https://android.googlesource.com/platform/external/fec',
            'aosp-extras': 'https://android.googlesource.com/platform/system/extras'}[repo]
    return save(f'{repo}/{commit}/{path}', data, commit=commit, upstream_path=path,
                url=f'{base}/+/{commit}/{path}' if 'googlesource' in base else f'{base}/blob/{commit}/{path}')

def fetch(url):
    cached = None
    if url.endswith('/fec-3.0.1.tar.bz2'):
        cached = OUT / 'karn/fec-3.0.1.tar.bz2'
    elif url.startswith('https://raw.githubusercontent.com/torvalds/linux/'):
        cached = OUT / 'linux' / url.split('/torvalds/linux/')[1]
    elif '/commits?path=' in url:
        cached = OUT / 'history/linux-encode.json'
    elif url.endswith('/commits/dc8f923eaee24061c557cb3221abeea3b95072c4'):
        cached = OUT / 'history/linux-license-commit.json'
    if cached and cached.exists():
        return cached.read_bytes()
    if cached:
        previous = ROOT / 'evidence' / cached.relative_to(OUT)
        if previous.exists():
            return previous.read_bytes()
    req = urllib.request.Request(url, headers={'User-Agent': 'MSD-RS-provenance-research'})
    try:
        with urllib.request.urlopen(req, timeout=90) as response:
            return response.read()
    except urllib.error.HTTPError as e:
        if e.code != 429 or not url.startswith('https://raw.githubusercontent.com/torvalds/linux/'):
            raise
        rest = url.split('/torvalds/linux/')[1]
        commit, path = rest.split('/', 1)
        save(f'retrieval-linux-{commit}-{Path(path).name}-429.txt',
             f'{url}\nHTTP Error 429: Too Many Requests\nFallback: commit-pinned GitHub contents API\n')
        api = f'https://api.github.com/repos/torvalds/linux/contents/{path}?ref={commit}'
        with urllib.request.urlopen(urllib.request.Request(api, headers={'User-Agent': 'MSD-RS-provenance-research'}), timeout=90) as response:
            return base64.b64decode(json.load(response)['content'])

def clean(s):
    return re.sub(r'/\*.*?\*/|//[^\n]*', '', s, flags=re.S)

def function(s, name):
    s = clean(s)
    m = re.search(r'\b' + name + r'\([^;{}]*\)\s*\{', s)
    if not m:
        raise ValueError(name)
    begin = m.end()
    depth = 1
    for i in range(begin, len(s)):
        depth += (s[i] == '{') - (s[i] == '}')
        if depth == 0:
            return s[begin:i]
    raise ValueError('unclosed function')

def tokens(s):
    return re.findall(r'->|<<|>>|\+\+|--|!=|==|<=|>=|\^=|\w+|[^\s]', clean(s))

def norm(s):
    s = clean(s)
    s = re.sub(r'#ifdef UNNORMALIZED.*?#endif', '', s, flags=re.S)
    for a, b in [('ALPHA_TO', 'rs->alpha_to'), ('INDEX_OF', 'rs->index_of'),
                 ('GENPOLY', 'rs->genpoly'), ('NROOTS', 'rs->nroots'),
                 ('NN', 'rs->nn'), ('PAD', 'rs->pad')]:
        s = re.sub(r'\b' + a + r'\b', b, s)
    s = re.sub(r'\bMODNN\(', 'mod255(rs,', s)
    s = re.sub(r'\bmodnn\(', 'mod255(', s)
    s = re.sub(r'\bA0\b', '255', s)
    s = re.sub(r'\bdata_t\b', 'uint8_t', s)
    s = s.replace('sizeof(uint8_t)', '1').replace('(size_t)', '')
    s = re.sub(r'\brs->mm\b|\bsymsize\b', '8', s)
    s = re.sub(r'\(1\s*<<\s*8\)', '256', s)
    s = re.sub(r'int\s+rsn\s*=\s*rs->nn\s*-\s*rs->nroots\s*;', '', s)
    s = re.sub(r'\brsn\b', 'rs->nn-rs->nroots', s)
    s = re.sub(r'-\s*rs->pad', '', s)
    s = re.sub(r'\b1\s*\*\s*', '', s)
    s = re.sub(r'\s*\*\s*1\b', '', s)
    return s

def regions(init):
    s = clean(init)
    gf = re.search(r'sr\s*=\s*1;.*?(?=if\s*\(sr\s*!=\s*1\))', s, re.S).group()
    gen = re.search(r'rs->genpoly\[0\]\s*=\s*1;.*?rs->genpoly\[i\]\s*=\s*rs->index_of\[rs->genpoly\[i\]\];', s, re.S).group()
    return gf, gen

# Preserve and verify the original archive without rewriting it.
old_path = REPO / 'docs/research/storage/rs-formatter-provenance-2026-11-15/evidence.tar.gz'
old = old_path.read_bytes()
assert sha(old) == 'd7c0e89b793ba29f1160c8ff25d772a393757b78945e5abc57dc7aefc9285bb6'
with tarfile.open(fileobj=io.BytesIO(old)) as t:
    original = {n: t.extractfile(n).read() for n in t.getnames()}
old_manifest = json.loads(original['manifest.json'])
assert len(old_manifest['files']) == 32
for f in old_manifest['files']:
    assert sha(original[f['candidate'] + '/' + f['path']]) == f['sha256']
for line in original['SHA256SUMS'].decode().splitlines():
    digest, path = line.split(maxsplit=1)
    assert sha(original[path.lstrip('*')]) == digest
save('old-verification.json', json.dumps(dict(archive_sha256=sha(old), upstream_files=32,
     all_sha256sums_verified=True), indent=2))

local = (REPO / 'board/cardputerzero/tools/dm-verity/verityfmt.c').read_bytes()
local_text = local.decode()
save('local/verityfmt.c', local, commit='5a6f14027f79c3e3184fab0ae2b73610b9a84973')
local_rs = local_text[local_text.index('/* Reed-Solomon encoder'):local_text.index('/* dm-verity superblock')]
save('local/RS-section.txt', local_rs)
save('local/history.txt', subprocess.check_output(['git', '-C', str(REPO), 'log', '--follow',
     '--format=%H %aI %s', '--', 'board/cardputerzero/tools/dm-verity/verityfmt.c']))
save('retrieval-failures.txt', '2026-11-16: Googlesource external/fec +log init_rs.h returned HTTP 429; full Git clone succeeded. GitHub aosp-mirror/platform_external_fec and platform_system_extras clones returned repository not found; official Googlesource full Git clones succeeded. No retries against the failed REST endpoint.\n')

CS = '102e91cb0fee849bb86fb1ec4d6ea218e45563cd'
LF = '9750ca0a6d0a786b506e44692776b541f90daa91'
AF = '90857deb7973c0ca24c79b9c1809fc9667f32c4f'
AX = 'fc2494a2abd7ab21774d03deb09c1362bbb0bba8'
for repo, end, paths in [
    ('cryptsetup', CS, ['lib/verity/rs_encode_char.c', 'lib/verity/rs.h', 'lib/verity/rs_decode_char.c', 'lib/verity/libfec', 'lib/verity/verity_fec.c']),
    ('libfec', LF, ['encode_rs.h', 'init_rs.h', 'rs-common.h', 'char.h']),
    ('aosp-fec', AF, ['encode_rs.h', 'init_rs.h', 'rs-common.h', 'METADATA']),
    ('aosp-extras', AX, ['libfec', 'verity'])]:
    assert git(repo, 'rev-parse', '--is-shallow-repository').strip() == b'false'
    save(f'history/{repo}.log', git(repo, 'log', '--format=%H %aI %s', end, '--', *paths), commit=end)
    for p in paths:
        if p == 'lib/verity/libfec' or p in ['libfec', 'verity']:
            continue
        save(f'blame/{repo}/{p}.txt', git(repo, 'blame', '--line-porcelain', end, '--', p), commit=end, upstream_path=p)

# Include stable-branch tags too; a tag need not be an ancestor of main.
tags = git('cryptsetup', 'tag').decode().splitlines()
tags = [t for t in tags if re.fullmatch(r'v\d+\.\d+\.\d+', t)]
cutoff = int(subprocess.check_output(['git', '-C', str(REPO), 'show', '-s', '--format=%ct',
                                   '1cb907ad0c87d62cd1e5aceba715426e36c02c04']))
tags = [t for t in tags if int(git('cryptsetup', 'show', '-s', '--format=%ct', t + '^{}')) <= cutoff]
variants = []
snapshots = {}
for tag in tags:
    commit = git('cryptsetup', 'rev-parse', tag + '^{}').decode().strip()
    data = source('cryptsetup', commit, 'lib/verity/rs_encode_char.c')
    snapshots[tag] = (commit, data.decode())
    variants.append(dict(tag=tag, commit=commit, raw_sha256=sha(data),
                         encode_body_sha256=sha(' '.join(tokens(function(data.decode(), 'encode_rs_char'))).encode()),
                         init_body_sha256=sha(' '.join(tokens(function(data.decode(), 'init_rs_char'))).encode())))
save('release-bodies.json', json.dumps(variants, indent=2))

commits = ['c2cf33af242e4cbd580c3feb27c833ec590402a4',
           'e4f1faa478abd4673e7f92c3932f9d783e42eb29',
           '54cb40fce7760a7fc41db9e8c8baab47880c66d9',
           '5e0db46f1790700a23bc9af14f1ab20bac4e7c5b',
           '661f57def4e3aa158305d92079ced68d64be6d8a', CS]
for commit in commits:
    save(f'patches/cryptsetup-{commit}.patch', git('cryptsetup', 'show', '--format=fuller', commit, '--', 'lib/verity', 'README.licensing'), commit=commit)
    paths = ['lib/verity/libfec/' + p for p in ['encode_rs.h', 'init_rs.h', 'char.h', 'rs-common.h']] if commit == commits[0] else ['lib/verity/rs_encode_char.c', 'lib/verity/rs.h']
    for p in paths:
        source('cryptsetup', commit, p)
for p in ['COPYING', 'README.licensing', 'lib/verity/verity_fec.c', 'docs/licenses/COPYING.LGPL-2.1-or-later-WITH-cryptsetup-OpenSSL-exception']:
    source('cryptsetup', CS, p)
for repo, commit, paths in [
    ('libfec', LF, ['encode_rs.h', 'init_rs.h', 'rs-common.h', 'char.h', 'README', 'lesser.txt']),
    ('aosp-fec', AF, ['encode_rs.h', 'init_rs.h', 'rs-common.h', 'char.h', 'METADATA', 'Android.bp', 'lesser.txt', 'NOTICE']),
    ('aosp-fec', '4e213d510f437769f8a28578dd4f786fb7d16c44', ['init_rs.h', 'encode_rs.h']),
    ('aosp-extras', AX, ['libfec/fec_process.cpp', 'libfec/fec_read.cpp', 'libfec/include/fec/ecc.h', 'libfec/Android.bp', 'libfec/NOTICE'])]:
    for p in paths:
        source(repo, commit, p)
save('patches/aosp-warning.patch', git('aosp-fec', 'show', '--format=fuller', '5767f2ce4658e4207ffacd88a268f79fa7ed0d50', '--', 'init_rs.h'), commit='5767f2ce4658e4207ffacd88a268f79fa7ed0d50')

# Verify the original Karn release against the commit-pinned mirror; do not invent a release Git commit.
url = 'https://www.ka9q.net/code/fec/fec-3.0.1.tar.bz2'
release = fetch(url)
save('karn/fec-3.0.1.tar.bz2', release, url=url, release='3.0.1 (non-Git release)', mirror_commit=LF)
karn_matches = []
with tarfile.open(fileobj=io.BytesIO(release)) as t:
    for p in ['encode_rs.h', 'init_rs.h', 'rs-common.h', 'char.h', 'README', 'lesser.txt']:
        n = next(n for n in t.getnames() if n.endswith('/' + p))
        content = t.extractfile(n).read()
        karn_matches.append(dict(path=p, sha256=sha(content), mirror_commit=LF,
                                 byte_equal=content == git('libfec', 'show', f'{LF}:{p}')))
save('karn/mirror-equality.json', json.dumps(karn_matches, indent=2))

# Linux is a negative control, including the pre-2018 rs_control layout.
linux_end = '23c62304dde29abe92013d85910d03a77dada35d'
url = 'https://api.github.com/repos/torvalds/linux/commits?path=lib/reed_solomon/encode_rs.c&sha=' + linux_end + '&per_page=100'
history = save('history/linux-encode.json', fetch(url), commit=linux_end, url=url)
linux_history = json.loads(history)
assert len(linux_history) < 100
for commit in [linux_end, '1da177e4c3f41524e886b7f1b8a0c1fc7321cac2', 'dc8f923eaee24061c557cb3221abeea3b95072c4']:
    for p in ['lib/reed_solomon/encode_rs.c', 'lib/reed_solomon/reed_solomon.c']:
        url = f'https://raw.githubusercontent.com/torvalds/linux/{commit}/{p}'
        save(f'linux/{commit}/{p}', fetch(url), commit=commit, upstream_path=p, url=url)
url = 'https://api.github.com/repos/torvalds/linux/commits/dc8f923eaee24061c557cb3221abeea3b95072c4'
save('history/linux-license-commit.json', fetch(url), commit='dc8f923eaee24061c557cb3221abeea3b95072c4', url=url)

local_parts = {'encode': function(local_text, 'rs_encode'),
               'mod': function(local_text, 'mod255')}
local_parts['gf'], local_parts['genpoly'] = regions(function(local_text, 'rs_init'))
candidates = []
for label, text in [('cryptsetup-first', (OUT / f'cryptsetup/{commits[1]}/lib/verity/rs_encode_char.c').read_text()),
                    ('cryptsetup-fixed', (OUT / f'cryptsetup/{commits[2]}/lib/verity/rs_encode_char.c').read_text()),
                    ('cryptsetup-pinned', (OUT / f'cryptsetup/{CS}/lib/verity/rs_encode_char.c').read_text())]:
    gf, gp = regions(function(text, 'init_rs_char'))
    h = (OUT / f'cryptsetup/{CS}/lib/verity/rs.h').read_text() if label == 'cryptsetup-pinned' else text
    candidates.append((label, dict(encode=function(text, 'encode_rs_char'), gf=gf, genpoly=gp, mod=function(h, 'modnn'))))
for repo, commit in [('libfec', LF), ('aosp-fec', AF)]:
    base = OUT / repo / commit
    s = clean((base / 'encode_rs.h').read_text())
    start = s.index('{')
    gf, gp = regions((base / 'init_rs.h').read_text())
    candidates.append((repo, dict(encode=s[start+1:s.rindex('}')], gf=gf, genpoly=gp,
                                  mod=function((base / 'rs-common.h').read_text(), 'modnn'))))
rows = []
for label, parts in candidates:
    for region, text in parts.items():
        a, b = tokens(local_parts[region]), tokens(text)
        an, bn = tokens(norm(local_parts[region])), tokens(norm(text))
        rows.append(dict(candidate=label, region=region, local_tokens=len(a), source_tokens=len(b),
                         raw_sequence_ratio=round(difflib.SequenceMatcher(None, a, b, autojunk=False).ratio(), 6),
                         normalized_sequence_ratio=round(difflib.SequenceMatcher(None, an, bn, autojunk=False).ratio(), 6),
                         normalized_equal=an == bn))
        save(f'diffs/{label}-{region}.diff', ''.join(difflib.unified_diff(text.splitlines(True), local_parts[region].splitlines(True), fromfile=label, tofile='local')))
        save(f'normalized/{label}-{region}.txt', 'LOCAL\n'+' '.join(an)+'\nUPSTREAM\n'+' '.join(bn)+'\n')
save('token-comparison.json', json.dumps(rows, indent=2))

save('METHOD.txt', 'Regions: function bodies, GF loop from sr=1 to sr!=1, generator construction through index conversion. C comments/whitespace stripped; token punctuation retained; SequenceMatcher autojunk=False. Normalization expands documented libfec macros, fixes symsize/mm=8, A0=255, removes disabled UNNORMALIZED block, removes pad for full length, removes sizeof(uint8_t)=1 and size_t casts, inlines local rsn. It is deliberately parameter-specific; normalized equality is not textual authorship proof. Full code, raw diffs and normalized streams retained. Linux negative control uses raw source/structural reading rather than applying userspace extraction to incompatible kernel functions. No compiler or behavioral tests and no legal conclusion are implied.\n')
save('collector.py', Path(__file__).read_bytes())
save('manifest.json', json.dumps(dict(old_archive_sha256=sha(old), files=manifest.copy()), indent=2))
all_files = sorted(p for p in OUT.rglob('*') if p.is_file())
sums = ''.join(f'{sha(p.read_bytes())}  {p.relative_to(OUT)}\n' for p in all_files)
(OUT / 'SHA256SUMS').write_text(sums)
archive = REPO / 'docs/research/storage/rs-formatter-provenance-2026-11-15/followup-evidence.tar.gz'
with tarfile.open(archive, 'w:gz') as t:
    for p in sorted(p for p in OUT.rglob('*') if p.is_file()):
        t.add(p, arcname=str(p.relative_to(OUT)))
with tarfile.open(archive) as t:
    for line in sums.splitlines():
        digest, name = line.split('  ', 1)
        assert sha(t.extractfile(name).read()) == digest
print('release tags', len(variants))
print('encode body variants', len({v['encode_body_sha256'] for v in variants}))
print('init body variants', len({v['init_body_sha256'] for v in variants}))
print('Karn matches', karn_matches)
print('token comparison', json.dumps(rows, indent=2))
print('ARCHIVE', archive.stat().st_size, sha(archive.read_bytes()), 'members', len(sums.splitlines())+1)
