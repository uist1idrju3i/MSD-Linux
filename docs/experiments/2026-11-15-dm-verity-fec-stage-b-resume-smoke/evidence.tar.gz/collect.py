#!/usr/bin/env python3
import argparse
import csv
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

p = argparse.ArgumentParser()
for name in ('clone', 'kernel', 'handoff', 'destination'):
    p.add_argument(name, type=Path)
a = p.parse_args()
data = {}


def sha(b):
    return hashlib.sha256(b).hexdigest()


def add(name, path):
    assert name not in data
    data[name] = path.read_bytes()


def obj(name, value):
    data[name] = (json.dumps(value, indent=2) + '\n').encode()


base = a.clone / 'output-b3-cases-b3'
for prefix in ('output-b3-smoke-b3', 'output-b3-sources-b3'):
    for path in sorted((a.clone / prefix).rglob('*')):
        if path.is_file():
            add(str(path.relative_to(a.clone)), path)
cases = sorted(path for path in base.iterdir() if (path / 'case.json').exists())
assert len(cases) == 10
for case in cases:
    for name in ('case.json', 'inputs.json', 'qemu-extra-append.txt'):
        add(str((case / name).relative_to(a.clone)), case / name)
for name in ('preparation.json', 'repacked-seed/repack.json', 'repacked-seed/location.json',
             'repacked-seed/variant-info.txt', 'repacked-seed/verity-parameters.env',
             'repacked-seed/mksquashfs.log', 'repacked-seed/format.log',
             'repacked-seed/rootfs-tree/etc/inittab',
             'repacked-seed/rootfs-tree/usr/libexec/b3-readall.sh',
             'nofec-format/params.env', 'nofec-format/format.log'):
    add('output-b3-cases-b3/' + name, base / name)
for name in ('preparation.json', 'repacked-seed/mksquashfs.log'):
    add('failed-preparation-b2/' + name, a.clone / 'output-b3-cases-b2' / name)
add('environment.json', a.clone / 'output-b3-environment-b3.json')
for name in ('p1c4-resume-harness.patch', 'p1c4-resume-fixtures.log',
             'p1c4-resume-host-docker.log', 'p1c4-resume-shellcheck.log',
             'p1c4-resume-shellcheck-uid.log', 'p1c4-resume-shellcheck-rootless.log',
             'p1c4-resume-prepare.log', 'p1c4-resume-prepare-b3.log',
             'p1c4-resume-smoke-b3.log', 'p1c4-resume-busybox-dynamic.txt'):
    add('host/' + name, a.handoff / name)
for name in ('tests/dm-verity-format/test-followup.py', 'tests/dm-verity-format/run.sh'):
    add(name, a.clone / name)
for name in ('b3-trace.patch', 'b3-source-hashes.json', '.config'):
    add('kernel/' + name, a.kernel / name)
tree = base / 'repacked-seed/rootfs-tree'
cpio = base / 'B-clean-ram/initramfs.cpio.gz'
b = gzip.decompress(cpio.read_bytes())
entries, offset = {}, 0
while offset < len(b):
    assert b[offset:offset + 6] == b'070701'
    h = [int(b[offset + 6 + i * 8:offset + 14 + i * 8], 16) for i in range(13)]
    name = b[offset + 110:offset + 110 + h[11] - 1].decode()
    start = (offset + 110 + h[11] + 3) // 4 * 4
    payload = b[start:start + h[6]]
    entries[name] = dict(mode=oct(h[1]), size=len(payload), sha256=sha(payload))
    if h[1] & 0o170000 == 0o120000:
        entries[name]['target'] = payload.decode()
    if name in ('lib/libresolv.so.2', 'bin/busybox', 'lib/ld-linux-aarch64.so.1'):
        assert payload == (tree / name).read_bytes()
    offset = (start + h[6] + 3) // 4 * 4
    if name == 'TRAILER!!!':
        break
obj('diagnosis/cpio-entries.json', entries)
loader = (tree / 'lib/ld-linux-aarch64.so.1').read_bytes()
obj('diagnosis/library-paths.json',
    dict(cpio_sha256=sha(cpio.read_bytes()),
         source_aliases={n: str((tree / n).readlink()) for n in ('lib64', 'usr/lib64')},
         cpio_aliases_present={n: n in entries for n in ('lib64', 'usr/lib64')},
         source_ld_cache=(tree / 'etc/ld.so.cache').exists(),
         cpio_ld_cache='etc/ld.so.cache' in entries,
         loader_directory_literals={s: (s.encode() + bytes(1)) in loader
                                    for s in ('/lib/', '/lib64/', '/usr/lib/', '/usr/lib64/')},
         dynamic_trace_collected=False))
rows = []
buffer = io.StringIO()
w = csv.writer(buffer, lineterminator='\n')
w.writerow(['run_id', 'variant', 'repeat', 'metric', 'value', 'unit', 'valid', 'note'])
for file in sorted((a.clone / 'output-b3-smoke-b3').glob('*/functional.json')):
    result = json.loads(file.read_text())
    assert sha((file.parent / 'serial.log').read_bytes()) == result['serial_sha256']
    case = file.parent.name.removesuffix('-boot0')
    rows.append(result)
    w.writerow(['stage-b-resume-smoke-20261115', case, 0, 'wall', result['wall_seconds'],
                's', int(result['functional_pass']), 'expected=' + result['expected']
                + ';stop=' + result['stop_reason'] + ';formal_runs=0;host_stop=True'])
assert len(rows) == 2 and sum(row['functional_pass'] for row in rows) == 1
assert rows[1]['panic'] and rows[1]['stop_reason'] == 'unexpected-terminal'
data['results.csv'] = buffer.getvalue().encode()
obj('stop.json', dict(reason='second clean smoke failed; no repair or reboot attempted',
                      smoke_runs=2, formal_runs=0, remaining_b_smokes=8,
                      remaining_formal_boots=215,
                      smoke_wall_sum_seconds=sum(row['wall_seconds'] for row in rows),
                      rootless_mapping='host UID 1001; bind owner in container 0; container root used',
                      sdk_mount='/work/output-integrity'))
add('collect.py', Path(__file__))
for name, value in data.items():
    assert Path.home().as_posix().encode() not in value, name
manifest = {name: sha(value) for name, value in sorted(data.items())}
obj('MANIFEST.json', manifest)
a.destination.mkdir()
stream = io.BytesIO()
with tarfile.open(fileobj=stream, mode='w') as tar:
    for name, value in sorted(data.items()):
        info = tarfile.TarInfo(name)
        info.size, info.mode, info.mtime = len(value), 0o644, 0
        tar.addfile(info, io.BytesIO(value))
archive = gzip.compress(stream.getvalue(), mtime=0)
(a.destination / 'evidence.tar.gz').write_bytes(archive)
a.destination.with_suffix('.csv').write_bytes(data['results.csv'])
with tarfile.open(a.destination / 'evidence.tar.gz') as tar:
    for name, digest in manifest.items():
        assert sha(tar.extractfile(name).read()) == digest
print(f'ok - {len(manifest)} evidence members hash-verified; two smoke records, one pass, one clean failure, zero formal trials')
print('archive_sha256=' + sha(archive))
print('archive_bytes=' + str(len(archive)))
print('smoke_wall_sum_seconds=' + str(sum(row['wall_seconds'] for row in rows)))
