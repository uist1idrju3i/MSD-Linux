import csv
import hashlib
import io
import json
from pathlib import Path
import tarfile

repo = Path('/home/devin-worker/e34doc/MSD-Linux')
dry = Path('/home/devin-worker/b3-followup-hostdry/output-host-dry')
base = Path('/home/devin-worker/b3-followup-resume/output-b3-cases-b3')
handoff = Path('/home/devin-worker/handoff')
target = repo / 'docs/experiments/2026-11-15-dm-verity-fec-host-dry'
target.mkdir(exist_ok=False)
files = {}


def add(name, path):
    files[name] = path.read_bytes()


for path in sorted(dry.rglob('*')):
    if path.is_file() and path.suffix in ('.json', '.env', '.log', '.py', '.sh', '.tsv', '.txt'):
        add('dry/' + str(path.relative_to(dry)), path)
for name in ('p1c4-host-dry.log', 'p1c4-host-final-fixtures.log', 'p1c4-host-header-clean.log',
             'p1c4-alias-fixtures.log', 'p1c4-alias-refresh-fixtures.log', 'p1c4-host-c-fixtures.log',
             'p1c4-host-d-fixtures.log', 'p1c4-host-d-verify-fixtures.log',
             'p1c4-host-e-fixtures.log', 'p1c4-host-f-fixtures.log', 'p1c4-r2-probe-console.log',
             'p1c4-cryptsetup-tag.txt', 'p1c4-cryptsetup-tree.json'):
    add('logs/' + name, handoff / name)
for name in ('p1c4-veritysetup-upstream.c', 'p1c4-verity-upstream.c', 'p1c4-fec-upstream.c',
             'p1c4-hash-upstream.c', 'p1c4-cryptsetup-COPYING', 'p1c4-cryptsetup-COPYING.LGPL'):
    add('upstream/' + name, handoff / name)
for path in sorted((handoff / 'p1c4-r2-probe').iterdir()):
    add('probe/' + path.name, path)
add('probe/probe_verify.py', repo / 'board/cardputerzero/tools/bench/dm-verity-fec/probe_verify.py')
add('provenance/old-preparation.json', base / 'preparation.json')
add('payload/base-pack.img', base / 'repacked-seed/rootfs.img')
add('payload/old-initramfs.cpio.gz', base / 'ram.cpio.gz')
add('payload/new-initramfs.cpio.gz', dry / 'cases-b/ram.cpio.gz')
suffixes = {}
for template in sorted((dry / 'cases-d').glob('format-*')):
    p = dict(line.split('=', 1) for line in (template / 'params.env').read_text().splitlines() if '=' in line)
    image = (template / 'rootfs.img').read_bytes()
    data = int(p['data_blocks']) * 4096
    if image[:data] != files['payload/base-pack.img'][:data]:
        raise ValueError('D data differ from common base')
    files['payload/' + template.name + '-suffix.bin'] = image[data:]
    suffixes[template.name] = dict(data_bytes=data, image_bytes=len(image), sha256=hashlib.sha256(image).hexdigest(),
                                 rebuild='base-pack.img[:data_bytes] + corresponding suffix.bin')
files['payload/rebuild.json'] = (json.dumps(suffixes, indent=2) + '\n').encode()
add('archive-script.py', Path(__file__))
record = json.loads((dry / 'host-dry.json').read_text())
csv_path = repo / 'docs/experiments/2026-11-15-dm-verity-fec-host-dry.csv'
with csv_path.open('x', newline='') as stream:
    writer = csv.writer(stream)
    writer.writerow(['run_id', 'stage', 'planned_cases', 'generated_cases', 'passed', 'wall_seconds', 'error'])
    for stage, values in record['stages'].items():
        writer.writerow(['host-dry-1', stage, dict(B=10, C=10, D=18, E=4, F=1)[stage],
                         len(list((dry / ('cases-' + stage.lower())).glob('*/case.json'))),
                         values['passed'], values['wall_seconds'], values.get('error', '')])
add('results.csv', csv_path)
manifest = {name: hashlib.sha256(content).hexdigest() for name, content in files.items()}
files['MANIFEST.json'] = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
archive = target / 'evidence.tar.gz'
with tarfile.open(archive, 'w:gz') as tar:
    for name, content in sorted(files.items()):
        info = tarfile.TarInfo(name)
        info.size = len(content)
        info.mtime = 0
        tar.addfile(info, io.BytesIO(content))
with tarfile.open(archive) as tar:
    for name, expected in manifest.items():
        if hashlib.sha256(tar.extractfile(name).read()).hexdigest() != expected:
            raise ValueError(name)
    for name, values in suffixes.items():
        common = tar.extractfile('payload/base-pack.img').read()
        suffix = tar.extractfile('payload/' + name + '-suffix.bin').read()
        if hashlib.sha256(common[:values['data_bytes']] + suffix).hexdigest() != values['sha256']:
            raise ValueError('D reconstruction: ' + name)
print(f'ok - {len(manifest)} evidence members hash-verified; 37 generated cases, six D cases not generated, zero QEMU boots')
print('ok - four D pack images reconstructed byte-for-byte from archived common data and suffixes')
print('archive_sha256=' + hashlib.sha256(archive.read_bytes()).hexdigest())
print('archive_bytes=' + str(archive.stat().st_size))
