import csv
from datetime import datetime, timezone
import hashlib
import io
import json
import math
from pathlib import Path
import statistics
import sys
import tarfile

stage = sys.argv[1].upper()
partial = '--partial' in sys.argv
number = dict(C=10, D=18, E=4, F=1)[stage]
repo = Path('/home/devin-worker/e34doc/MSD-Linux')
run = Path('/home/devin-worker/b3-followup-b4')
prefix = stage.lower() + '4'
base = run / 'output-d2' if stage == 'D' else Path('/home/devin-worker/b3-followup-hostdry/output-host-dry') / ('cases-' + stage.lower())
date = datetime.now(timezone.utc).strftime('%Y-%m-%d')
target = repo / f'docs/experiments/{date}-dm-verity-fec-stage-{stage.lower()}'
files, records = {}, []
cases = sorted(p for p in base.iterdir() if (p / 'case.json').exists())
assert len(cases) == number
for phase, count in (('smoke', number), ('formal', number * 5)):
    directory = run / f'output-{prefix}-{phase}'
    results = sorted(directory.glob('*/functional.json'))
    if not partial:
        assert len(results) == count
    for raw in sorted(directory.rglob('*')):
        if raw.is_file():
            assert raw.suffix != '.img'
            files[f'raw/{phase}/' + str(raw.relative_to(directory))] = raw.read_bytes()
    for path in results:
        value = json.loads(path.read_text())
        name, repeat = path.parent.name.rsplit('-boot', 1)
        text = (path.parent / 'serial.log').read_bytes()
        assert hashlib.sha256(text).hexdigest() == value['serial_sha256']
        assert math.isfinite(value['wall_seconds']) and value['wall_seconds'] > 0
        value.update(phase=phase, case=name, repeat=int(repeat))
        records.append(value)
    for suffix in ('', '-time'):
        log = Path(f'/home/devin-worker/handoff/p1c4-{prefix}-{phase}{suffix}.log')
        if log.exists():
            files[f'logs/{phase}{suffix}.log'] = log.read_bytes()
for case in cases:
    if not partial:
        repeats = [r['repeat'] for r in records if r['phase'] == 'formal' and r['case'] == case.name]
        assert sorted(repeats) == list(range(5))
    for name in ('case.json', 'inputs.json', 'qemu-extra-append.txt'):
        files[f'inputs/{case.name}/{name}'] = (case / name).read_bytes()
for directory in ('board/cardputerzero/tools/bench/dm-verity-fec', 'board/cardputerzero/qemu'):
    for path in sorted((run / directory).iterdir()):
        if path.suffix in ('.py', '.sh', '.tsv'):
            assert path.read_bytes() == (repo / directory / path.name).read_bytes()
            files['sources/' + directory + '/' + path.name] = path.read_bytes()
files['host-all-ready.json'] = (run / 'host-all-ready.json').read_bytes()
files['archive-script.py'] = Path(__file__).read_bytes()
summary = {}
for case in cases:
    trials = [r for r in records if r['phase'] == 'formal' and r['case'] == case.name]
    smoke = [r for r in records if r['phase'] == 'smoke' and r['case'] == case.name]
    walls = [r['wall_seconds'] for r in trials]
    summary[case.name] = dict(smoke=[r['functional_pass'] for r in smoke],
        wall=walls, median=statistics.median(walls) if walls else None,
        minimum=min(walls) if walls else None, maximum=max(walls) if walls else None,
        matches=sum(r['functional_pass'] for r in trials),
        guards=sorted({r['guard_hits'] for r in trials}),
        panic=sum(r['panic'] for r in trials), restart=sum(r['restart'] for r in trials),
        reset=sum(r['qmp_reset'] for r in trials),
        host_terminated=sum(r['host_terminated_after_observation'] for r in trials))
target.mkdir()
columns = ['phase', 'case', 'repeat', 'expected', 'functional_pass', 'wall_seconds', 'guard_hits',
           'readall_complete', 'ram_read_success', 'ready', 'login', 'panic', 'restart',
           'qmp_reset', 'boot_banners', 'stop_reason', 'exit_status',
           'host_terminated_after_observation', 'final_process_status', 'serial_sha256']
with target.with_suffix('.csv').open('x', newline='') as stream:
    writer = csv.DictWriter(stream, fieldnames=columns, extrasaction='ignore', lineterminator='\n')
    writer.writeheader()
    writer.writerows(records)
files['results.csv'] = target.with_suffix('.csv').read_bytes()
files['summary.json'] = (json.dumps(summary, indent=2) + '\n').encode()
manifest = {name: hashlib.sha256(content).hexdigest() for name, content in files.items()}
files['MANIFEST.json'] = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
archive = target / 'evidence.tar.gz'
with tarfile.open(archive, 'w:gz') as tar:
    for name, content in sorted(files.items()):
        info = tarfile.TarInfo(name)
        info.size, info.mtime = len(content), 0
        tar.addfile(info, io.BytesIO(content))
with tarfile.open(archive) as tar:
    for name, expected in manifest.items():
        assert hashlib.sha256(tar.extractfile(name).read()).hexdigest() == expected
formal = [r for r in records if r['phase'] == 'formal']
print(f'ok - stage {stage}: {len(records)} trials, {len(formal)} formal, {sum(r["functional_pass"] for r in formal)} formal matches; {len(manifest)} members hash-verified')
print('formal_boot_wall_sum=' + str(sum(r['wall_seconds'] for r in formal)))
print('archive_sha256=' + hashlib.sha256(archive.read_bytes()).hexdigest())
print('archive_bytes=' + str(archive.stat().st_size))
print('target=' + str(target.relative_to(repo)))
print(json.dumps(summary, indent=2))
