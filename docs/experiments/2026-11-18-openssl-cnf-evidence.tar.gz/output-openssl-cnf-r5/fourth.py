import csv
import importlib.util
from pathlib import Path

root = Path(__file__).resolve().parents[1]
out = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location(
    "cnf", root / "board/cardputerzero/tools/bench/openssl-cnf/run.py")
cnf = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cnf)
with (out / "fourth.csv").open("x", newline="") as stream:
    writer = csv.DictWriter(stream, fieldnames=[
        "variant", "run", "case", "exit_code", "writes", "sectors", "valid", "serial_sha256"])
    writer.writeheader()
    for label in ("C0", "C1", "C2", "C0-AA"):
        variant = label.split("-")[0]
        directory = out / f"{label}-r4"
        rows = cnf.boot(root / "output-openssl-lts", out / variant / "sdcard.img",
                        variant, directory)
        for row in rows:
            writer.writerow(dict(variant=label, run=4, valid=1, **row,
                                 serial_sha256=cnf.sha(directory / "serial.log")))
        stream.flush()
        print(f"ok - {label} r4: {len(rows)} functional cases", flush=True)
