import csv
import hashlib
import json
from pathlib import Path
import tarfile

out = Path(__file__).resolve().parent
root = out.parent
docs = root / "docs/experiments"
stem = "2026-11-18-openssl-cnf"
rows = []
for filename in ("results.csv", "fourth.csv"):
    with (out / filename).open() as stream:
        for row in csv.DictReader(stream):
            row.update(phase="pilot" if row["run"] == "1" else "formal", attempt="r5")
            rows.append(row)
assert len(rows) == 400
assert all(row["valid"] == "1" for row in rows)
formal = [row for row in rows if row["phase"] == "formal"]
assert len(formal) == 300
assert {row["run"] for row in formal} == {"2", "3", "4"}
assert all(row["writes"] == "0" and row["sectors"] == "0" for row in rows)
for number, case in ((1, "extract-chown"), (2, "missing-modinfo"),
                     (3, "missing-timeout"), (4, "tar-gzip-unavailable")):
    rows.append(dict(phase="failed", attempt=f"r{number}", variant="C0", run=1,
                     case=case, valid=0))
rows.append(dict(phase="instrument", attempt="r5", variant="C0", run=1,
                 case="known-load-65536-bytes", sectors=240, exit_code=0, valid=1))
with (docs / f"{stem}.csv").open("w", newline="") as stream:
    writer = csv.DictWriter(stream, fieldnames=[
        "phase", "attempt", "variant", "run", "case", "exit_code", "writes",
        "sectors", "valid", "serial_sha256"])
    writer.writeheader()
    writer.writerows(rows)

files = {}
def add(path, name=None):
    if path.is_file():
        files[name or str(path.relative_to(root))] = path

for number in range(1, 6):
    directory = root / f"output-openssl-cnf-r{number}"
    add(root / f"output-openssl-cnf-r{number}-driver.log")
    for name in ("build.log", "inputs.json", "results.csv", "fourth.csv",
                 "calibrate.py", "fourth.py", "aggregate.py", "calibration-driver.log",
                 "fourth-driver.log", "kmod-probe", "openssl-build.json"):
        add(directory / name)
    for pattern in ("*-r*/serial.log", "*-r*/guest-logs.tar.gz", "calibration/serial.log",
                    "C?/openssl.cnf"):
        for path in directory.glob(pattern):
            add(path)
for name in ("run.py", "guest.sh", "module.c"):
    add(root / "board/cardputerzero/tools/bench/openssl-cnf" / name)
for name in ("mksquashfs",):
    add(root / "output-openssl-lts/host/bin" / name)
add(root / "output-openssl-lts/build/squashfs-sort.resolved")
add(root / "output-openssl-lts/build/libopenssl-3.5.9/LICENSE.txt")
add(root / "output-openssl-lts/build/kmod-34.2/COPYING")
hashes = {name: hashlib.sha256(path.read_bytes()).hexdigest() for name, path in files.items()}
index = out / "evidence-sha256.json"
index.write_text(json.dumps(hashes, indent=2) + "\n")
add(index)
archive = docs / f"{stem}-evidence.tar.gz"
with tarfile.open(archive, "w:gz") as target:
    for name, path in sorted(files.items()):
        target.add(path, arcname=name, recursive=False)
print(f"ok - {len(formal)} formal cases, 100 pilot cases, 4 failed attempts, 1 calibration")
print("ok - formal/pilot p7 case deltas all zero; known-load 240 sectors")
print(f"evidence files={len(files)} bytes={archive.stat().st_size}")
print(f"sha256={hashlib.sha256(archive.read_bytes()).hexdigest()}")
