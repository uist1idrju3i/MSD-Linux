import importlib.util
from pathlib import Path
import os
import selectors
import shutil
import subprocess
import time

root = Path(__file__).resolve().parents[1]
out = Path(__file__).resolve().parent / "calibration"
out.mkdir(exist_ok=False)
image = out / "sdcard.img"
subprocess.run(["cp", "--sparse=always", str(out.parent / "C0/sdcard.img"), str(image)], check=True)
env = dict(os.environ, OUTPUT_DIR=str(root / "output-openssl-lts"),
           QEMU_COPY_IMAGE="0", ROOT_DEVICE="/dev/mmcblk0p5", ROOT_FSTYPE="squashfs",
           QEMU_MACHINE="raspi3ap", QEMU_ICOUNT="", QEMU_HASH_IMAGE="1")
process = subprocess.Popen([str(root / "board/cardputerzero/qemu/run-qemu.sh"), str(image)],
                           stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                           stderr=subprocess.STDOUT, env=env)
selector = selectors.DefaultSelector()
selector.register(process.stdout, selectors.EVENT_READ)
pending = bytearray()
with (out / "serial.log").open("xb") as log:
    def read(marker):
        deadline = time.monotonic() + 240
        while marker not in pending:
            if time.monotonic() > deadline:
                raise TimeoutError(marker)
            if selector.select(1):
                data = os.read(process.stdout.fileno(), 65536)
                if not data:
                    raise RuntimeError("unexpected EOF")
                pending.extend(data)
                log.write(data)
                log.flush()
        del pending[:pending.index(marker) + len(marker)]

    def send(command):
        process.stdin.write(command.encode() + b"\n")
        process.stdin.flush()

    try:
        read(b"login:")
        send("root")
        read(b"# ")
        send("stty -echo")
        read(b"# ")
        send("sync; sleep 10; "
             "echo CAL_BEFORE; cat /sys/class/block/mmcblk0p7/stat; "
             "dd if=/dev/zero of=/data/cnf-instrument-control bs=4096 count=16 conv=fsync; sync; "
             "echo CAL_AFTER; cat /sys/class/block/mmcblk0p7/stat; "
             "rm /data/cnf-instrument-control; sync; sleep 3; "
             "echo CAL_CLEAN; cat /sys/class/block/mmcblk0p7/stat; "
             "echo CAL_DONE")
        read(b"CAL_DONE")
        read(b"# ")
    finally:
        process.terminate()
        process.wait(timeout=10)
        selector.close()
raw = (out / "serial.log").read_text()
before = raw.split("CAL_BEFORE\n")[1].splitlines()[0].split()
after = raw.split("CAL_AFTER\n")[1].splitlines()[0].split()
delta = int(after[6]) - int(before[6])
assert delta >= 128, delta
print(f"ok - p7 known-load: 65536 payload bytes, {delta} sectors observed")
