#!/usr/bin/env python3
import argparse
import csv
from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
import math
from pathlib import Path
import tarfile


def sha(data):
    return hashlib.sha256(data).hexdigest()


p = argparse.ArgumentParser()
for key in ('formal', 'kernel', 'busybox', 'binary', 'handoff', 'destination'):
    p.add_argument(key, type=Path)
a = p.parse_args()
members = {}


def add(name, path):
    if name in members:
        raise ValueError('duplicate member')
    members[name] = path.read_bytes()


def obj(name, value):
    members[name] = (json.dumps(value, indent=2) + '\n').encode()


for prefix in ('output-b3-smoke-b', 'output-b3-sources-b'):
    for path in sorted((a.formal / prefix).rglob('*')):
        if path.is_file():
            add(str(path.relative_to(a.formal)), path)
for path in sorted((a.formal / 'output-b3-cases-b').rglob('*')):
    if path.is_file() and path.suffix in ('.json', '.txt', '.env', '.log'):
        add(str(path.relative_to(a.formal)), path)
add('environment.json', a.formal / 'output-b3-environment-b.json')
for name in ('p1c4-kernel-build.log', 'p1c4-host-final.log', 'p1c4-cpio-fixtures.log',
             'p1c4-shellcheck.log', 'p1c4-prepare-b.log', 'p1c4-smoke-b.log',
             'p1c4-booted-inittab.txt', 'p1c4-exec-reproduction.txt'):
    add('host/' + name, a.handoff / name)
for name in ('init/init.c', 'shell/ash.c', 'LICENSE', '.config'):
    add('busybox-source/' + name, a.busybox / name)
lines = (a.handoff / 'p1c4-busybox-disassembly.txt').read_text().splitlines()
snippet = []
for line in lines:
    try:
        address = int(line.strip().split(':')[0], 16)
    except ValueError:
        continue
    if 0x97210 <= address <= 0x973a8:
        snippet.append(line)
members['busybox-source/actual-init-exec-disassembly.txt'] = ('\n'.join(snippet) + '\n').encode()
b = a.binary.read_bytes()
observed = 'bca3db4b4267666e0f5fd78b89326bbc34b8e8cdb779a62f3ffb49d083b14637'
assert sha(b) == observed
strings = {hex(n): b[n:b.index(0, n)].decode() for n in (0xb9430, 0xb9431, 0xb9439, 0xb9450, 0xabb99)}
obj('busybox-source/binary-binding.json',
    dict(actual_image_extraction_sha256=observed, analyzed_binary_sha256=sha(b),
         cached_build_binary_sha256=sha((a.busybox / 'busybox').read_bytes()),
         source_binding='cached 1.38.0 source is not assumed to reproduce the seed binary; actual binary disassembly independently checked',
         actual_binary_strings=strings, actual_init_exec_range=['0x97210', '0x973a8']))
records = sorted((a.formal / 'output-b3-smoke-b').glob('*/functional.json'))
assert len(records) == 1 and records[0].parent.name == 'B-clean-normal-boot0'
f = json.loads(records[0].read_text())
assert math.isfinite(f['wall_seconds']) and f['wall_seconds'] > 0
assert sha((records[0].parent / 'serial.log').read_bytes()) == f['serial_sha256']
assert not f['functional_pass'] and f['ready'] and f['login'] and not f['readall_complete']
assert f['stop_reason'] == 'unexpected-terminal'
buffer = io.StringIO()
w = csv.writer(buffer)
w.writerow(['run_id', 'variant', 'repeat', 'metric', 'value', 'unit', 'valid', 'note'])
w.writerow(['stage-b-smoke-20261115', 'B-clean-normal', 0, 'wall', f['wall_seconds'], 's', 0,
            'expected=normal-read;stop=unexpected-terminal;ready=True;login=True;readall=False;host_stop=True;formal_runs=0'])
members['results.csv'] = buffer.getvalue().encode()
stop = dict(finished_utc=datetime.now(timezone.utc).isoformat(), smoke_completed=1,
            smoke_remaining=9, formal_runs=0, stage_c_through_f_started=False,
            cause='clean smoke lacks independent readall marker; no gate relaxation or retry',
            remaining_planned_formal=215, projected_seconds_per_boot=240,
            projected_new_smokes_after_repack=43, projected_preparation_hours=4)
obj('stop.json', stop)
members['collect.py'] = Path(__file__).read_bytes()
for name, data in members.items():
    assert Path.home().as_posix().encode() not in data, name
manifest = {name: sha(data) for name, data in sorted(members.items())}
members['MANIFEST.json'] = (json.dumps(manifest, indent=2) + '\n').encode()
a.destination.mkdir()
tarbuffer = io.BytesIO()
with tarfile.open(fileobj=tarbuffer, mode='w') as tar:
    for name, data in sorted(members.items()):
        info = tarfile.TarInfo(name)
        info.size, info.mode, info.mtime = len(data), 0o644, 0
        tar.addfile(info, io.BytesIO(data))
archive = gzip.compress(tarbuffer.getvalue(), mtime=0)
(a.destination / 'evidence.tar.gz').write_bytes(archive)
a.destination.with_suffix('.csv').write_bytes(members['results.csv'])
with tarfile.open(a.destination / 'evidence.tar.gz') as tar:
    for name, digest in manifest.items():
        assert sha(tar.extractfile(name).read()) == digest
print(f'ok - {len(manifest)} evidence members hash-verified; one failed smoke preserved, zero formal runs')
print('archive_sha256=' + sha(archive))
print('archive_bytes=' + str(len(archive)))
print('wall_seconds=' + str(f['wall_seconds']))
print('strings=' + json.dumps(strings))
