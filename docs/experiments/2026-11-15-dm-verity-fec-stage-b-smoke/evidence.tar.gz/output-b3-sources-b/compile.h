#define UTS_MACHINE		"aarch64"
#define LINUX_COMPILE_BY	"b3-research"
#define LINUX_COMPILE_HOST	"standalone"
#define LINUX_COMPILER		"aarch64-linux-gcc.br_real (Buildroot 2021.11-18033-g83947c7bb6) 14.3.0, GNU ld (GNU Binutils) 2.43.1"
