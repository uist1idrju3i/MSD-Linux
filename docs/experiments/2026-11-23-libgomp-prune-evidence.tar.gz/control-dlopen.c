#include <dlfcn.h>
int main(void){return !dlopen("libgomp.so.1",RTLD_NOW);}
