int main(void) {int n=0;
#pragma omp parallel reduction(+:n)
n+=1;
return n<1;}
