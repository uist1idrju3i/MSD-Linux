# /data grow後のidle残量の帰属

- 状態: 実施中
- 日付: 2026-11-17
- 担当: Devin
- 関連: [同期初期化の測定](2026-11-17-data-sync-itable.md)、[書き込み台帳](../design/write-policy.md)

## 目的と仮説

同期初期化後の最初の120秒idleに残った88 sectorを、guestのjbd2統計・ext4 lifetime値とblock offsetで帰属します。仮説はgrow・mkdirで汚れたmetadataの遅延writebackです。superblockの定期更新、atime、userspace等も検査し、到達経路を確かめない原因は断定しません。製品コードを変更せず、修正候補は記述にとどめます。

## 採否の基準（測定前）

同一入力を5回測定し、各回のidle1全sectorをoffsetの領域分類とguest counterの差分で説明できた場合に限り帰属を確定します。説明できないsectorを残余として表示します。RAM対照はp7 0、disk正対照は2,048 sector以上を要件とします。idle2も120秒観測します。速度の優劣は判定しません。

## 条件と手順

基準はmainの`72c51cc31e73832e76cb8c9574e2e9c06c6bcf02`です。前回の`output-data-sync-itable/input-after`とwarm treeの`output-openssl-lts`を使い、再buildしません。製品のmount/grow関連sourceが基準と一致すること、binary hashが前回と一致することを照合します。製品imageにはhookを入れず、serial経由でRAMへ転送します。

固定kernelは`CONFIG_FTRACE`無効です。代わりにQEMUの`blk_co_pwritev`でoffsetを取り、guestの`/proc/fs/jbd2/mmcblk0p7-8/info`、ext4 lifetime/session値、p7 statを観測します。元runnerのRAM/disk対照を保持し、idleでは1秒ごとのcounter読取りだけを加えます。

```sh
docker/msd-dev python3 board/cardputerzero/tools/bench/write-inventory/run.py \
  --output output-data-sync-itable/input-after \
  --run-dir output-data-idle-residual/runs/trace-r1 \
  --variant trace --seconds 120 --windows 2 --trace-writes \
  --guest-script board/cardputerzero/tools/bench/write-inventory/residual-guest.sh
```

## 結果・失敗・保存

実施後に入力hash、全試行の生値、offset分類、失敗、証拠の照合結果を追記します。QEMUの値であり、実SD・FTL・電源断・製品画面の検証には使いません。
