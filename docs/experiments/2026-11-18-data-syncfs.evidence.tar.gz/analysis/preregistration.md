# /data初期設定末尾のsyncfs

- 状態: 計画登録、未測定
- 基準: `9e89357`。実行前にfull commitと入力hashを保存する
- 関連: [残量の帰属](2026-11-17-data-idle-residual.md)

## 目的と事前基準

grow・mkdir後のsyncfsが、journal commitだけでなくmetadataの本来位置へのwritebackを待つか検証する。最初に未変更imageのRAM上でhelperを呼ぶpilotを行う。boot counterに従って切り分けたtraceで、既知の11 metadata blockがsyncfs終了前へ移り、120秒idleのp7が0でなければ製品への組込みを停止する。

pilot合格後、同じwarm tree・kernel・QEMU・計測器でbefore/after各5回、初回起動のboot・idle1・idle2を測る。idleは各120秒。変更後の全5回で両idleが0、RAM対照0、disk正対照2,048 sector以上を採否基準とする。起動時間の絶対値と差も記録し、実機性能とは扱わない。

拡張・directory作成済みのsecond bootもbefore/after各5回測り、同期を省略できることと追加費用を確認する。同期失敗はhost fault injectionで非zeroと診断を確認する。実SD・電源断・LCDとprogressは未確認のままとする。失敗した試行も保存し、既存の出力は上書きしない。
