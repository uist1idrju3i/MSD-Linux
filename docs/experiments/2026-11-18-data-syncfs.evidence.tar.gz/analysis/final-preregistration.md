# /data初期設定末尾のsyncfs

- 状態: 初回5回のidle基準を満たした。起動時間・second bootを測定中
- 基準: `9e89357`。実行前にfull commitと入力hashを保存する
- 関連: [残量の帰属](2026-11-17-data-idle-residual.md)

## 目的と事前基準

grow・mkdir後のsyncfsが、journal commitだけでなくmetadataの本来位置へのwritebackを待つか検証する。最初に未変更imageのRAM上でhelperを呼ぶpilotを行う。boot counterに従って切り分けたtraceで、既知の11 metadata blockがsyncfs終了前へ移り、120秒idleのp7が0でなければ製品への組込みを停止する。

pilot合格後、同じwarm tree・kernel・QEMU・計測器でbefore/after各5回、初回起動のboot・idle1・idle2を測る。idleは各120秒。変更後の全5回で両idleが0、RAM対照0、disk正対照2,048 sector以上を採否基準とする。起動時間の絶対値と差も記録し、実機性能とは扱わない。

拡張・directory作成済みのsecond bootもbefore/after各5回測り、同期を省略できることと追加費用を確認する。同期失敗はhost fault injectionで非zeroと診断を確認する。実SD・電源断・LCDとprogressは未確認のままとする。失敗した試行も保存し、既存の出力は上書きしない。

## 時間計測の追加登録

元runnerのboot snapshotはlogin後のhook転送も含むため、起動時間の代用にはしない。旧runnerを変更せず、`run-timed.py`の写しでQEMU launcher起動からlogin promptまでのmonotonic wall時間を記録する。provenanceの入力hash計算も含む値であり、kernel内だけの時間ではない。初回起動はこの写しでbefore/after各5回、idleを1秒1窓として時間だけを追加測定する。second bootは同じ写しで各5回、120秒1窓とする。正式な初回idleの採否は元runnerの120秒2窓で行う。

second bootの入力は共通の拡張済みp7を使い、disk正対照fileを除去してoffline fsckでcleanにする。before/afterで同一p7を使うことで、前回runnerの強制終了によるrecovery差を起動時間へ混ぜない。

## 実行条件と事前登録との差

beforeは基準commitのS02、afterは末尾同期を加えたS02です。helper packageはpilotのため双方のrootfsへ収録し、beforeのS02からは呼びません。事前登録に書いたRAMへのhelper投入ではなく、S02以外のpackageを揃える方式にしました。純粋なmain imageとの比較ではなく、S02の変更による差を測ります。

Buildrootの同じwarm treeで両imageを作り、kernel・DTBを共通にします。通常のgenimageが作った64 MiBのp7を1 GiBのSD imageで初回起動し、352 MiBまで広げます。全runにQEMU block write traceを付け、各runのSDは独立した写しです。初回の120秒測定はbefore/afterを交互に5回ずつ実行します。時間測定は別の交互5回で、短いidleを遅延writebackの採否には使いません。

second bootはpilotのp7を取り出し、offline fsck、正対照fileの除去、再fsckを行った共通のclean imageを使います。p5/p6へ各variantのrootfsを入れ、p7の同一性を維持します。実際に1回目を起動して強制終了した直後のrecovery costではなく、拡張・directory作成済みでcleanな起動の比較です。

既存post-buildはQEMU読取り順のsortlistをmksquashfsへ渡します。両buildで`Cannot stat sortlist entry "etc/default/seedrng"`などの警告が出ました。固定containerとBuildroot toolは動作しており、原因は現在のrootfsにない項目が既存sortlistに残ることです。実験間でsortlistを変えず、警告も保存します。

## 方式とhome-locationの確認

[一次資料による比較](../research/storage/data-syncfs.md)から、小さいC helperを選びました。globalな`sync()`は対象を限定できず、戻り値でwriteback errorも通知できません。固定BusyBox 1.38.0は`FEATURE_SYNC_FANCY`が無効で、有効にしても`sync -f /data`が`syncfs()`のerrorを捨てます。helperは`open`・`syncfs`・`close`の失敗を診断して非zeroを返し、S02も同期失敗を記録して終了1とします。target上のhelperは5,920 byteです。他方式のbinary sizeは比較していません。

先に行ったpilotでは、helper前のp7 counterが16,848、戻った後が16,936 sectorで、差は88でした。in-flightは境界で0です。traceをcounterで切ると、次のhome-locationがそれぞれ8 sectorずつ、helperが戻る前に書かれています。journal領域へのcommitだけでは説明できません。その後の120秒idleは0、RAM対照0、disk正対照2,112 sectorでした。

| 対象 | p7内の4 KiB block | sector |
|---|---|---:|
| directory | 10、2097、2098 | 24 |
| bitmap | 9、25、32779 | 24 |
| inode table | 41、32781 | 16 |
| superblock | 0、32768 | 16 |
| GDT | 1 | 8 |
| 合計 | 11 block | 88 |

blockの用途は前回の帰属と一致し、今回の`dumpe2fs`・`debugfs`でもdirectory・各group・journal inodeの配置を保存しました。helperはfilesystem内のpending writebackを待つもので、実SDの内部cacheやFTLの永続性を証明しません。

## 予備試行v1: df判定での初回5回

単位は512 byte sectorです。bootはhookの最初のsnapshotまでの累積値で、boot時間ではありません。両idle窓は各120秒sleepです。

| 反復 | before boot | after boot | before idle1 | after idle1 | idle2（双方） |
|---|---:|---:|---:|---:|---:|
| 1 | 16,848 | 16,968 | 88 | 0 | 0 |
| 2 | 16,880 | 16,936 | 88 | 0 | 0 |
| 3 | 16,880 | 16,936 | 88 | 0 | 0 |
| 4 | 16,848 | 16,936 | 88 | 0 | 0 |
| 5 | 16,880 | 16,936 | 88 | 0 | 0 |

全10回のRAM対照は0、disk正対照は2,112 sectorでした。idleへの88 sectorをboot側へ移せましたが、総量を減らしたとは結論しません。boot＋idleの総量は双方16,936〜16,968 sectorです。r1のafterとbeforeの総量差32 sectorは、journal内のphysical block 15、1072〜1074への各8 sectorでした。beforeの反復間にも32 sectorの差があり、すべてをhelper固有の増加・削減とは扱いません。

このv1ではgrow前後の`df -Pk`を比較していました。しかしext4の値はmetadata overheadを差し引くため、最終版はsuperblockの実block数を`dumpe2fs -h`で読みます。途中だったv1時間測定はcontainerを停止して中断し、失敗した試行を含めて保存します。v1を最終版の5回測定に数えず、最終imageで測り直します。

再登録した最終測定では、counter測定のbefore/afterを1組ずつ同時に起動し、組を5回繰り返します。両variantの条件は同じ2 VMです。初回idleは120秒2窓、起動時間は別途1 VMで交互5回、second bootも1 VMで交互5回・120秒1窓とします。時間測定をcounter測定やbuildと並行させません。実block数の検出不能・grow失敗・mkdir失敗は保守的に同期し、fsck修復も同期します。
