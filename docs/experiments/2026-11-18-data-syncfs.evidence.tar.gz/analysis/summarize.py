import csv
import importlib.util
import json
import statistics
from pathlib import Path

root = Path(__file__).resolve().parent
repo = root.parent
spec = importlib.util.spec_from_file_location("residual", repo / "board/cardputerzero/tools/bench/write-inventory/residual-report.py")
report = importlib.util.module_from_spec(spec)
spec.loader.exec_module(report)
rows = []
for condition, prefix, windows in [("first", "final-", 2), ("timing", "final-timing-", 1), ("second", "final-second-", 1)]:
    for repeat in range(1, 6):
        for variant in ["before", "after"]:
            run = root / "runs" / f"{prefix}{variant}-r{repeat}"
            samples = {}
            for row in csv.DictReader((run / "raw.csv").open()):
                if row["metric"] != "mmcblk0p7.write_sectors":
                    continue
                fields = dict(pair.split("=", 1) for pair in row["note"].split(";"))
                assert fields["stat"].split()[8] == "0", (run, fields)
                samples[fields["phase"], int(row["repeat"])] = int(row["value"])
            def delta(phase, number):
                return samples[f"{phase}-after", number] - samples[f"{phase}-before", number]
            total = samples["disk-after", 0]
            trace = (run / "writes.trace").read_text()
            blocks = report.select_blocks(trace, 0, total, total, 1376256, 720896)
            assert sum(blocks.values()) == total
            for number in range(1, windows + 1):
                matched = report.select_blocks(trace, samples["idle-before", number], samples["idle-after", number], total, 1376256, 720896)
                assert sum(matched.values()) == delta("idle", number)
            serial = (run / "serial.log").read_text()
            calls = serial.count("msd-data: setup synchronized")
            assert calls == (1 if condition != "second" and variant == "after" else 0), (run, calls)
            assert delta("ram", 0) == 0 and delta("disk", 0) >= 2048, run
            if condition == "first":
                assert delta("idle", 1) == (88 if variant == "before" else 0), run
                assert delta("idle", 2) == 0, run
                if variant == "after":
                    boot_blocks = report.select_blocks(trace, 0, samples["boot", 0], total, 1376256, 720896)
                    for block in [0, 1, 9, 10, 25, 41, 2097, 2098, 32768, 32779, 32781]:
                        assert boot_blocks[block] >= 8, (run, block)
            if condition == "second":
                assert delta("idle", 1) == 0, run
            seconds = json.loads((run / "boot-time.json").read_text())["launch_to_login_seconds"] if (run / "boot-time.json").exists() else ""
            rows.append(dict(condition=condition, variant=variant, repeat=repeat,
                             boot_p7_sector512=samples["boot", 0],
                             idle1_p7_sector512=delta("idle", 1),
                             idle2_p7_sector512=delta("idle", 2) if windows == 2 else "",
                             ram_p7_sector512=delta("ram", 0), disk_p7_sector512=delta("disk", 0),
                             launch_to_login_seconds=seconds, helper_invocations=calls))
with (root / "summary.csv").open("w") as stream:
    writer = csv.DictWriter(stream, fieldnames=list(rows[0]), lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
for condition in ["first", "timing", "second"]:
    print(condition)
    for variant in ["before", "after"]:
        selected = [r for r in rows if r["condition"] == condition and r["variant"] == variant]
        print(variant, "boot=", [r["boot_p7_sector512"] for r in selected], "idle1=", [r["idle1_p7_sector512"] for r in selected], "idle2=", [r["idle2_p7_sector512"] for r in selected])
    if condition != "first":
        before = [r["launch_to_login_seconds"] for r in rows if r["condition"] == condition and r["variant"] == "before"]
        after = [r["launch_to_login_seconds"] for r in rows if r["condition"] == condition and r["variant"] == "after"]
        differences = [a - b for b, a in zip(before, after)]
        print("seconds before=", before, "after=", after, "paired_delta=", differences)
        print("median before/after/delta=", statistics.median(before), statistics.median(after), statistics.median(differences))
print("PASS: 30 runs; trace/counter reconciliation; zero in-flight; controls; first idle 88 -> 0; second boot skips syncfs")
