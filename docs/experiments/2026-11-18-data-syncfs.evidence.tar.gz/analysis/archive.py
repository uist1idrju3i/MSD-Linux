import hashlib
import io
import json
import shutil
import tarfile
from decimal import Decimal
from pathlib import Path

root = Path(__file__).resolve().parent
repo = root.parent
sources = ["Config.in", "configs/msd_cardputerzero_defconfig", "board/cardputerzero/post-build.sh",
           "board/cardputerzero/rootfs-overlay/etc/init.d/S02msd-data",
           "board/cardputerzero/squashfs-sort.txt", "board/cardputerzero/qemu/run-qemu.sh",
           "tests/init-scripts/run.sh", "tests/init-scripts/syncfs-faults.c", "tests/write-inventory/run.py",
           "output-openssl-lts/build/linux-custom/.config", "output-openssl-lts/build/linux-custom/fs/sync.c",
           "output-openssl-lts/build/linux-custom/fs/ext4/super.c",
           "output-openssl-lts/build/busybox-1.38.0/.config", "output-openssl-lts/build/busybox-1.38.0/coreutils/sync.c",
           "output-openssl-lts/build/e2fsprogs-1.47.4/resize/main.c", "output-openssl-lts/build/e2fsprogs-1.47.4/misc/dumpe2fs.c",
           "output-openssl-lts/host/bin/mksquashfs", "output-openssl-lts/build/squashfs-sort.resolved",
           "output-openssl-lts/target/usr/sbin/msd-syncfs"]
sources += [str(p.relative_to(repo)) for p in (repo / "package/msd-syncfs").iterdir() if p.is_file()]
sources += [str(p.relative_to(repo)) for p in (repo / "board/cardputerzero/tools/bench/write-inventory").iterdir() if p.is_file()]
assert all((repo / p).is_file() for p in sources)
evidence = root / "evidence"
evidence.mkdir(exist_ok=False)
def copy(source, destination):
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)
for source in sources:
    copy(repo / source, evidence / "source" / source)
for run in sorted((root / "runs").iterdir()):
    for source in sorted(run.iterdir()):
        if source.is_file() and source.suffix != ".img":
            copy(source, evidence / "runs" / run.name / source.name)
patterns = ["*-driver.log", "build-*.log", "grown*.json", "grown*.log", "journal-map.log",
            "tool-versions.txt", "compiler-version.txt", "source-manifest.json", "sort-inputs.sha256",
            "*preregistration.md", "product*.patch", "summary.csv", "summary.log", "legal-info-final.log",
            "summarize.py", "archive.py", "provenance.txt", "v1-abort.json", "*-S02", "precreated-preparation.log"]
for source in sorted({p for pattern in patterns for p in root.glob(pattern)}):
    copy(source, evidence / "analysis" / source.name)
inputs = {}
for name in ["input-before", "input-after", "input-grown-before", "input-grown-after", "input-final-after", "input-grown-final-after", "input-precreated-after"]:
    directory = root / name
    copy(directory / ".config", evidence / "inputs" / name / "buildroot.config")
    for source in sorted((directory / "images").iterdir()):
        if source.is_file():
            with source.open("rb") as stream:
                digest = hashlib.file_digest(stream, "sha256").hexdigest()
            inputs[str(source.relative_to(root))] = dict(sha256=digest, size=source.stat().st_size)
(evidence / "input-binaries.json").write_text(json.dumps(inputs, indent=2) + "\n")
manifest = {}
for source in sorted(evidence.rglob("*")):
    if source.is_file():
        stat = source.stat()
        manifest[str(source.relative_to(evidence))] = dict(sha256=hashlib.sha256(source.read_bytes()).hexdigest(), size=stat.st_size, mtime_ns=stat.st_mtime_ns)
(evidence / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
archive = repo / "docs/experiments/2026-11-18-data-syncfs.evidence.tar.gz"
assert not archive.exists()
with tarfile.open(archive, "w:gz", format=tarfile.PAX_FORMAT) as stream:
    for source in sorted(evidence.rglob("*")):
        if source.is_file():
            info = stream.gettarinfo(str(source), arcname=str(source.relative_to(evidence)))
            ns = source.stat().st_mtime_ns
            info.pax_headers["mtime"] = f"{ns // 1000000000}.{ns % 1000000000:09d}"
            with source.open("rb") as content:
                stream.addfile(info, content)
with tarfile.open(archive, "r:gz") as stream:
    assert {member.name for member in stream} == set(manifest) | {"manifest.json"}
    assert json.load(stream.extractfile("manifest.json")) == manifest
    for name, expected in manifest.items():
        member = stream.getmember(name)
        data = stream.extractfile(member).read()
        assert len(data) == expected["size"]
        assert hashlib.sha256(data).hexdigest() == expected["sha256"]
        assert int(Decimal(member.pax_headers["mtime"]) * 1000000000) == expected["mtime_ns"]
print(f"PASS: archive roundtrip {len(manifest)} files; sha256/size/mtime_ns match")
print(f"archive bytes={archive.stat().st_size} sha256={hashlib.sha256(archive.read_bytes()).hexdigest()}")
