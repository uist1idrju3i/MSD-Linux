#!/bin/sh
set -eu

target_dir="${1:?Buildroot must pass TARGET_DIR}"
mkdir -p "$target_dir/run" "$target_dir/tmp" "$target_dir/var/log" "$target_dir/data" \
	"$target_dir/proc" "$target_dir/sys" "$target_dir/dev/pts" "$target_dir/dev/shm"

# Update this inventory when executable rootfs-overlay scripts gain commands.
required_target_commands='
awk
cat
cmp
dd
fsck.ext4
fsync
grep
ir-ctl
ir-keytable
ln
loadkeys
media-ctl
mkdir
mkfs.ext4
mkswap
mount
msd-data-grow
msd-hwinfo
msd-syncfs
dumpe2fs
msd-update
mktemp
mv
od
openssl
partx
readlink
reboot
resize2fs
rm
rmdir
sfdisk
sha256sum
sed
sh
sleep
sync
swapon
tar
touch
tr
umount
v4l2-ctl
watchdog
wc
'
missing_target_commands=0
while IFS= read -r target_command; do
	if [ -z "$target_command" ]; then
		continue
	fi
	command_found=0
	for path_dir in bin sbin usr/bin usr/sbin; do
		if [ -x "$target_dir/$path_dir/$target_command" ]; then
			command_found=1
			break
		fi
	done
	if [ "$command_found" -eq 0 ]; then
		printf 'Required target command is missing: %s\n' "$target_command" >&2
		missing_target_commands=1
	fi
done <<EOF
$required_target_commands
EOF
if [ "$missing_target_commands" -ne 0 ]; then
	exit 1
fi

rm -f "$target_dir/etc/init.d/S01seedrng" \
	"$target_dir/etc/init.d/S05seedrng" "$target_dir/etc/default/seedrng"
for seedrng_file in etc/init.d/S01seedrng etc/init.d/S05seedrng etc/default/seedrng; do
	test ! -e "$target_dir/$seedrng_file"
done
test -x "$target_dir/etc/init.d/S99msd-zram"

test -x "$target_dir/etc/init.d/S98msd-ready"
test -f "$target_dir/etc/fstab"
for mountpoint in /proc /sys /run /tmp; do
	if ! grep -Eq "^[^#[:space:]]+[[:space:]]+${mountpoint}[[:space:]]" "$target_dir/etc/fstab"; then
		printf 'Required mount point is missing from target fstab: %s\n' "$mountpoint" >&2
		exit 1
	fi
done

python3 "$(dirname "$0")/tools/openssl-c1.py" "$target_dir/etc/ssl/openssl.cnf"
python3 "$(dirname "$0")/tools/prune-libgomp.py" "$target_dir"
python3 "$(dirname "$0")/tools/prune-kbd.py" "$target_dir"

keymap="$target_dir/usr/share/keymaps/tca8418_keypad_m5stack_keymap.map"
test -f "$keymap"
for keymaps in "$target_dir/usr/share/keymaps" "$target_dir/usr/share/kbd/keymaps"; do
	if [ -d "$keymaps" ]; then
		find "$keymaps" -depth ! -type d ! -path "$keymap" -delete
		find "$keymaps" -depth -type d -empty -delete
	fi
done
for data_dir in consolefonts consoletrans unimaps; do
	rm -rf "${target_dir:?}/usr/share/$data_dir" "${target_dir:?}/usr/share/kbd/$data_dir"
done

# libv4l-utils は meson の単一トグルで全 utility を target に入れるため、
# カメラ/IR の確認に必要な 4 本（v4l2-ctl, media-ctl, ir-keytable, ir-ctl）
# 以外のツールと RC keymap・udev rule をここで削除する。
for v4l_tool in cec-compliance cec-ctl cec-follower cx18-ctl decode_tm6000 \
	edid-decode ivtv-ctl rds-ctl v4l2-compliance v4l2-dbg v4l2-sysfs-path; do
	rm -f "${target_dir:?}/usr/bin/$v4l_tool" "${target_dir:?}/usr/sbin/$v4l_tool"
done
rm -rf "${target_dir:?}/lib/udev/rc_keymaps"
rm -f "${target_dir:?}/etc/rc_maps.cfg" \
	"${target_dir:?}/lib/udev/rules.d/70-infrared.rules"
if [ -d "$target_dir/lib/udev" ]; then
	find "$target_dir/lib/udev" -depth -type d -empty -delete
fi

mdev_conf="$target_dir/etc/mdev.conf"
test -f "$mdev_conf"
insert_mdev_rule() {
	rule="$1"
	if grep -Fqx -e "$rule" "$mdev_conf"; then
		return
	fi
	awk -v rule="$rule" '
		!inserted && /^\$MODALIAS=/ { print rule; inserted = 1 }
		{ print }
		END { if (!inserted) print rule }
	' "$mdev_conf" > "$mdev_conf.new"
	mv "$mdev_conf.new" "$mdev_conf"
}

insert_mdev_rule "-\$SUBSYSTEM=input;input/event[0-9]+ root:root 640 */usr/libexec/msd/cardputer-keyboard \"\$ACTION\" \"\$MDEV\""
insert_mdev_rule "-\$POWERFAIL=1 root:root 660 */usr/libexec/msd/powerfail-notify"

duplicate_mdev_rules="$(awk '
	/^[[:space:]]*($|#)/ { next }
	++seen[$0] == 2 { print $0 }
' "$mdev_conf" | sort)"
if [ -n "$duplicate_mdev_rules" ]; then
	printf 'Duplicate non-comment mdev.conf lines:\n%s\n' \
		"$duplicate_mdev_rules" >&2
	exit 1
fi

base_dir="${BASE_DIR:-}"
host_dir="${HOST_DIR:-}"
if [ -z "$base_dir" ] || [ -z "$host_dir" ]; then
	printf '%s\n' 'BASE_DIR and HOST_DIR must be set for update signing.' >&2
	exit 1
fi
busybox_config=
for candidate in "$base_dir"/build/busybox-*/.config; do
	if [ -f "$candidate" ]; then
		busybox_config="$candidate"
		break
	fi
done
if [ -z "$busybox_config" ]; then
	printf 'Buildroot BusyBox configuration is missing under %s/build.\n' "$base_dir" >&2
	exit 1
fi
required_busybox_options='
CONFIG_DESKTOP=y
CONFIG_FEATURE_DD_IBS_OBS=y
CONFIG_FEATURE_MD5_SHA1_SUM_CHECK=y
CONFIG_FEATURE_SWAPON_PRI=y
'
while IFS= read -r busybox_option; do
	if [ -z "$busybox_option" ]; then
		continue
	fi
	if ! grep -Fxq "$busybox_option" "$busybox_config"; then
		printf 'Required BusyBox option is missing: %s\n' "$busybox_option" >&2
		exit 1
	fi
done <<EOF
$required_busybox_options
EOF

host_openssl="$host_dir/bin/openssl"
if [ ! -x "$host_openssl" ]; then
	printf 'Required Buildroot host OpenSSL binary is missing: %s\n' "$host_openssl" >&2
	exit 1
fi

if [ -n "${MSD_UPDATE_PUBLIC_KEY:-}" ]; then
	key_origin=release
	test "$(sed -n '1p' "$MSD_UPDATE_PUBLIC_KEY")" = '-----BEGIN PUBLIC KEY-----'
	if grep -q 'PRIVATE KEY' "$MSD_UPDATE_PUBLIC_KEY"; then
		printf '%s\n' 'Public-key input must not contain a private key.' >&2
		exit 1
	fi
	"$host_openssl" pkey -pubin -in "$MSD_UPDATE_PUBLIC_KEY" -text -noout |
		grep -q '^ED25519 Public-Key:'
	public_key="$("$host_openssl" pkey -pubin -in "$MSD_UPDATE_PUBLIC_KEY" -pubout)"
	if [ -n "${MSD_UPDATE_SIGNING_KEY:-}" ]; then
		private_public="$("$host_openssl" pkey -in "$MSD_UPDATE_SIGNING_KEY" -passin pass: -pubout)"
		if [ "$public_key" != "$private_public" ]; then
			printf '%s\n' 'Update public and private keys do not match.' >&2
			exit 1
		fi
	fi
elif [ -n "${MSD_UPDATE_SIGNING_KEY:-}" ]; then
	signing_key="$MSD_UPDATE_SIGNING_KEY"
	key_origin=release
else
	signing_key="$base_dir/msd-update-dev-key.pem"
	key_origin=development
	if [ ! -f "$signing_key" ]; then
		printf '%s\n' 'WARNING: generating a development update-signing key; use MSD_UPDATE_SIGNING_KEY for releases.' >&2
		(
			umask 077
			"$host_openssl" genpkey -algorithm Ed25519 -out "$signing_key"
		)
	else
		printf '%s\n' 'WARNING: using the development update-signing key; do not ship this key for releases.' >&2
	fi
	chmod 0600 "$signing_key"
fi
if [ -z "${MSD_UPDATE_PUBLIC_KEY:-}" ]; then
	test -r "$signing_key"
fi

legacy_update_dir="$target_dir/etc/msd-update"
if [ -d "$legacy_update_dir" ]; then
	rm -f "$legacy_update_dir/update-key.pem" \
		"$legacy_update_dir/version" \
		"$legacy_update_dir/key-origin"
	rmdir "$legacy_update_dir"
fi
update_trust_dir="$target_dir/usr/share/msd-update"
mkdir -p "$update_trust_dir"
if [ -n "${MSD_UPDATE_PUBLIC_KEY:-}" ]; then
	"$host_openssl" pkey -pubin -in "$MSD_UPDATE_PUBLIC_KEY" -pubout \
		-out "$update_trust_dir/update-key.pem"
else
	"$host_openssl" pkey -in "$signing_key" -pubout \
		-out "$update_trust_dir/update-key.pem"
fi
printf '%s\n' "$key_origin" > "$update_trust_dir/key-origin"

# msd-update refuses bundles older than this number unless --allow-downgrade is given.
update_version="${MSD_UPDATE_VERSION:-}"
if [ -z "$update_version" ]; then
	update_version="$(git -C "$(dirname "$0")" log -1 --format=%ct HEAD 2>/dev/null || true)"
fi
case "$update_version" in
	'' | *[!0-9]* | 0?*)
		printf 'Cannot determine the update version (%s); set MSD_UPDATE_VERSION to a decimal integer\n' \
			"$update_version" >&2
		exit 1
		;;
esac
if [ "${#update_version}" -gt 18 ]; then
	printf 'MSD_UPDATE_VERSION must have at most 18 digits: %s\n' "$update_version" >&2
	exit 1
fi
printf '%s\n' "$update_version" > "$update_trust_dir/version"

"$(dirname "$0")/tools/write-version-info.sh" "$target_dir" "$(dirname "$0")"

"$(dirname "$0")/tools/sign-modules.sh" "$target_dir" "$base_dir/build/linux-custom"
sh "$(dirname "$0")/tools/prune-module-indexes.sh" "$target_dir"

# SquashFS sort: Buildroot does not expose mksquashfs -sort because COMP_OPTS is
# calculated without prompting, so a wrapper in $HOST_DIR injects the file
# order measured in QEMU (docs/experiments/2026-10-25-qemu-boot-read-order.md).
# The @KVER@ token is resolved to the actual kernel version for each build.
sort_src="$(dirname "$0")/squashfs-sort.txt"
sort_file="$base_dir/build/squashfs-sort.resolved"
krel_file="$base_dir/build/linux-custom/include/config/kernel.release"
if [ -f "$sort_src" ] && [ -f "$krel_file" ]; then
	sed "s|@KVER@|$(cat "$krel_file")|g" "$sort_src" > "$sort_file"
fi
mksq="${HOST_DIR:?HOST_DIR must be set}/bin/mksquashfs"
if [ -f "$sort_file" ] && [ -f "$mksq" ]; then
	[ -f "$mksq.orig" ] || mv "$mksq" "$mksq.orig"
	printf '#!/bin/sh\nexec "%s" "$@" -sort "%s"\n' "$mksq.orig" "$sort_file" > "$mksq"
	chmod 755 "$mksq"
elif [ -f "$mksq.orig" ]; then
	mv "$mksq.orig" "$mksq"
fi
