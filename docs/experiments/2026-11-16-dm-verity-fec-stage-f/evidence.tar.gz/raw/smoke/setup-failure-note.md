# Fの実行環境で止まった試行

最初のlaunchはcontainerへhost UID 1001をそのまま指定し、runnerの出力directory作成でPermissionErrorとなりました。QEMU起動・caseのbootは0回で、出力directoryも生成されていません。元のstderrとdriver wall（0.575秒）はsetup-failure.logとsetup-failure-time.logに保存しました。正式反復やsmokeのboot数には含めません。

DockerのSecurityOptionsにname=rootlessを確認しました。hostのclone所有者はUID 1001、mode 0755です。container UID 0の診断では次のuid_mapが返り、/workの所有者は0、os.access('/work', os.W_OK)は成功しました。

```text
         0       1001          1
         1     231072      65536
```

container UID 1001はhost UID 1001ではなく従属UIDへ写るため、初回指定では所有者のwrite権限を得られません。container UID 0を指定してhost所有者に合わせ、fresh出力先へ再実行しました。host rootの利用、権限や所有者の変更、入力・期待・実行scriptの修正はしていません。これは実験条件や判定の変更ではなくlaunch環境の訂正です。
