import csv
import hashlib
import io
import json
import math
from pathlib import Path
import re
import statistics
import tarfile

repo = Path('/home/devin-worker/e34doc/MSD-Linux')
run = Path('/home/devin-worker/b3-followup-b4')
base = Path('/home/devin-worker/b3-followup-hostdry/output-host-dry/cases-b')
records, files = [], {}
for phase, directory, count in (('clean-smoke', 'output-b4-clean', 2),
                               ('smoke', 'output-b4-smoke', 8), ('formal', 'output-b4-formal', 50)):
    trials = sorted((run / directory).glob('*/functional.json'))
    assert len(trials) == count
    for path in trials:
        case, repeat = path.parent.name.rsplit('-boot', 1)
        result = json.loads(path.read_text())
        assert math.isfinite(result['wall_seconds']) and result['wall_seconds'] > 0
        assert result['stop_reason'] != 'timeout'
        serial = (path.parent / 'serial.log').read_bytes()
        assert hashlib.sha256(serial).hexdigest() == result['serial_sha256']
        text = serial.decode(errors='replace')
        rs = [int(v) for v in re.findall(r'B3_RS[^\n]*result=(-?\d+)', text)]
        assert text.count('B3_GUARD ') == result['guard_hits']
        result.update(phase=phase, case=case, repeat=int(repeat), rs_calls=len(rs),
                      rs_corrected=sum(v > 0 for v in rs),
                      ram_before_guard=(0 <= text.find('B3_RAM_BEGIN') < text.find('B3_GUARD')))
        records.append(result)
        for raw in sorted(path.parent.iterdir()):
            if raw.is_file():
                assert raw.suffix != '.img'
                files[f'raw/{phase}/{path.parent.name}/{raw.name}'] = raw.read_bytes()
for case in sorted(p.name for p in base.iterdir() if (p / 'case.json').exists()):
    trials = [r for r in records if r['phase'] == 'formal' and r['case'] == case]
    assert sorted(r['repeat'] for r in trials) == list(range(5))
    if 'clean' in case:
        assert all(r['functional_pass'] for r in trials)
    for name in ('case.json', 'inputs.json', 'qemu-extra-append.txt'):
        files[f'inputs/{case}/{name}'] = (base / case / name).read_bytes()
for path in sorted((run / 'board/cardputerzero/tools/bench/dm-verity-fec').iterdir()):
    if path.suffix in ('.py', '.sh', '.tsv'):
        assert path.read_bytes() == (repo / 'board/cardputerzero/tools/bench/dm-verity-fec' / path.name).read_bytes()
        files['sources/' + path.name] = path.read_bytes()
for name in ('clean', 'smoke', 'formal', 'formal-time'):
    files['logs/' + name + '.log'] = Path('/home/devin-worker/handoff/p1c4-b4-' + name + '.log').read_bytes()
files['host-all-ready.json'] = (run / 'host-all-ready.json').read_bytes()
kernel = Path('/home/devin-worker/b3-followup-build/output-b3-kernel')
for name in ('.config', 'b3-trace.patch', 'b3-source-hashes.json', 'drivers/md/dm-verity-fec.c',
             'drivers/md/dm-verity-target.c', 'COPYING', 'LICENSES/preferred/GPL-2.0'):
    files['kernel/' + name] = (kernel / name).read_bytes()
files['payload/initramfs.cpio.gz'] = (base / 'B-clean-ram/initramfs.cpio.gz').read_bytes()
files['archive-script.py'] = Path(__file__).read_bytes()
target = repo / 'docs/experiments/2026-11-15-dm-verity-fec-stage-b'
target.mkdir()
columns = ['phase', 'case', 'repeat', 'expected', 'functional_pass', 'wall_seconds',
           'recovered_against_eio', 'guard_hits', 'rs_calls', 'rs_corrected', 'ram_before_guard',
           'readall_complete', 'ram_read_success', 'ready', 'login', 'panic', 'restart',
           'stop_reason', 'exit_status', 'host_terminated_after_observation', 'final_process_status', 'serial_sha256']
with target.with_suffix('.csv').open('x', newline='') as stream:
    writer = csv.DictWriter(stream, fieldnames=columns, extrasaction='ignore', lineterminator='\n')
    writer.writeheader()
    writer.writerows(records)
files['results.csv'] = target.with_suffix('.csv').read_bytes()
summary = {}
for case in sorted({r['case'] for r in records}):
    trials = [r for r in records if r['phase'] == 'formal' and r['case'] == case]
    walls = [r['wall_seconds'] for r in trials]
    summary[case] = dict(wall=walls, median=statistics.median(walls), minimum=min(walls), maximum=max(walls),
                         matches=sum(r['functional_pass'] for r in trials),
                         recovered=sum(r['recovered_against_eio'] for r in trials),
                         guards=sorted({r['guard_hits'] for r in trials}),
                         rs_corrected=sorted({r['rs_corrected'] for r in trials}),
                         ram_before_guard=all(r['ram_before_guard'] for r in trials))
files['summary.json'] = (json.dumps(summary, indent=2) + '\n').encode()
files['MANIFEST.json'] = (json.dumps({k: hashlib.sha256(v).hexdigest() for k, v in files.items()},
                                    indent=2, sort_keys=True) + '\n').encode()
archive = target / 'evidence.tar.gz'
with tarfile.open(archive, 'w:gz') as tar:
    for name, content in sorted(files.items()):
        info = tarfile.TarInfo(name)
        info.size, info.mtime = len(content), 0
        tar.addfile(info, io.BytesIO(content))
with tarfile.open(archive) as tar:
    for name, expected in json.load(tar.extractfile('MANIFEST.json')).items():
        assert hashlib.sha256(tar.extractfile(name).read()).hexdigest() == expected
formal = [r for r in records if r['phase'] == 'formal']
print(f'ok - 60 unique trials (10 smoke + 50 formal); {sum(r["functional_pass"] for r in formal)} formal matches; no timeout or clean failure')
print('formal_boot_wall_sum=' + str(sum(r['wall_seconds'] for r in formal)))
print('formal_host_terminated=' + str(sum(r['host_terminated_after_observation'] for r in formal)))
print('archive_sha256=' + hashlib.sha256(archive.read_bytes()).hexdigest())
print('archive_bytes=' + str(archive.stat().st_size))
print('archive_members=' + str(len(files)))
print(json.dumps(summary, indent=2))
