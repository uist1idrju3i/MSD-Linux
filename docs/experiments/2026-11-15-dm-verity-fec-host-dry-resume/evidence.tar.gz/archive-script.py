import csv
import hashlib
import io
import json
from pathlib import Path
import tarfile

repo = Path('/home/devin-worker/e34doc/MSD-Linux')
run = Path('/home/devin-worker/b3-followup-b4')
target = repo / 'docs/experiments/2026-11-15-dm-verity-fec-host-dry-resume'
target.mkdir()
files = {}
for path in sorted((run / 'output-d2').rglob('*')):
    if path.is_file() and path.suffix in ('.json', '.env', '.log'):
        files['dry/' + str(path.relative_to(run / 'output-d2'))] = path.read_bytes()
for path in sorted((run / 'board/cardputerzero/tools/bench/dm-verity-fec').iterdir()):
    if path.suffix in ('.py', '.sh', '.tsv'):
        files['sources/' + path.name] = path.read_bytes()
files['host-all-ready.json'] = (run / 'host-all-ready.json').read_bytes()
files['fixtures.log'] = Path('/home/devin-worker/handoff/p1c4-d2-fixtures.log').read_bytes()
files['generate.log'] = Path('/home/devin-worker/handoff/p1c4-d2-generate.log').read_bytes()
checks = json.loads((run / 'output-d2/host-check.json').read_text())
rows = []
for name, values in checks['checks'].items():
    if name.startswith('D-'):
        p = json.loads((run / 'output-d2' / name / 'case.json').read_text())['parameters']
        rows.append(['recovery', name, p['hash_alg'], p['fec_roots'], '', '', values['outcome'],
                     values['decoded_equals_clean'], '', values['clean_sha256'], values['decoded_sha256']])
    elif name.endswith('-veritysetup'):
        for value in values:
            rows.append(['cli', value['name'], 'sha256', name.split('-r')[1].split('-')[0],
                         '', '', 'observation-only', '', value['status'], '', ''])
    elif isinstance(values, list):
        for index, value in enumerate(values):
            rows.append(['boundary', name + '-' + str(index), name.split('-')[1], value['roots'],
                         value['errors'], value['erasures'], value['outcome'], '', '', '', ''])
csv_path = target.with_suffix('.csv')
with csv_path.open('x', newline='') as stream:
    writer = csv.writer(stream, lineterminator='\n')
    writer.writerow(['kind', 'case', 'hash', 'roots', 'errors', 'erasures', 'outcome',
                     'decoded_equals_clean', 'cli_status', 'clean_sha256', 'decoded_sha256'])
    writer.writerows(rows)
files['results.csv'] = csv_path.read_bytes()
with tarfile.open(repo / 'docs/experiments/2026-11-15-dm-verity-fec-host-dry/evidence.tar.gz') as old:
    common = old.extractfile('payload/base-pack.img').read()
rebuild = {}
for path in sorted((run / 'output-d2').glob('format-*/rootfs.img')):
    p = dict(line.split('=', 1) for line in (path.parent / 'params.env').read_text().splitlines() if '=' in line)
    data = int(p['data_blocks']) * 4096
    packed = path.read_bytes()
    assert packed[:data] == common[:data]
    suffix = packed[data:]
    name = path.parent.name
    files['payload/' + name + '-suffix.bin'] = suffix
    digest = hashlib.sha256(packed).hexdigest()
    assert hashlib.sha256(common[:data] + suffix).hexdigest() == digest
    rebuild[name] = dict(data_bytes=data, sha256=digest)
files['payload/rebuild.json'] = (json.dumps(rebuild, indent=2) + '\n').encode()
files['archive-script.py'] = Path(__file__).read_bytes()
manifest = {name: hashlib.sha256(content).hexdigest() for name, content in files.items()}
files['MANIFEST.json'] = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
archive = target / 'evidence.tar.gz'
with tarfile.open(archive, 'w:gz') as tar:
    for name, content in sorted(files.items()):
        info = tarfile.TarInfo(name)
        info.size, info.mtime = len(content), 0
        tar.addfile(info, io.BytesIO(content))
with tarfile.open(archive) as tar:
    for name, expected in manifest.items():
        assert hashlib.sha256(tar.extractfile(name).read()).hexdigest() == expected
    assert list(csv.reader(io.StringIO(tar.extractfile('results.csv').read().decode()))) == list(csv.reader(csv_path.open()))
print(f'ok - {len(manifest)} members hash-verified; 18 recovery, 36 boundary and 12 CLI records; six D packs reconstructed byte-for-byte')
print('archive_sha256=' + hashlib.sha256(archive.read_bytes()).hexdigest())
print('archive_bytes=' + str(archive.stat().st_size))
