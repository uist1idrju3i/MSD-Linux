# /dataのinode table同期初期化

- 状態: 実施中
- 日付: 2026-11-17
- 担当: Devin
- 関連: [従来の帰属測定](2026-11-15-data-first-boot-writes.md)、[書き込み台帳](../design/write-policy.md)

## 目的と仮説

`noinit_itable`でmountしてからonline growすると、新規groupのinode tableがresize中に同期初期化されるという固定kernelのsource上の判断をQEMUで確かめます。fallback mkfsにも `lazy_itable_init=0,lazy_journal_init=0` を指定します。総書き込み量をなくす変更ではありません。

## 採否の基準（測定前に記録）

変更後の3回全てで、grow後の全groupに `ITABLE_ZEROED` があり、guestのprocess一覧にext4lazyinitがなく、最初の120秒idle中のp7書き込みが0 sectorなら同期化を採用します。RAM controlとdisk positive controlがrunnerの検査に合格することも条件です。progress未実装と既存SDの未初期化tableは採否とは別の残課題です。

## 条件と手順

- 基準: `origin/main` = `f132f3c4e3c1165632e4549834a930bd242e5afc`。
- 変更後: 同じ基準にS02msd-dataのmount・fallback formatとfstabの変更だけを適用します。
- warm buildの `output-openssl-lts` をdefconfigで更新し、mainと変更後を順にbuildします。以前のSquashFS sort wrapperも両条件で共通です。
- 同じwrite-inventory runnerを使い、base variant相当の未拡張imageを1 GiBに広げます。各条件3回、idleは120秒を3窓。bootとidle1を主評価とし、idle2・3も保存します。
- 生ログは `output-data-sync-itable` に保持し、大きなimageはcommitしません。版・hash・実行command・失敗試行・保存方法は完了後に追記します。

```sh
docker/msd-dev sh -c 'make -C vendor/buildroot BR2_EXTERNAL=/work O=/work/output-openssl-lts msd_cardputerzero_defconfig && make -C output-openssl-lts -j8'
# 条件ごとにimagesと.configをinput-before/input-afterへ保存してから各3回:
docker/msd-dev python3 board/cardputerzero/tools/bench/write-inventory/run.py \
  --output output-data-sync-itable/input-before \
  --run-dir output-data-sync-itable/runs/before-r1 \
  --variant before --seconds 120 --windows 3
```

## 未確認の点

実SDの時間・FTL・電源断、LCD上の表示、既存SDの未初期化tableの完了処理は対象外です。QEMUのsector値を実機の書き込み量と扱いません。
