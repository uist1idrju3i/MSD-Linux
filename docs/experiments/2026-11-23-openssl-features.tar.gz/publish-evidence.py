import csv
import hashlib
import io
import json
from pathlib import Path
import re
import tarfile

root = Path.cwd()
base = root / 'output-openssl-features-r1'
destination = root / 'docs/experiments/2026-11-23-openssl-features.tar.gz'
files = {}

def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            digest.update(block)
    return digest.hexdigest()

def add(path, name=None):
    assert path.is_file(), path
    name = name or str(path.relative_to(base))
    assert name not in files, name
    files[name] = path

for directory in ('cold-pair-01', 'probe-01', 'analysis-01', 'c1-host-probe-01'):
    path = base / directory
    for item in path.rglob('*') if directory in ('probe-01', 'c1-host-probe-01') else path.iterdir():
        if item.is_file() and item.suffix not in ('.squashfs', '.img') and item.stat().st_size < 6000000:
            add(item)
for variant in ('baseline', 'candidate'):
    add(base / 'cold-pair-01' / variant / '.config')
for pattern in ('*unit*.log', 'release-signing*.log', 'shellcheck*.log', '*-driver.log', '*host-final.log', '*test-final.log'):
    for item in base.glob(pattern):
        if str(item.relative_to(base)) not in files:
            add(item)
for name in ('consumer-audit.py', 'openssl-audit-1a133e1d092e405a8cd72e9fa09db1b2.json',
             'baseline-configdata.json', 'candidate-configdata.json', 'dev-image-id.txt',
             'dev-image-layers.txt', 'environment.json', 'primary-inputs.json',
             'protocol-observation.json', 'target-gcc-version.log', 'build-openssl-version.log',
             'buildroot-table-final.csv', 'publish-evidence.py'):
    add(base / name)
for item in (root / 'board/cardputerzero/tools/bench/openssl-features').iterdir():
    if item.is_file():
        add(item, 'runners/' + item.name)
add(root / 'board/cardputerzero/tools/bench/openssl-features-build.py', 'runners/openssl-features-build.py')
full_logs = {}
for variant in ('baseline', 'candidate'):
    path = base / 'cold-pair-01' / (variant + '-build.log')
    full_logs[str(path.relative_to(base))] = {'bytes': path.stat().st_size, 'sha256': sha(path)}
    tail = base / (variant + '-build-tail.log')
    with tail.open('x') as stream:
        stream.write('\n'.join(path.read_text().splitlines()[-160:]) + '\n')
    add(tail)
for name, path in files.items():
    if path.suffix in ('.log', '.json', '.txt', '.csv'):
        assert not re.search(rb'(?:Master-Key|Resumption PSK):\s*[0-9a-fA-F]{16}|BEGIN (?:[A-Z]+ )?PRIVATE KEY', path.read_bytes()), name
with (root / 'docs/experiments/2026-11-23-openssl-features.csv').open() as stream:
    rows = list(csv.DictReader(stream))
assert len(rows) == len({row['run_id'] for row in rows}) == 89
assert all(row['valid'] == 'true' for row in rows)
manifest = {'files': {name: {'bytes': p.stat().st_size, 'sha256': sha(p)} for name, p in sorted(files.items())}, 'full_build_logs_not_bundled': full_logs}
payload = (json.dumps(manifest, indent=2) + '\n').encode()
with tarfile.open(destination, 'x:gz') as archive:
    info = tarfile.TarInfo('manifest.json')
    info.size = len(payload)
    archive.addfile(info, io.BytesIO(payload))
    for name, path in sorted(files.items()):
        archive.add(path, arcname=name, recursive=False)
with tarfile.open(destination) as archive:
    for name, value in manifest['files'].items():
        assert hashlib.sha256(archive.extractfile(name).read()).hexdigest() == value['sha256'], name
print('Evidence archive:', len(files), 'files;', destination.stat().st_size, 'bytes; SHA-256', sha(destination))
print('Verified 89 CSV rows, all archive source hashes; no private keys or TLS session keys')
