import csv
import hashlib
import json
import re
import subprocess
import uuid
from pathlib import Path


out = Path(__file__).resolve().parent
repo = out.parent
root = out / 'root'
source = repo / 'output-integrity/build/libopenssl-3.5.9'


def sha(path):
    result = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            result.update(block)
    return result.hexdigest()


report = {'run_id': 'openssl-audit-' + uuid.uuid4().hex,
          'execution_commit': subprocess.check_output(
              ['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip(),
          'script_sha256': sha(Path(__file__)), 'elf': {}, 'text_hits': {},
          'regular_bytes': 0, 'openssl_files': {}, 'dlopen_imports': []}
tokens = ('libcrypto', 'libssl', 'openssl', 'OSSL_PROVIDER_', 'EVP_KDF_')
for path in sorted(root.rglob('*')):
    if path.is_symlink() or not path.is_file():
        continue
    name = str(path.relative_to(root))
    data = path.read_bytes()
    report['regular_bytes'] += len(data)
    if data.startswith(b'\x7fELF'):
        dynamic = subprocess.check_output(['readelf', '-d', str(path)], text=True)
        symbols = subprocess.check_output(['readelf', '-Ws', str(path)], text=True)
        report['elf'][name] = {
            'needed': re.findall(r'\(NEEDED\).*?\[(.*?)\]', dynamic),
            'openssl_imports': [line.strip() for line in symbols.splitlines()
                                if ' UND ' in line and '@OPENSSL_' in line]}
        if re.search(r'\b(dlopen|dlsym)@', symbols):
            report['dlopen_imports'].append(name)
    else:
        hits = [token for token in tokens if token.encode() in data]
        if hits:
            report['text_hits'][name] = hits
    if name in ('usr/bin/openssl', 'usr/lib/libcrypto.so.3',
                'usr/lib/libssl.so.3', 'usr/lib/ossl-modules/legacy.so'):
        report['openssl_files'][name] = {'bytes': len(data), 'sha256': sha(path)}

configdata = json.loads((out / 'local-openssl-configdata.json').read_text())
report['local_reference_configure_argv'] = configdata['config']['perlargv']
report['local_reference_disabled'] = configdata['disabled']
report['local_reference_crypto_matches_ci'] = (
    sha(repo / 'output-integrity/target/usr/lib/libcrypto.so.3') ==
    report['openssl_files']['usr/lib/libcrypto.so.3']['sha256'])
table = repo / 'docs/research/component-options/openssl-minimal-options.csv'
with table.open() as stream:
    rows = list(csv.DictReader(stream))
expected = set(configdata['disablables']) - {'crmf'}
actual = {row['option'] for row in rows if row['available_3_5_9'] == 'yes'}
report['option_coverage'] = {'expected': sorted(expected),
                             'missing': sorted(expected - actual),
                             'extra': sorted(actual - expected)}
kconfig = repo / 'vendor/buildroot/package/libopenssl/Config.in'
report['buildroot_symbols'] = re.findall(r'^config (\w+)', kconfig.read_text(), re.M)
inputs = [source / 'Configure', source / 'INSTALL.md', kconfig,
          repo / 'vendor/buildroot/package/libopenssl/libopenssl.mk',
          repo / 'board/cardputerzero/package-overrides.mk',
          repo / 'board/cardputerzero/tools/openssl-c1.py',
          repo / 'docs/design/rauc-update-contract.md',
          repo / 'configs/msd_cardputerzero_defconfig',
          out / 'artifact/images/buildroot-show-info.json',
          out / 'cryptsetup-2.8.7/lib/crypto_backend/crypto_openssl.c',
          out / 'cryptsetup-2.8.7/lib/setup.c', table]
report['inputs_sha256'] = {str(path.relative_to(repo)): sha(path) for path in inputs}
path = out / (report['run_id'] + '.json')
path.write_text(json.dumps(report, indent=2) + '\n')
print('audit:', path.name)
print('ELF:', len(report['elf']), 'regular bytes:', report['regular_bytes'])
print('OpenSSL ELF bytes:', sum(value['bytes'] for value in report['openssl_files'].values()))
print('Configure token coverage:', len(expected), 'missing=', len(expected - actual))
print('Local reference libcrypto matches CI:', report['local_reference_crypto_matches_ci'])
