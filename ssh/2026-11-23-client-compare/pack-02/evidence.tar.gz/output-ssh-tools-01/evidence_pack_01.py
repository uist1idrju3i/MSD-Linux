import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile

root = Path.cwd()
destination = root / 'output-ssh-data-01/ssh/2026-11-23-client-compare'
files = []
for directory in ['output-ssh-compare-01', 'output-ssh-measure-02']:
    base = root / directory
    files += [p for p in base.iterdir() if p.is_file() and p.suffix in ('.json', '.csv')]
    for variant in ('baseline', 'openssh', 'dropbear', 'putty'):
        work = base / variant
        files += [p for p in work.iterdir() if p.is_file() and p.suffix in ('.json', '.log')]
        config = work / 'buildroot/.config'
        if config.exists(): files.append(config)
    checkpoint = base / 'script-checkpoint/build.py'
    if checkpoint.exists(): files.append(checkpoint)
for index in range(1, 7):
    base = root / f'output-ssh-runtime-{index:02}'
    files += [p for p in base.iterdir() if p.is_file() and p.suffix in ('.log', '.json', '.csv', '.pub', '.py', '.sh')]
    files.append(base / 'root/init')
for directory in ('output-ssh-tools-01', 'output-ssh-inventory-05', 'output-ssh-summary-02'):
    files += [p for p in (root / directory).iterdir() if p.is_file() and p.suffix in ('.log', '.json', '.csv', '.txt', '.html', '.py')]
files.append(root / 'output-integrity/.config')
files += list((root / 'board/cardputerzero/tools/bench/ssh-client-compare').glob('*.py'))
files.append(root / 'board/cardputerzero/tools/bench/ssh-client-compare/guest.sh')
files = sorted(set(files))
manifest, payload = [], {}
for path in files:
    original = path.read_bytes()
    text = original.decode('utf-8', errors='strict')
    public = re.sub(r'https?://[^\s\x27"<>]+', lambda m: m[0].split('?', 1)[0] + '?[REDACTED QUERY]' if '?' in m[0] else m[0], text)
    public = re.sub(r'(?im)^set-cookie:.*$', 'set-cookie: [REDACTED]', public).encode()
    name = str(path.relative_to(root))
    payload[name] = public
    digest = lambda data: hashlib.sha256(data).hexdigest()
    manifest.append(dict(path=name, original_sha256=digest(original), public_sha256=digest(public),
                         original_bytes=len(original), public_bytes=len(public), redacted=original != public))
    assert digest(path.read_bytes()) == digest(original)
meta = json.dumps(manifest, indent=2).encode() + b'\n'
(destination / 'manifest.json').write_bytes(meta)
payload['manifest.json'] = meta
archive = destination / 'evidence.tar.zst'
assert not archive.exists()
with subprocess.Popen(['zstd', '-q', '-19', '-T2', '-o', str(archive)], stdin=subprocess.PIPE) as process:
    with tarfile.open(fileobj=process.stdin, mode='w|') as tar:
        for name, content in sorted(payload.items()):
            info = tarfile.TarInfo(name)
            info.size, info.mode, info.mtime = len(content), 0o644, 0
            tar.addfile(info, io.BytesIO(content))
    process.stdin.close()
    assert process.wait() == 0
with subprocess.Popen(['zstd', '-dq', '-c', str(archive)], stdout=subprocess.PIPE) as process:
    count = 0
    with tarfile.open(fileobj=process.stdout, mode='r|') as tar:
        for item in tar:
            assert tar.extractfile(item).read() == payload[item.name], item.name
            count += 1
    assert process.wait() == 0
assert count == len(payload)
result = dict(files=len(manifest), members=count, redacted=sum(p['redacted'] for p in manifest),
              archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(), archive_bytes=archive.stat().st_size)
(destination / 'verification.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(result))
