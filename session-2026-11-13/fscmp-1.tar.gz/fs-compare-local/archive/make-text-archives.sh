#!/bin/bash
# Usage: make-text-archives.sh RUNS_DIR OUT_DIR [EXCLUDE_GROUP...]
set -euo pipefail
runs=$1; out=$2; shift 2
exclude=" $* "
mkdir -p "$out"
group_of() {
	case "$1" in
		phase2-generated-unfiltered.tsv|phase2-plans.txt|phase2-*plan*.tsv|phase2-*input.tsv|phase2-*-live-guard.*|stackfix-smoke-plan.tsv)
			echo phase2-plans ;;
		phase2-analysis*) echo skip ;;
		phase2-smoke*) echo phase2-smoke ;;
		phase2-pilot*) echo phase2-pilot ;;
		phase2-j8-check*) echo phase2-j8-check ;;
		phase2-t4*) echo phase2-t4 ;;
		phase2-main-r2*) echo phase2-main-r2 ;;
		phase2-main*) echo phase2-main ;;
		phase2-stackfix*) echo phase2-stackfix ;;
		stackfix-smoke*) echo stackfix-smoke ;;
		phase1-r3-t2-retry*) echo phase1-r3-t2-retry ;;
		phase1-r3-t2*) echo phase1-r3-t2-invalid ;;
		phase1-r2*) echo phase1-r2 ;;
		t2fix-check*) echo t2fix-check ;;
		phase0*) echo phase0 ;;
		phase1-*) echo phase1-pilot-and-fixes ;;
		dedup-build-hardlink-*) echo skip ;;
		*) echo misc ;;
	esac
}
declare -A lists
tmp=$(mktemp -d)
for entry in $(ls "$runs"); do
	g=$(group_of "$entry")
	[ "$g" = skip ] && continue
	case "$exclude" in *" $g "*) continue ;; esac
	( cd "$runs" && find "$entry" -path '*/build' -prune -o -type f \
		! -name '*.img' ! -name '*.ext4' -print0 ) >>"$tmp/$g.list"
	lists[$g]=1
done
for g in "${!lists[@]}"; do
	( cd "$runs" && tar --null -T "$tmp/$g.list" --sort=name -cf - ) |
		nice -n 19 zstd -19 -T2 -q -o "$out/$g.tar.zst"
	( cd "$runs" && xargs -0 sha256sum <"$tmp/$g.list" ) | sort -k2 >"$out/$g.files.sha256"
done
( cd "$out" && sha256sum ./*.tar.zst | sort -k2 >SHA256SUMS )
rm -rf "$tmp"
