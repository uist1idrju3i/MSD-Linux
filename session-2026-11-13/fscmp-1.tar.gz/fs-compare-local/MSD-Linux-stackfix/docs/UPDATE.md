# A/B 更新と書き込み領域

管理者が行うRelease保護と鍵の準備は [署名鍵の設定手順](RELEASE-SIGNING.md)、設計・未実装部分・確認結果は [Releaseの調査](research/release-client/release-security.md) を参照してください。以下のmanifest署名は、配布用SD image全体の署名ではありません。

## パーティション構成

SD カードは MBR 形式です。p4 を拡張パーティションにし、p5 以降を論理パーティションとして配置します。

| 番号 | 用途 | 内容 |
|---|---|---|
| p1 | 起動選択、FAT 16 MiB | `autoboot.txt` と `bootcode.bin` |
| p2 | ブート A、FAT 64 MiB | p3 と同一の boot image。`config.txt` が A 用 cmdline を選択 |
| p3 | ブート B、FAT 64 MiB | p2 と同一の boot image。`config.txt` が B 用 cmdline を選択 |
| p4 | 拡張パーティション | p5〜p7 を格納 |
| p5 | rootfs A、SquashFS 256 MiB | A 用 rootfs |
| p6 | rootfs B、SquashFS 256 MiB | 初期イメージでは A と同一 |
| p7 | `/data`、ext4 64 MiB | 更新状態と永続データ |

p1 を初期ブートパーティションとして使い、`autoboot.txt` を置く構成です。BCM2837 のブートフロー資料では ROM が SD などのブート元から `bootcode.bin` を探すと説明されているため、これも p1 に含めます。公式資料の A/B 例は、p1 に `autoboot.txt`、p2/p3 に firmware と kernel を置いています。ブート可能な FAT パーティションには `start.elf` が必要とされるため、p2/p3 に `start_cd.elf` と `fixup_cd.dat` を配置する設計です。

p1 には `autoboot.txt` と `bootcode.bin` の2ファイルだけを置きます。公式資料は p1 に追加の firmware ファイルが必要とは明記していません。p1 に bootcode を置く根拠と資料の限界は上記のとおりで、実機での確認が必要です。

初期の `autoboot.txt` は次のとおりです。

```ini
[all]
tryboot_a_b=1
boot_partition=2
[tryboot]
boot_partition=3
```

資料では `boot_partition` は 1 始まりで、`autoboot.txt` は初期ブートパーティションに置く仕様です。p2/p3 の共通 boot image に A/B 両方の cmdline を含め、`config.txt` の `[boot_partition=2]` / `[boot_partition=3]` 条件で選択します。A は `/dev/mmcblk0p5`、B は `/dev/mmcblk0p6` を指す設定です。Raspberry Pi の資料にも、同じ boot image を使い、`config.txt` の条件で cmdline ファイルを選ぶ例があります。

参照資料は Raspberry Pi の [autoboot.txt と A/B 更新](https://www.raspberrypi.com/documentation/computers/configuration.html#autoboot-txt) と、リポジトリ外にある `documentation/asciidoc/computers/raspberry-pi/bootflow-legacy.adoc` です。後者は BCM2837 の ROM がブート元を調べて `bootcode.bin` を読み込む流れを説明していますが、「最初の FAT パーティション」と明記した記述は確認できませんでした。p1 への配置は、初期ブートパーティションを selector とし、SD の先頭に置く構成として採用しています。実機での起動確認が必要です。

## 更新する前に

**現行実装を説明する開発用手順です。実機のtryboot・自動復帰・更新中の電源断は未確認です。** [導入手順](INSTALL.md) のSD全体の書き込みはA/B更新とは異なり、`/data` も失います。

- `/data` の重要なデータを別の媒体へ退避し、安定した電源と復旧用のPC・カードを用意します。A/Bは共有データや設定の変更まで巻き戻しません。
- 端末に配置された公開鍵に対応する `msd-update-bundle.tar` を用意します。自分で構築した場合は `output/images/` に生成されます。現行の `msd-cardputerzero-build` artifactはSD image等を保存しますが、更新tarは保存しません。Releaseからの自動ダウンロードも未実装です。
- `cat /usr/share/msd-update/key-origin` で由来を確認します。`development` は開発用鍵であり、本番配布の認証ではありません。未指定なら別のbuild出力で別の開発鍵になる場合があり、対応しないbundleは既存端末で拒否されます。
- 公開鍵のDER表現のSHA-256を、信頼する発行者の公開鍵fingerprintと照合します。秘密鍵を端末にコピーせず、署名エラー時に公開鍵をbundle側のものへ差し替えたり、検証を迂回したりしません。

  ```sh
  openssl pkey -pubin -in /usr/share/msd-update/update-key.pem -outform DER |
      openssl dgst -sha256
  ```

- bundleを手元で `/data/update.tar` に配置し、`df -h /data /tmp` で空き領域を確認します。現在はtarを一時ディレクトリへ展開して検証するため、保存先だけでなく通常tmpfsの `/tmp` にも展開分が必要です。512 MiB機で最大slot相当のbundleが扱える保証ではありません。

公開SemVerと、現行manifestの10進整数の更新番号は別です。対応は承認済みで、内部更新番号はtag commitのcommit時刻です。対応表は[Release対応表](releases/README.md)を参照してください。SemVer文字列を現行 `MSD_UPDATE_VERSION` に渡しません。

## 更新の流れ

`msd-update status` は `/proc/device-tree/chosen/bootloader/partition` と `tryboot` を読み、現在の A/B スロットと試験起動中かどうかを表示します。値は 32 bit big-endian です。BusyBox の `od` には `--endian=big` がないため、`od -An -v -t x1` でバイト列を読み、16 進数として変換します。

post-image スクリプトは `output/images/msd-update-bundle.tar` を生成します。更新 bundle は次の 4 ファイルをルートに含む tar アーカイブです。`manifest.sig` は `manifest` の Ed25519 署名です。

```text
rootfs.squashfs
boot.vfat
manifest
manifest.sig
```

`manifest` の 1 行目は `version <番号>` で、2 行目以降は `sha256sum` と同じ形式の各イメージの SHA-256 です。番号は 10 進の整数とし、build ごとに増加させます。post-build では環境変数 `MSD_UPDATE_VERSION` を使います。未指定時は本リポジトリの HEAD の commit 時刻（UNIX 時間）を採番に使う仕様です。同じ番号の保存先は rootfs の `/usr/share/msd-update/version` です。

```text
version 1761400000
<SHA-256>  rootfs.squashfs
<SHA-256>  boot.vfat
```

同一の `boot.vfat` を p2 と p3 のどちらにも使います。両方の cmdline を含み、選択中の boot partition に応じて root を p5 または p6 に切り替えます。`install` はこの boot image を非アクティブなブートパーティションへそのまま転送するため、同じ bundle を A/B のどちらにも適用可能です。

端末の管理権限で一行ずつ実行します。`install` が正常終了しなければ止め、`try` は実行しません。ほかの更新処理と同時に実行しないでください。

```sh
msd-update status
msd-update install /data/update.tar
msd-update try
```

`install` は稼働中の rootfs/boot を維持し、非アクティブスロットを更新先にする処理です。bundle のメンバー名、署名、SHA-256 を確かめ、`manifest` の番号を稼働中の `/usr/share/msd-update/version` と比べます。番号が稼働中より小さい bundle と、番号のない bundle は、既定では書き込まずに拒否します。古いバージョンへ戻すときだけ、`--allow-downgrade` を付けてください。番号が同じ bundle は受け入れる仕様です。確認後、`dd conv=fsync` でイメージを転送します。同じバイト数を読み戻し、ハッシュが一致することを確かめます。双方の検証後、`/data/msd-update/installed` に試験対象を記録する流れです。

`try` は検証済み更新の状態ファイルと `autoboot.txt` のスロット指定が一致する場合だけ、`reboot '0 tryboot'` を実行します。firmware は p1 の `[tryboot]` で指定されたブート領域を一度だけ選びます。次回の通常起動では tryboot が解除されるため、試験中に再起動しても未コミットの更新へ固定されません。

tryboot 中に rootfs が SquashFS、`/data` が ext4 でマウント済みか、`MSD/Linux ready` marker があるかを確認するのが `S99msd-health` の役割です。条件成立後は `msd-update commit` が p1 を読み書き可能でマウントし、`autoboot.txt.new` を書いてから `autoboot.txt` への rename を実行します。BusyBox の `fsync` applet で新しいファイルと p1 のディレクトリを同期し、rename 後に p1 と更新状態のディレクトリを同期します。確認に失敗すると設定を変えずに通常再起動し、旧スロットに戻る設計です。早期起動が停止した場合に備え、BusyBox watchdog を `-T 15 -t 5` で起動します。

## 試験起動後と失敗時

`S99msd-health` は前述の条件が成立すると自動でcommitします。LCD・キーボード・Wi-Fi等の全機能を検査する処理でも、利用者の承認を待つ処理でもありません。成功した場合は、次を確認します。

```sh
msd-update status
cat /data/msd-update/committed
test ! -e /data/msd-update/installed
```

`committed` の値はboot partitionの番号2または3です。`status` の `partition` と一致するか確認します。`commit` は起動時のDTを変更しないため、その起動中は `tryboot=1` が続きます。通常の `reboot` 後も新しいslotで起動し、`tryboot=0` か確認します。現在の自動health処理を無効にして手動commitする手順は案内しません。

未commitで通常再起動すると旧スロットへ戻す設計です。ただし、起動停止そのものをfirmwareが検出して即座に再起動する保証ではありません。watchdogが有効になる前の停止や実SDの障害は、電源操作や別媒体での復旧が必要になり得ます。旧slotへ戻っても共有の `/data` は以前の内容に戻りません。失敗した状態、console出力、更新番号、鍵fingerprintを保存し、検証やDTの読み取りを試験用の環境変数で迂回しません。

`--allow-downgrade` は復旧のための例外であり、通常の手順には入れません。現行仕様は稼働中より小さい番号と番号なしを既定で拒否し、同じ番号は許可します。耐改ざん領域で記録するanti-rollbackではなく、全SDの交換や稼働中の状態の巻き戻しを防ぐ仕組みではありません。

## 書き込み可能な領域

rootfs は Zstandard 圧縮 SquashFS で読み取り専用です。fstab が tmpfs としてマウントするのは `/dev/shm`、`/tmp`、`/run` です。`/var` 自体は tmpfs ではありません。Buildroot の skeleton では `/var/cache`、`/var/log`、`/var/spool`、`/var/tmp` が `/tmp` 配下を指し、`/var/lock`、`/var/run` が `/run` 配下を指します。`/var/lib/misc` も `/tmp` 配下を指します。

起動時は p7 の ext4 を `fsck.ext4 -p` で確認します。superblock magic がなく、パーティション全体がゼロの場合だけ `mkfs.ext4 -b 4096` で初期化する仕様です。未知の非空パーティションはフォーマットせず、起動を停止する設計です。初期化または fsck の後に `/data` へマウントします。新規 filesystem のブロックサイズは 4 KiB です。既存デバイスの 1 KiB filesystem は再フォーマットも移行もせず、新しい mount option でそのまま使用します。mount option は `noatime,nodev,nosuid,data=ordered,errors=remount-ro` です。`commit=` は kernel の既定値を使います。

`/etc` は overlayfs で構成します。`/etc` と `/data/etc` を lower layer、`/run` 上の tmpfs を upper/work layer とするため、通常の `/etc` への変更は再起動で消えます。再起動後も残す設定ファイルは `/data/etc` に保存してください。サービスがその場所を直接参照しない場合は、個別の bind mount などを追加します。更新鍵、鍵の由来、最低更新番号は `/usr/share/msd-update/` に置きます。このディレクトリーは `/etc` を対象とする overlay の外にあるため、`/data/etc` の内容で上書きされません。

p7は初期イメージで64 MiBです。現在は `S02msd-data` が `msd-data-grow` を呼び、p4とp7の末尾をディスク末尾へ広げ、`resize2fs` を実行する実装があります。失敗時はエラーを出し、`/data` をマウントしたまま続けます。[構築手順](BUILD.md#現在の検証状況) には拡大imageでのローカルQEMU確認を記録していますが、実機での拡張は未確認です。以前の「自動拡張は未実装」という記述を訂正しました。

## 検証範囲

GitHub Releasesを端末から取得して更新するclientは未実装です。下表は既存A/B処理の検証範囲であり、新しい配信・metadata検証を含みません。候補比較と実装前の条件は[端末自己更新の設計](research/release-client/README.md)にあります。

| 方法 | 確認する内容 | 制約 |
|---|---|---|
| `tests/msd-update/run.sh` | DT 値の読み取り、commit の拒否条件、2↔3 の切り替え、bundle の署名と SHA-256 の検証、番号の比較と `--allow-downgrade`、非アクティブスロットへの書き込み | 一時ディレクトリ上のホストテスト。実デバイスの電源断耐性は確認しない |
| `board/cardputerzero/qemu/test-ab.sh` | QEMU で p6 を rootfs として起動し、marker と login prompt を確認 | 検出後に QEMU を停止する。GPU firmware の tryboot は実行されず、firmware の A/B 選択や自動フォールバックを確認しない |
| CardputerZero 実機 | firmware tryboot、rootfs 起動、watchdog、更新中の電源断、LCD・キーボード | 実機での検証が必要 |

## 電源スイッチに関する未対応事項

`vendor/m5stack-linux-dtoverlays/modules/CardputerZero/cardputerzero-v5-overlay.dts` の `powerfail` node は GPIO 6 の falling-edge IRQ を `cardputerzero,powerfail-suo` driver に渡します。確認した overlay には gpio-keys または userspace input event の定義がありません。driver の `powerfail_suo.c` は SysRq-U を実行し、backlight と disabled GPIO を扱います。既存 IRQ と競合する userspace handler は追加せず、入力イベントの仕様が確認できるまで TODO とします。
