#!/bin/sh
set -eu
cd "$(dirname "$0")/../.."
python3 -m unittest discover -s tests/check-kernel-fragment -p 'test_*.py'
