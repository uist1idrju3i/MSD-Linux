#!/bin/bash
set -euo pipefail

if [[ $# -ne 3 ]]; then
	printf 'Usage: %s <image> <log> <run-id>\n' "$0" >&2
	exit 2
fi

image=$1
log=$2
run_id=$3
qemu_pid=

cleanup()
{
	if [[ -n "$qemu_pid" ]] && kill -0 "$qemu_pid" 2>/dev/null; then
		kill -KILL "$qemu_pid" 2>/dev/null || true
		wait "$qemu_pid" 2>/dev/null || true
	fi
}
trap cleanup EXIT

append="msd.fscmp=F5:T2:${run_id} msd.fscmp.phase=verify"
QEMU_COPY_IMAGE=0 QEMU_MACHINE=raspi3b OUTPUT_DIR=/work/output-fscmp \
	QEMU_EXTRA_APPEND="$append" \
	/work/board/cardputerzero/qemu/run-qemu.sh "$image" >"$log" 2>&1 &
qemu_pid=$!
deadline=$((SECONDS + 300))

while ((SECONDS < deadline)); do
	if grep -aFq 'msd.fscmp: recovery_finished' "$log"; then
		printf 'qemu_verification_finished=yes\n'
		kill -KILL "$qemu_pid" 2>/dev/null || true
		wait "$qemu_pid" 2>/dev/null || true
		qemu_pid=
		exit 0
	fi
	if grep -aFq 'msd.fscmp: error=' "$log"; then
		tail -n 80 "$log" >&2
		exit 1
	fi
	if ! kill -0 "$qemu_pid" 2>/dev/null; then
		status=0
		wait "$qemu_pid" || status=$?
		qemu_pid=
		tail -n 80 "$log" >&2
		exit "$status"
	fi
	sleep 1
done

tail -n 80 "$log" >&2
exit 124
