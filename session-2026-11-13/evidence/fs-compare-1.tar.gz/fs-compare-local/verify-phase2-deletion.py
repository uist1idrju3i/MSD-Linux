from pathlib import Path
import csv
import hashlib
import json
import os
import subprocess
import sys
from datetime import datetime, timezone

base = Path('/home/devin-worker/fscmp')
runs = base / 'runs'
repo = base / 'data-branch'
misc = repo / 'fs-compare/misc'
state = base / 'phase2-deletion-before.json'
def rows(name):
    return list(csv.DictReader((misc / name).open(), delimiter='\t'))
def signature(path):
    s = path.stat()
    return [s.st_size, s.st_blocks * 512, s.st_mtime_ns, s.st_dev, s.st_ino]
def head():
    return subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True).strip()
def clean():
    assert not subprocess.check_output(['git', '-C', str(repo), 'status', '--porcelain'])
plan = (misc / 'deletion-candidates-phase2-20261112.txt').read_text().splitlines()
phase1 = set((misc / 'images-kept-20261111.txt').read_text().splitlines())
phase2 = {line.split('\t')[0] for line in (misc / 'images-kept-phase2-20261112.txt').read_text().splitlines()}
old_kept = [row for row in rows('images-inventory-20261111.tsv') if row['path'].split('/')[0] in phase1]
kept_paths = {row['path'] for row in old_kept} | {k + '/sdcard.img' for k in phase2}
assert len(phase2) == 26
assert hashlib.sha256((misc / 'deletion-candidates-phase2-20261112.txt').read_bytes()).hexdigest() == 'a25d4d30e472b8a61a0c2a861fa17f11965a77880b8ba02acd813ea747ef6df8'
clean()
if sys.argv[1] == 'before':
    assert head() == '5f75452b9c4507cac8db366e93ffe67a05f5deb8'
    coverage = rows('coverage-phase2-20261112.tsv')
    if '--text-checked' not in sys.argv:
        for row in coverage:
            with (runs / row['path']).open('rb') as f:
                assert hashlib.file_digest(f, 'sha256').hexdigest() == row['sha256'], row['path']
        print('ok - current text hashes unchanged:', len(coverage), flush=True)
    inventories = rows('images-inventory-phase2-20261112.tsv')
    for row in inventories + old_kept:
        s = (runs / row['path']).stat()
        sec, ns = divmod(s.st_mtime_ns, 10**9)
        stamp = datetime.fromtimestamp(sec, timezone.utc).strftime('%Y-%m-%dT%H:%M:%S') + f'.{ns:09d}0Z'
        assert [s.st_size, s.st_blocks * 512, stamp] == [int(row['apparent_bytes']), int(row['allocated_bytes']), row['mtime_utc']], row['path']
    print('ok - phase2 image size/allocation/mtime unchanged:', len(inventories), flush=True)
    builds = rows('build-inventory-phase2-20261112.tsv')
    for row in builds:
        build = runs / row['path']
        entries = [build]
        for root, dirs, files in os.walk(build):
            entries.extend(Path(root) / n for n in dirs + files)
        seen = set()
        apparent = allocated = 0
        for p in entries:
            s = p.lstat()
            key = (s.st_dev, s.st_ino)
            if key not in seen:
                seen.add(key)
                apparent += s.st_size
                allocated += s.st_blocks * 512
        assert [apparent, allocated] == [int(row['apparent_bytes']), int(row['allocated_bytes'])], row['path']
    assert len(plan) == len(set(plan)) == 2359
    expected = {row['path'] for row in builds} | {row['path'] for row in inventories if row['path'].endswith('/sdcard.img') and row['path'].split('/')[0] not in phase2}
    assert set(plan) == expected
    for p in plan:
        assert len(Path(p).parts) == 2 and not Path(p).is_absolute() and '..' not in Path(p).parts
        assert p.split('/')[0].startswith(('phase2-', 'stackfix-', 't2fix-'))
        assert (runs / p).exists() and not (runs / p).is_symlink()
        assert p not in kept_paths
    state.write_text(json.dumps({'head': head(), 'kept': {k: signature(runs / k) for k in kept_paths}}))
    print('ok - build capacities unchanged:', len(builds), '; safe deletion candidates:', len(plan), flush=True)
else:
    saved = json.loads(state.read_text())
    assert head() == saved['head']
    for k, sig in saved['kept'].items():
        assert signature(runs / k) == sig, k
    assert all(not os.path.lexists(runs / p) for p in plan)
    print('ok - kept images unchanged: phase2', len(phase2), '; phase0/1', len(old_kept), '; unique total', len(saved['kept']))
    print('ok - no deleted path remains:', len(plan))
    print('ok - data branch HEAD unchanged and working tree clean:', head())
