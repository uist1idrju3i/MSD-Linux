import json
import re
from pathlib import Path

repo = Path('/home/devin-worker/fscmp/data-branch')
runs = repo.parent/'runs'
misc = repo/'fs-compare/misc'
keep_path = misc/'images-kept-phase2-20261112.txt'
keep = {l.split('\t',1)[0]:set(l.split('\t',1)[1].split('；')) for l in keep_path.read_text().splitlines()}
before = set(keep)
for d in sorted(runs.iterdir()):
    if not d.is_dir() or not (d/'sdcard.img').exists():
        continue
    if d.name.startswith('phase2-j8-check-T4-sync-') or d.name.startswith('phase2-pilot-T4-sync-'):
        keep.setdefault(d.name,set()).add('本文のj8/j4比較表に掲載した計測器検証')
    if d.name.startswith('phase2-smoke-r2-smoke-') and any('-'+base+'-' in d.name for base in ['E1','F1']):
        keep.setdefault(d.name,set()).add('本文のE1/F1基準構成smoke')
    match = re.match(r'phase2-(?:main|main-r2)-T(?:3|6)-(P\d+)-', d.name)
    invalid_stack = {'P110','P113'} | {f'P{i:03d}' for i in range(115,123)} | {f'P{i:03d}' for i in range(134,140)}
    if match and match[1] in invalid_stack:
        keep.setdefault(d.name,set()).add('stack reopen修正前の無効試行の診断')
keep_path.write_text(''.join(k+'\t'+'；'.join(sorted(v))+'\n' for k,v in sorted(keep.items())))
added = set(keep)-before
freed_reduction = 0
for k in added:
    st = (runs/k/'sdcard.img').stat()
    assert st.st_nlink == 1
    freed_reduction += st.st_blocks*512
plan_path=misc/'deletion-candidates-phase2-20261112.txt'
plan=plan_path.read_text().splitlines()
removed=[p for p in plan if p.endswith('/sdcard.img') and p.split('/')[0] in added]
assert len(removed)==len(added)
plan=[p for p in plan if p not in removed]
plan_path.write_text(''.join(p+'\n' for p in plan))
audit_path=misc/'storage-audit-phase2-20261112.json'
audit=json.loads(audit_path.read_text())
audit['kept_sdcard_images']=len(keep)
audit['kept_allocated_bytes']+=freed_reduction
audit['delete_image_files']-=len(added)
audit['candidate_paths']=len(plan)
audit['freed_allocated_bytes_estimate']-=freed_reduction
audit['scope_kept_phase1_protected_images']=sum(k.startswith('t2fix-') for k in keep)
audit_path.write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n')
print('additional diagnostic/control images',len(added))
print(json.dumps(audit,ensure_ascii=False,indent=2))
