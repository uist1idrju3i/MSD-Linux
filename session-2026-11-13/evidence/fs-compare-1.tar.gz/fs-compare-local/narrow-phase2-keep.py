import csv
import hashlib
import json
import os
from pathlib import Path
from collections import Counter, defaultdict

repo = Path('/home/devin-worker/fscmp/data-branch')
runs = repo.parent/'runs'
misc = repo/'fs-compare/misc'
keep = {}

def add(rid, category, reason):
    assert rid not in keep
    assert (runs/rid/'sdcard.img').is_file()
    keep[rid] = (category, reason)

old = (misc/'images-kept-phase2-20261112.txt').read_text().splitlines()
for line in old:
    rid, reason = line.split('\t', 1)
    if '追試の代表' in reason and 'P087/T6' not in reason:
        label = next(r for r in reason.split('；') if r.startswith('追試の代表'))
        detail = '。P113はT5の書き込み量とT4のidle I/Oを別々に調べるため2 imageを保持' if 'P113/' in label else ''
        add(rid, 'follow-up', label+detail)
add('phase2-main-T5-P087-r1-1794411133', 'follow-up', '追試の代表 P087/T5。T6 harnessの制約で失敗したimageではなく、mixed構成で完了した書き込み試験を保持')
for base, rid in [('E1','phase2-smoke-r2-smoke-E1-r1-1794365236'), ('F1','phase2-smoke-r2-smoke-F1-r1-1794365261')]:
    add(rid, 'base-control', base+'の基準構成smoke。setupとmountの比較用。T4/T5のbase測定の代替ではない')
diagnostics = [
 ('phase2-t4-T4-sync-P007-r1-1794371987', 'mmp quiesce timeoutの代表。当時のMMP blockとsuperblockの状態を調べるため。再生成時に同じ停止時点の状態になるかは未確認'),
 ('phase2-main-T3-P047-r1-1794402424', 'checkpoint=disableでT3 fileが消失した代表。当時のcheckpointとnodeを直接調べるため。textにはfile消失後の全metadataはない'),
 ('phase2-main-T6-P103-r1-1794415584', 'chattr +Cでscrubが破損を検出しなかった代表。破損位置、extentのchecksum有無、file属性を直接照合するため'),
 ('phase2-main-T3-P110-r1-1794415859', 'stack reopen修正前のtag mismatch代表。当時のintegrity journalとtagを調べるため。textには全journal内容はない'),
 ('phase2-main-r2-T3-P118-r1-1794433558', 'stack reopen修正前のguest_exit_status=5代表。P110と異なる設定のsuperblockとopen条件を直接照合するため'),
 ('phase2-stackfix-T3-P110-r1-1794434789', 'stack reopen修正後のP110対照。失敗imageとのjournal・tag・設定の比較に使う。保持はこの修正後1件だけ'),
]
for rid, reason in diagnostics:
    add(rid, 'diagnostic', reason)
for line in old:
    rid, reason = line.split('\t', 1)
    if rid.startswith('t2fix-'):
        add(rid, 'protected-phase1', '第1段から保護しているimage。今回の削除対象外')
assert len(keep) == 26
(misc/'images-kept-phase2-20261112.txt').write_text(''.join(rid+'\t'+cat+': '+reason+'\n' for rid,(cat,reason) in sorted(keep.items())))

images = list(csv.DictReader((misc/'images-inventory-phase2-20261112.tsv').open(), delimiter='\t'))
builds = list(csv.DictReader((misc/'build-inventory-phase2-20261112.tsv').open(), delimiter='\t'))
protected = set((misc/'images-kept-20261111.txt').read_text().splitlines())
old_paths = {r['path'] for r in csv.DictReader((misc/'images-inventory-20261111.tsv').open(), delimiter='\t')}
delete_images = [r['path'] for r in images if '/build/' not in r['path'] and r['path'].split('/')[0] not in keep and r['path'] not in old_paths]
plan = sorted([r['path'] for r in builds]+delete_images)
assert not any(p.endswith('/sdcard.img') and p.split('/')[0] in protected for p in plan)
plan_path=misc/'deletion-candidates-phase2-20261112.txt'
plan_path.write_text(''.join(p+'\n' for p in plan))

# Count each inode once across every candidate, including links between builds.
inodes = {}
removed_links = Counter()
for rel in plan:
    p = runs/rel
    paths = [p]
    if p.is_dir():
        for root, dirs, files in os.walk(p):
            paths.extend(Path(root)/n for n in dirs+files)
    for f in paths:
        st = f.lstat()
        key = (st.st_dev,st.st_ino)
        inodes[key] = (st, f.is_dir() and not f.is_symlink())
        removed_links[key] += 1
freed=shared=0
for key,(st,is_dir) in inodes.items():
    if is_dir or removed_links[key] >= st.st_nlink:
        freed += st.st_blocks*512
    else:
        shared += st.st_blocks*512
categories=defaultdict(lambda:dict(count=0,allocated_bytes=0))
for rid,(cat,reason) in keep.items():
    categories[cat]['count'] += 1
    categories[cat]['allocated_bytes'] += (runs/rid/'sdcard.img').stat().st_blocks*512
audit_path=misc/'storage-audit-phase2-20261112.json'
audit=json.loads(audit_path.read_text())
audit.update(kept_sdcard_images=len(keep), kept_allocated_bytes=sum(v['allocated_bytes'] for v in categories.values()), kept_categories=dict(categories), delete_image_files=len(delete_images), candidate_paths=len(plan), freed_allocated_bytes_estimate=freed, shared_inode_allocated_bytes_not_freed=shared, retention_policy='follow-up representatives, necessary controls, selected on-disk diagnostics, protected phase1 only; no blanket CSV or j8/j4 retention')
audit_path.write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(audit,ensure_ascii=False,indent=2),flush=True)
print('deletion proposal sha256',hashlib.sha256(plan_path.read_bytes()).hexdigest(),flush=True)
