#!/usr/bin/env python3
import csv
import hashlib
import io
import json
import os
from pathlib import Path
import re
import subprocess
import tarfile
from collections import Counter, defaultdict
from datetime import datetime, timezone

REPO = Path('/home/devin-worker/fscmp/data-branch')
RUNS = REPO.parent / 'runs'
OUT = REPO / 'fs-compare'
DATE = '20261112'
BINARY = {'.img', '.squashfs', '.ext4', '.ext3', '.ext2', '.vfat', '.fat', '.f2fs', '.btrfs', '.erofs', '.cramfs', '.qcow2', '.raw', '.iso', '.bin', '.dtb'}

def digest_file(p):
    with p.open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()

def git(path):
    return subprocess.check_output(['git', '-C', str(REPO), 'show', 'origin/main:' + path], text=True)

def write_tsv(path, header, rows):
    with path.open('w') as f:
        w = csv.writer(f, delimiter='\t', lineterminator='\n')
        w.writerow(header)
        w.writerows(rows)

old_paths = {row['path'] for row in csv.DictReader((OUT/'misc/images-inventory-20261111.tsv').open(), delimiter='\t')}
old_dirs = {p.split('/')[0] for p in old_paths}
protected = set((OUT/'misc/images-kept-20261111.txt').read_text().splitlines())
scope = sorted(d for d in RUNS.iterdir() if d.is_dir() and (d.name.startswith(('phase2-', 'stackfix-', 't2fix-')) or (d.name not in old_dirs and ((d/'build').exists() or (d/'sdcard.img').exists()))))
print('scope', len(scope), flush=True)

# Verify archive bytes and member hashes, not just manifest membership.
archived = defaultdict(list)
archive_members = 0
expected_archives = {}
for line in (OUT/'SHA256SUMS').read_text().splitlines():
    h, name = line.split(None, 1)
    expected_archives[name.removeprefix('./')] = h
for archive in sorted(OUT.glob('*.tar.zst')):
    assert digest_file(archive) == expected_archives[archive.name], archive
    manifest = {}
    for line in archive.with_name(archive.name.removesuffix('.tar.zst')+'.files.sha256').read_text().splitlines():
        h, name = line.split(None, 1)
        manifest[name.removeprefix('./')] = h
    seen = {}
    proc = subprocess.Popen(['zstd', '-dc', str(archive)], stdout=subprocess.PIPE)
    with tarfile.open(fileobj=proc.stdout, mode='r|') as tar:
        for member in tar:
            if not (member.isfile() or member.islnk()):
                continue
            name = member.name.removeprefix('./')
            h = seen[member.linkname.removeprefix('./')] if member.islnk() else hashlib.file_digest(tar.extractfile(member), 'sha256').hexdigest()
            assert manifest.get(name) == h, (archive, name)
            seen[name] = h
            archived[(name, h)].append(archive.name)
            archive_members += 1
    assert proc.wait() == 0
    assert seen == manifest, archive
print('verified archive members', archive_members, flush=True)

texts = set()
images = set()
build_dirs = []
for d in scope:
    for p in d.iterdir():
        if p.is_file():
            (images if p.suffix in BINARY else texts).add(p)
    build = d/'build'
    if build.is_dir():
        build_dirs.append(build)
        for root, dirs, files in os.walk(build):
            dirs[:] = [n for n in dirs if n != 'rootfs']
            for name in files:
                p = Path(root)/name
                (images if p.suffix in BINARY else texts).add(p)
for p in RUNS.iterdir():
    if p.is_file() and p.name.startswith(('phase2-', 'stackfix-', 't2fix-')):
        (images if p.suffix in BINARY else texts).add(p)
for d in scope:
    for p in RUNS.glob(d.name+'.*'):
        if p.is_file():
            (images if p.suffix in BINARY else texts).add(p)

coverage = []
missing = []
for p in sorted(texts):
    assert not p.is_symlink(), p
    assert b'\0' not in p.open('rb').read(8192), ('unclassified binary', p)
    h = digest_file(p)
    rel = str(p.relative_to(RUNS))
    matches = archived.get((rel, h), [])
    coverage.append([rel, h, 'already-archived' if matches else 'newly-archived', ','.join(matches)])
    if not matches:
        missing.append(p)
if missing:
    archive = OUT/'phase2-build-logs-extra.tar.zst'
    assert not archive.exists()
    proc = subprocess.Popen(['zstd', '-T0', '-q', '-o', str(archive)], stdin=subprocess.PIPE)
    with tarfile.open(fileobj=proc.stdin, mode='w|', format=tarfile.PAX_FORMAT) as tar:
        for p in missing:
            tar.add(p, arcname=str(p.relative_to(RUNS)), recursive=False)
    proc.stdin.close()
    assert proc.wait() == 0
    archive.with_name('phase2-build-logs-extra.files.sha256').write_text(''.join(f'{digest_file(p)}  {p.relative_to(RUNS)}\n' for p in missing))
    for row in coverage:
        if row[2] == 'newly-archived':
            row[3] = archive.name
print('coverage', len(coverage), 'already', len(coverage)-len(missing), 'new', len(missing), flush=True)
write_tsv(OUT/f'misc/coverage-phase2-{DATE}.tsv', ['path', 'sha256', 'status', 'archive'], coverage)

inventory = []
for p in sorted(images):
    st = p.stat()
    sec, ns = divmod(st.st_mtime_ns, 10**9)
    stamp = datetime.fromtimestamp(sec, timezone.utc).strftime('%Y-%m-%dT%H:%M:%S') + f'.{ns:09d}0Z'
    inventory.append([str(p.relative_to(RUNS)), st.st_size, st.st_blocks*512, stamp])
write_tsv(OUT/f'misc/images-inventory-phase2-{DATE}.tsv', ['path', 'apparent_bytes', 'allocated_bytes', 'mtime_utc'], inventory)

rows = list(csv.DictReader(io.StringIO(git('docs/experiments/2026-11-12-phase2-option-variants.csv'))))
doc = git('docs/experiments/2026-11-12-phase2-option-variants.md')
reasons = defaultdict(set)
available = {p.parent.name: p for p in images if p.name == 'sdcard.img' and p.parent.parent == RUNS}
for row in rows:
    if row['run_id'] in available:
        reasons[row['run_id']].add('第2段の最終比較CSVに掲載')
for rid in re.findall(r'(?:phase2|stackfix|t2fix)-[A-Za-z0-9_-]+', doc):
    if rid in available:
        reasons[rid].add('第2段の本文に掲載')
for rid in available:
    if rid in protected or rid in old_dirs:
        reasons[rid].add('第1段のinventoryに収録済みのimageを保護')

# Preserve discarded attempts and diagnostic variants alongside final results.
diagnostic = {'P007','P012','P047','P085','P087','P101','P103','P110','P118','P133'}
for d in scope:
    summary = d/'summary.csv'
    if summary.exists():
        for row in csv.DictReader(summary.open()):
            rid = row.get('run_id', d.name)
            if rid not in available:
                continue
            status = row.get('status', '')
            if status and status != 'ok':
                reasons[rid].add('失敗・中止の診断: '+status)
            variant = row.get('variant_id') or row.get('config', '')
            if variant in diagnostic:
                reasons[rid].add('本文で失敗・制約・再測定を記録したvariant '+variant)
    if d.name in available and not summary.exists():
        reasons[d.name].add('summary欠落の試行を診断用に保護')

followups = {'T5': ['P074','P089','P090','P091','P104','P112','P113','P136'], 'T4-sync': ['P044','P097','P113','P120','P121','P122'], 'T6': ['P087']}
for test, variants in followups.items():
    for variant in variants:
        candidates = [r for r in rows if r['variant_id'] == variant and r['test'] == test and r['run_id'] in available]
        if not candidates:
            candidates = [{'run_id': rid} for rid in sorted(available) if f'-{test}-{variant}-' in rid]
        if not candidates and variant == 'P087':
            candidates = [r for r in rows if r['variant_id'] == variant and r['run_id'] in available]
        assert candidates, (test, variant)
        reasons[candidates[0]['run_id']].add(f'追試の代表 {variant}/{test}')

# Select existing phase-1 base/control images without modifying their keep policy.
bases = {'F1','F3','B2','I1','I2','L1','E1','L3'}
controls = []
for base in sorted(bases):
    for test in ['T4-sync','T5']:
        found = []
        for rid in sorted(protected):
            p = RUNS/rid/'summary.csv'
            if not p.exists() or not (RUNS/rid/'sdcard.img').exists():
                continue
            for row in csv.DictReader(p.open()):
                if row.get('config') == base and row.get('test') == test:
                    found.append(rid)
        if found:
            controls.append([base, test, found[0], '第1段の保持image。今回の削除対象外'])
        else:
            controls.append([base, test, '', '第1段の保持imageに該当なし。textのbase比較記録を参照'])
write_tsv(OUT/f'misc/base-controls-phase2-{DATE}.tsv', ['base_config','test','run_id','reason'], controls)

keep = sorted(reasons)
(OUT/f'misc/images-kept-phase2-{DATE}.txt').write_text(''.join(rid+'\t'+'；'.join(sorted(reasons[rid]))+'\n' for rid in keep))

all_candidates = []
build_inventory = []
for build in build_dirs:
    entries = [build]
    for root, dirs, files in os.walk(build):
        entries.extend(Path(root)/name for name in dirs+files)
    seen = set()
    apparent = allocated = 0
    for p in entries:
        st = p.lstat()
        key = (st.st_dev, st.st_ino)
        if key not in seen:
            apparent += st.st_size
            allocated += st.st_blocks*512
            seen.add(key)
        if not p.is_dir() or p.is_symlink():
            all_candidates.append((p, st))
        else:
            all_candidates.append((p, st))
    build_inventory.append([str(build.relative_to(RUNS)), apparent, allocated])
write_tsv(OUT/f'misc/build-inventory-phase2-{DATE}.tsv', ['path','apparent_bytes','allocated_bytes'], build_inventory)
delete_images = [p for p in images if 'build' not in p.relative_to(RUNS).parts and p.parent.name not in reasons and str(p.relative_to(RUNS)) not in old_paths]
all_candidates.extend((p,p.lstat()) for p in delete_images)
inodes = {}
links_removed = Counter()
for p, st in all_candidates:
    key = (st.st_dev, st.st_ino)
    inodes[key] = (p,st)
    links_removed[key] += 1
freed = shared = 0
for key,(p,st) in inodes.items():
    if p.is_dir() or links_removed[key] >= st.st_nlink:
        freed += st.st_blocks*512
    else:
        shared += st.st_blocks*512
plan = [str(p.relative_to(RUNS)) for p in build_dirs+delete_images]
assert not any(p.split('/')[0].startswith(('phase0-','phase1-')) for p in plan)
assert not any(p.endswith('sdcard.img') and p.split('/')[0] in protected for p in plan)
(OUT/f'misc/deletion-candidates-phase2-{DATE}.txt').write_text(''.join(p+'\n' for p in sorted(plan)))
result = dict(date=DATE, source_data_commit=subprocess.check_output(['git','-C',str(REPO),'rev-parse','HEAD'],text=True).strip(), source_main_commit=subprocess.check_output(['git','-C',str(REPO),'rev-parse','origin/main'],text=True).strip(), scope_dirs=len(scope), archive_members_verified=archive_members, text_files_checked=len(coverage), already_archived=len(coverage)-len(missing), newly_archived=len(missing), build_text_files=sum('/build/' in r[0] for r in coverage), binary_extensions=sorted(BINARY), images=len(images), image_allocated_bytes=sum(p.stat().st_blocks*512 for p in images), kept_sdcard_images=len(keep), kept_allocated_bytes=sum(available[r].stat().st_blocks*512 for r in keep), final_csv_runs=len({r['run_id'] for r in rows}), final_csv_images_available=sum(r['run_id'] in available for r in rows), build_dirs=len(build_dirs), delete_image_files=len(delete_images), candidate_paths=len(plan), freed_allocated_bytes_estimate=freed, shared_inode_allocated_bytes_not_freed=shared)
(OUT/f'misc/storage-audit-phase2-{DATE}.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False,indent=2),flush=True)
