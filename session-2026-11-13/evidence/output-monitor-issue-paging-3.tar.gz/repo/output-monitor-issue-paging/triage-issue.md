# 製品SBOMの脆弱性監視

- NVD feed: `aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa`（commit時刻: 2033-05-18T03:33:19Z）
- 構成要素: 67件、VEX: 16094件、解決済み: 15942件
- 影響あり: target 143件、host 8件、unknown 0件
- 未評価（Buildrootの無視指定）: 2件（CVEとcomponentの組み合わせ）
- 実行: https://github.com/uist1idrju3i/MSD-Linux/actions/runs/43270979753

## 影響あり（exploitable）

### target（イメージ内）

| package | version | CVE | CVSS | severity |
|---|---|---|---:|---|
| busybox | 1.38.0 | [CVE-2026-38753](https://nvd.nist.gov/vuln/detail/CVE-2026-38753) | 7.5 | high |
| busybox | 1.38.0 | [CVE-2026-38754](https://nvd.nist.gov/vuln/detail/CVE-2026-38754) | 7.5 | high |
| busybox | 1.38.0 | [CVE-2026-38755](https://nvd.nist.gov/vuln/detail/CVE-2026-38755) | 7.5 | high |
| linux | 6.18.59 | [CVE-1999-0656](https://nvd.nist.gov/vuln/detail/CVE-1999-0656) | 5.0 | unknown |
| linux | 6.18.59 | [CVE-2007-4998](https://nvd.nist.gov/vuln/detail/CVE-2007-4998) | 6.9 | unknown |
| linux | 6.18.59 | [CVE-2010-4563](https://nvd.nist.gov/vuln/detail/CVE-2010-4563) | 5.0 | unknown |
| linux | 6.18.59 | [CVE-2019-3016](https://nvd.nist.gov/vuln/detail/CVE-2019-3016) | 6.2 | medium |
| linux | 6.18.59 | [CVE-2019-3819](https://nvd.nist.gov/vuln/detail/CVE-2019-3819) | 4.9 | unknown |
| linux | 6.18.59 | [CVE-2019-3887](https://nvd.nist.gov/vuln/detail/CVE-2019-3887) | 6.7 | medium |
| linux | 6.18.59 | [CVE-2020-25672](https://nvd.nist.gov/vuln/detail/CVE-2020-25672) | 7.5 | high |
| linux | 6.18.59 | [CVE-2020-27815](https://nvd.nist.gov/vuln/detail/CVE-2020-27815) | 7.8 | high |
| linux | 6.18.59 | [CVE-2021-20194](https://nvd.nist.gov/vuln/detail/CVE-2021-20194) | 7.8 | high |
| linux | 6.18.59 | [CVE-2021-3564](https://nvd.nist.gov/vuln/detail/CVE-2021-3564) | 5.5 | medium |
| linux | 6.18.59 | [CVE-2021-3669](https://nvd.nist.gov/vuln/detail/CVE-2021-3669) | 5.5 | medium |
| linux | 6.18.59 | [CVE-2022-38096](https://nvd.nist.gov/vuln/detail/CVE-2022-38096) | 6.3 | medium |
| linux | 6.18.59 | [CVE-2022-4543](https://nvd.nist.gov/vuln/detail/CVE-2022-4543) | 5.5 | medium |
| linux | 6.18.59 | [CVE-2025-71074](https://nvd.nist.gov/vuln/detail/CVE-2025-71074) | 7.8 | high |
| linux | 6.18.59 | [CVE-2025-71289](https://nvd.nist.gov/vuln/detail/CVE-2025-71289) | 7.1 | high |
| linux | 6.18.59 | [CVE-2025-71306](https://nvd.nist.gov/vuln/detail/CVE-2025-71306) | 7.1 | high |
| linux | 6.18.59 | [CVE-2025-71308](https://nvd.nist.gov/vuln/detail/CVE-2025-71308) | 5.5 | medium |
| linux | 6.18.59 | [CVE-2025-71313](https://nvd.nist.gov/vuln/detail/CVE-2025-71313) | 5.5 | medium |
| linux | 6.18.59 | [CVE-2026-100072](https://nvd.nist.gov/vuln/detail/CVE-2026-100072) | 7.8 | high |
| linux | 6.18.59 | [CVE-2026-100073](https://nvd.nist.gov/vuln/detail/CVE-2026-100073) | 5.5 | medium |
| linux | 6.18.59 | [CVE-2026-23327](https://nvd.nist.gov/vuln/detail/CVE-2026-23327) | 7.1 | high |
| linux | 6.18.59 | [CVE-2026-23328](https://nvd.nist.gov/vuln/detail/CVE-2026-23328) | 5.5 | medium |
| linux | 6.18.59 | [CVE-2026-23371](https://nvd.nist.gov/vuln/detail/CVE-2026-23371) | 5.5 | medium |
| linux | 6.18.59 | [CVE-2026-23374](https://nvd.nist.gov/vuln/detail/CVE-2026-23374) | 5.5 | medium |
| linux | 6.18.59 | [CVE-2026-23377](https://nvd.nist.gov/vuln/detail/CVE-2026-23377) | 5.5 | medium |
| linux | 6.18.59 | [CVE-2026-23442](https://nvd.nist.gov/vuln/detail/CVE-2026-23442) | 5.5 | medium |
| linux | 6.18.59 | [CVE-2026-23459](https://nvd.nist.gov/vuln/detail/CVE-2026-23459) | 8.2 | high |
| linux | 6.18.59 | [CVE-2026-31420](https://nvd.nist.gov/vuln/detail/CVE-2026-31420) | 5.5 | medium |
| linux | 6.18.59 | [CVE-2026-31501](https://nvd.nist.gov/vuln/detail/CVE-2026-31501) | 9.8 | critical |
| linux | 6.18.59 | [CVE-2026-31560](https://nvd.nist.gov/vuln/detail/CVE-2026-31560) | 5.5 | medium |
| linux | 6.18.59 | [CVE-2026-31589](https://nvd.nist.gov/vuln/detail/CVE-2026-31589) | 9.8 | critical |
| linux | 6.18.59 | [CVE-2026-31709](https://nvd.nist.gov/vuln/detail/CVE-2026-31709) | 8.8 | high |
| linux | 6.18.59 | [CVE-2026-31771](https://nvd.nist.gov/vuln/detail/CVE-2026-31771) | 8.1 | high |
| linux | 6.18.59 | [CVE-2026-31777](https://nvd.nist.gov/vuln/detail/CVE-2026-31777) | 5.5 | medium |
| linux | 6.18.59 | [CVE-2026-43009](https://nvd.nist.gov/vuln/detail/CVE-2026-43009) | 7.8 | high |
| linux | 6.18.59 | [CVE-2026-43022](https://nvd.nist.gov/vuln/detail/CVE-2026-43022) | 5.5 | medium |
| linux | 6.18.59 | [CVE-2026-43042](https://nvd.nist.gov/vuln/detail/CVE-2026-43042) | 7.1 | high |
| linux | 6.18.59 | [CVE-2026-43045](https://nvd.nist.gov/vuln/detail/CVE-2026-43045) | 5.5 | medium |
| linux | 6.18.59 | [CVE-2026-43053](https://nvd.nist.gov/vuln/detail/CVE-2026-43053) | 4.7 | medium |
| linux | 6.18.59 | [CVE-2026-43095](https://nvd.nist.gov/vuln/detail/CVE-2026-43095) | 5.5 | medium |
| linux | 6.18.59 | [CVE-2026-43115](https://nvd.nist.gov/vuln/detail/CVE-2026-43115) | 5.5 | medium |
| linux | 6.18.59 | [CVE-2026-43131](https://nvd.nist.gov/vuln/detail/CVE-2026-43131) | 5.5 | medium |
| linux | 6.18.59 | [CVE-2026-43174](https://nvd.nist.gov/vuln/detail/CVE-2026-43174) | 5.5 | medium |
| linux | 6.18.59 | [CVE-2026-43191](https://nvd.nist.gov/vuln/detail/CVE-2026-43191) | 5.5 | medium |
| linux | 6.18.59 | [CVE-2026-43204](https://nvd.nist.gov/vuln/detail/CVE-2026-43204) | 5.5 | medium |
| linux | 6.18.59 | [CVE-2026-43228](https://nvd.nist.gov/vuln/detail/CVE-2026-43228) | 5.5 | medium |
| linux | 6.18.59 | [CVE-2026-43299](https://nvd.nist.gov/vuln/detail/CVE-2026-43299) | 5.5 | medium |
| linux | 6.18.59 | [CVE-2026-43308](https://nvd.nist.gov/vuln/detail/CVE-2026-43308) | 5.5 | medium |
| linux | 6.18.59 | [CVE-2026-43310](https://nvd.nist.gov/vuln/detail/CVE-2026-43310) | 5.5 | medium |
| linux | 6.18.59 | [CVE-2026-43311](https://nvd.nist.gov/vuln/detail/CVE-2026-43311) | 5.5 | medium |
| linux | 6.18.59 | [CVE-2026-43326](https://nvd.nist.gov/vuln/detail/CVE-2026-43326) | 5.5 | medium |
| linux | 6.18.59 | [CVE-2026-43344](https://nvd.nist.gov/vuln/detail/CVE-2026-43344) | 5.5 | medium |
| linux | 6.18.59 | [CVE-2026-43391](https://nvd.nist.gov/vuln/detail/CVE-2026-43391) | 8.8 | high |
| linux | 6.18.59 | [CVE-2026-43414](https://nvd.nist.gov/vuln/detail/CVE-2026-43414) | 9.8 | critical |
| linux | 6.18.59 | [CVE-2026-43443](https://nvd.nist.gov/vuln/detail/CVE-2026-43443) | 5.5 | medium |
| linux | 6.18.59 | [CVE-2026-45897](https://nvd.nist.gov/vuln/detail/CVE-2026-45897) | 5.5 | medium |
| linux | 6.18.59 | [CVE-2026-45901](https://nvd.nist.gov/vuln/detail/CVE-2026-45901) | 5.5 | medium |
| linux | 6.18.59 | [CVE-2026-45945](https://nvd.nist.gov/vuln/detail/CVE-2026-45945) | 8.8 | high |
| linux | 6.18.59 | [CVE-2026-45961](https://nvd.nist.gov/vuln/detail/CVE-2026-45961) | 5.5 | medium |
| linux | 6.18.59 | [CVE-2026-45963](https://nvd.nist.gov/vuln/detail/CVE-2026-45963) | 5.5 | medium |
| linux | 6.18.59 | [CVE-2026-45991](https://nvd.nist.gov/vuln/detail/CVE-2026-45991) | 7.8 | high |
| linux | 6.18.59 | [CVE-2026-46008](https://nvd.nist.gov/vuln/detail/CVE-2026-46008) | 4.7 | medium |
| linux | 6.18.59 | [CVE-2026-46017](https://nvd.nist.gov/vuln/detail/CVE-2026-46017) | 4.7 | medium |
| linux | 6.18.59 | [CVE-2026-46032](https://nvd.nist.gov/vuln/detail/CVE-2026-46032) | 5.5 | medium |
| linux | 6.18.59 | [CVE-2026-46054](https://nvd.nist.gov/vuln/detail/CVE-2026-46054) | 7.1 | high |
| linux | 6.18.59 | [CVE-2026-46092](https://nvd.nist.gov/vuln/detail/CVE-2026-46092) | 5.5 | medium |
| linux | 6.18.59 | [CVE-2026-46130](https://nvd.nist.gov/vuln/detail/CVE-2026-46130) | 7.1 | high |
| linux | 6.18.59 | [CVE-2026-46153](https://nvd.nist.gov/vuln/detail/CVE-2026-46153) | 5.5 | medium |
| linux | 6.18.59 | [CVE-2026-46203](https://nvd.nist.gov/vuln/detail/CVE-2026-46203) | 7.1 | high |
| linux | 6.18.59 | [CVE-2026-46210](https://nvd.nist.gov/vuln/detail/CVE-2026-46210) | 7.8 | high |
| linux | 6.18.59 | [CVE-2026-46245](https://nvd.nist.gov/vuln/detail/CVE-2026-46245) | 5.5 | medium |
| linux | 6.18.59 | [CVE-2026-46252](https://nvd.nist.gov/vuln/detail/CVE-2026-46252) | 5.5 | medium |
| linux | 6.18.59 | [CVE-2026-46298](https://nvd.nist.gov/vuln/detail/CVE-2026-46298) | 4.7 | medium |
| linux | 6.18.59 | [CVE-2026-46302](https://nvd.nist.gov/vuln/detail/CVE-2026-46302) | 5.5 | medium |
| linux | 6.18.59 | [CVE-2026-46311](https://nvd.nist.gov/vuln/detail/CVE-2026-46311) | 7.8 | high |
| linux | 6.18.59 | [CVE-2026-46330](https://nvd.nist.gov/vuln/detail/CVE-2026-46330) | 7.8 | high |
| linux | 6.18.59 | [CVE-2026-52949](https://nvd.nist.gov/vuln/detail/CVE-2026-52949) | 5.5 | medium |
| linux | 6.18.59 | [CVE-2026-52956](https://nvd.nist.gov/vuln/detail/CVE-2026-52956) | 7.5 | high |
| linux | 6.18.59 | [CVE-2026-52960](https://nvd.nist.gov/vuln/detail/CVE-2026-52960) | 7.5 | high |
| linux | 6.18.59 | [CVE-2026-52965](https://nvd.nist.gov/vuln/detail/CVE-2026-52965) | 5.5 | medium |
| linux | 6.18.59 | [CVE-2026-52988](https://nvd.nist.gov/vuln/detail/CVE-2026-52988) | 7.1 | high |
| linux | 6.18.59 | [CVE-2026-53005](https://nvd.nist.gov/vuln/detail/CVE-2026-53005) | 7.8 | high |
| linux | 6.18.59 | [CVE-2026-53007](https://nvd.nist.gov/vuln/detail/CVE-2026-53007) | 5.5 | medium |
| linux | 6.18.59 | [CVE-2026-53008](https://nvd.nist.gov/vuln/detail/CVE-2026-53008) | 4.7 | medium |
| linux | 6.18.59 | [CVE-2026-53009](https://nvd.nist.gov/vuln/detail/CVE-2026-53009) | 7.8 | high |
| linux | 6.18.59 | [CVE-2026-53017](https://nvd.nist.gov/vuln/detail/CVE-2026-53017) | 5.5 | medium |
| linux | 6.18.59 | [CVE-2026-53024](https://nvd.nist.gov/vuln/detail/CVE-2026-53024) | 7.8 | high |
| linux | 6.18.59 | [CVE-2026-53025](https://nvd.nist.gov/vuln/detail/CVE-2026-53025) | 7.8 | high |
| linux | 6.18.59 | [CVE-2026-53027](https://nvd.nist.gov/vuln/detail/CVE-2026-53027) | 5.5 | medium |
| linux | 6.18.59 | [CVE-2026-53078](https://nvd.nist.gov/vuln/detail/CVE-2026-53078) | 7.8 | high |
| linux | 6.18.59 | [CVE-2026-53089](https://nvd.nist.gov/vuln/detail/CVE-2026-53089) | 7.8 | high |
| linux | 6.18.59 | [CVE-2026-53090](https://nvd.nist.gov/vuln/detail/CVE-2026-53090) | 7.8 | high |
| linux | 6.18.59 | [CVE-2026-53091](https://nvd.nist.gov/vuln/detail/CVE-2026-53091) | 8.4 | high |
| linux | 6.18.59 | [CVE-2026-53102](https://nvd.nist.gov/vuln/detail/CVE-2026-53102) | 5.5 | medium |
| linux | 6.18.59 | [CVE-2026-53106](https://nvd.nist.gov/vuln/detail/CVE-2026-53106) | 5.5 | medium |
| linux | 6.18.59 | [CVE-2026-53108](https://nvd.nist.gov/vuln/detail/CVE-2026-53108) | 4.7 | medium |
| linux | 6.18.59 | [CVE-2026-53113](https://nvd.nist.gov/vuln/detail/CVE-2026-53113) | 5.5 | medium |
| linux | 6.18.59 | [CVE-2026-53124](https://nvd.nist.gov/vuln/detail/CVE-2026-53124) | 5.5 | medium |
| linux | 6.18.59 | [CVE-2026-53178](https://nvd.nist.gov/vuln/detail/CVE-2026-53178) | 8.1 | high |
| linux | 6.18.59 | [CVE-2026-53222](https://nvd.nist.gov/vuln/detail/CVE-2026-53222) | 5.5 | medium |
| linux | 6.18.59 | [CVE-2026-53232](https://nvd.nist.gov/vuln/detail/CVE-2026-53232) | 8.8 | high |
| linux | 6.18.59 | [CVE-2026-53257](https://nvd.nist.gov/vuln/detail/CVE-2026-53257) | 5.5 | medium |
| linux | 6.18.59 | [CVE-2026-53260](https://nvd.nist.gov/vuln/detail/CVE-2026-53260) | 9.8 | critical |
| linux | 6.18.59 | [CVE-2026-53285](https://nvd.nist.gov/vuln/detail/CVE-2026-53285) | 5.5 | medium |
| linux | 6.18.59 | [CVE-2026-53292](https://nvd.nist.gov/vuln/detail/CVE-2026-53292) | 5.5 | medium |
| linux | 6.18.59 | [CVE-2026-53308](https://nvd.nist.gov/vuln/detail/CVE-2026-53308) | 5.5 | medium |
| linux | 6.18.59 | [CVE-2026-53313](https://nvd.nist.gov/vuln/detail/CVE-2026-53313) | 5.5 | medium |
| linux | 6.18.59 | [CVE-2026-53401](https://nvd.nist.gov/vuln/detail/CVE-2026-53401) | 7.8 | high |
| linux | 6.18.59 | [CVE-2026-63977](https://nvd.nist.gov/vuln/detail/CVE-2026-63977) | 7.8 | high |
| linux | 6.18.59 | [CVE-2026-64013](https://nvd.nist.gov/vuln/detail/CVE-2026-64013) | 5.5 | medium |
| linux | 6.18.59 | [CVE-2026-64019](https://nvd.nist.gov/vuln/detail/CVE-2026-64019) | 5.5 | medium |
| linux | 6.18.59 | [CVE-2026-64020](https://nvd.nist.gov/vuln/detail/CVE-2026-64020) | 7.5 | high |
| linux | 6.18.59 | [CVE-2026-64040](https://nvd.nist.gov/vuln/detail/CVE-2026-64040) | 5.5 | medium |
| linux | 6.18.59 | [CVE-2026-64057](https://nvd.nist.gov/vuln/detail/CVE-2026-64057) | 7.8 | high |
| linux | 6.18.59 | [CVE-2026-64067](https://nvd.nist.gov/vuln/detail/CVE-2026-64067) | 9.8 | critical |
| linux | 6.18.59 | [CVE-2026-64068](https://nvd.nist.gov/vuln/detail/CVE-2026-64068) | 9.8 | critical |
| linux | 6.18.59 | [CVE-2026-64079](https://nvd.nist.gov/vuln/detail/CVE-2026-64079) | 5.5 | medium |
| linux | 6.18.59 | [CVE-2026-64082](https://nvd.nist.gov/vuln/detail/CVE-2026-64082) | 7.8 | high |
| linux | 6.18.59 | [CVE-2026-64117](https://nvd.nist.gov/vuln/detail/CVE-2026-64117) | 8.8 | high |
| linux | 6.18.59 | [CVE-2026-64123](https://nvd.nist.gov/vuln/detail/CVE-2026-64123) | 7.8 | high |
| linux | 6.18.59 | [CVE-2026-64146](https://nvd.nist.gov/vuln/detail/CVE-2026-64146) | 5.5 | medium |
| linux | 6.18.59 | [CVE-2026-64154](https://nvd.nist.gov/vuln/detail/CVE-2026-64154) | 5.5 | medium |
| linux | 6.18.59 | [CVE-2026-64159](https://nvd.nist.gov/vuln/detail/CVE-2026-64159) | 5.5 | medium |
| linux | 6.18.59 | [CVE-2026-64160](https://nvd.nist.gov/vuln/detail/CVE-2026-64160) | 9.8 | critical |
| linux | 6.18.59 | [CVE-2026-64210](https://nvd.nist.gov/vuln/detail/CVE-2026-64210) | 7.5 | high |
| linux | 6.18.59 | [CVE-2026-64283](https://nvd.nist.gov/vuln/detail/CVE-2026-64283) | 7.0 | high |
| linux | 6.18.59 | [CVE-2026-64325](https://nvd.nist.gov/vuln/detail/CVE-2026-64325) | 5.5 | medium |
| linux | 6.18.59 | [CVE-2026-64341](https://nvd.nist.gov/vuln/detail/CVE-2026-64341) | 7.8 | high |
| linux | 6.18.59 | [CVE-2026-64388](https://nvd.nist.gov/vuln/detail/CVE-2026-64388) | 7.8 | high |
| linux | 6.18.59 | [CVE-2026-64400](https://nvd.nist.gov/vuln/detail/CVE-2026-64400) | 8.6 | high |
| linux | 6.18.59 | [CVE-2026-98049](https://nvd.nist.gov/vuln/detail/CVE-2026-98049) | 5.5 | medium |
| linux | 6.18.59 | [CVE-2026-98115](https://nvd.nist.gov/vuln/detail/CVE-2026-98115) | 8.8 | high |
| linux | 6.18.59 | [CVE-2026-98118](https://nvd.nist.gov/vuln/detail/CVE-2026-98118) | 7.1 | high |
| linux | 6.18.59 | [CVE-2026-98124](https://nvd.nist.gov/vuln/detail/CVE-2026-98124) | 5.5 | medium |
| linux | 6.18.59 | [CVE-2026-98125](https://nvd.nist.gov/vuln/detail/CVE-2026-98125) | 5.5 | medium |
| linux | 6.18.59 | [CVE-2026-98131](https://nvd.nist.gov/vuln/detail/CVE-2026-98131) | 5.5 | medium |
| linux | 6.18.59 | [CVE-2026-98134](https://nvd.nist.gov/vuln/detail/CVE-2026-98134) | 5.5 | medium |
| linux | 6.18.59 | [CVE-2026-98153](https://nvd.nist.gov/vuln/detail/CVE-2026-98153) | 5.5 | medium |
| linux | 6.18.59 | [CVE-2026-98162](https://nvd.nist.gov/vuln/detail/CVE-2026-98162) | 5.5 | medium |
| util-linux | 2.41.5 | [CVE-2026-13595](https://nvd.nist.gov/vuln/detail/CVE-2026-13595) | 6.8 | medium |

### host（ビルド専用）

| package | version | CVE | CVSS | severity |
|---|---|---|---:|---|
| bison | 3.8.2 | [CVE-2026-56389](https://nvd.nist.gov/vuln/detail/CVE-2026-56389) | 8.6 | high |
| bison | 3.8.2 | [CVE-2026-56390](https://nvd.nist.gov/vuln/detail/CVE-2026-56390) | 6.3 | medium |
| expat | 2.9.0 | [CVE-2026-113351](https://nvd.nist.gov/vuln/detail/CVE-2026-113351) | 8.2 | high |
| expat | 2.9.0 | [CVE-2026-115506](https://nvd.nist.gov/vuln/detail/CVE-2026-115506) | 8.7 | high |
| expat | 2.9.0 | [CVE-2026-117610](https://nvd.nist.gov/vuln/detail/CVE-2026-117610) | 8.2 | high |
| expat | 2.9.0 | [CVE-2026-118370](https://nvd.nist.gov/vuln/detail/CVE-2026-118370) | 8.2 | high |
| python-setuptools | 80.9.0 | [CVE-2026-59890](https://nvd.nist.gov/vuln/detail/CVE-2026-59890) | 6.1 | medium |
| util-linux | 2.41.5 | [CVE-2026-13595](https://nvd.nist.gov/vuln/detail/CVE-2026-13595) | 6.8 | medium |

### unknown（区分不明）

| package | version | CVE | CVSS | severity |
|---|---|---|---:|---|
| なし |  |  |  |  |

## 未評価（Buildrootの無視指定）

in_triageは影響あり・解消・scan失敗とは別の状態です。無視指定だけで安全とは判断しません。

| CVE | component | package | version |
|---|---|---|---|
| [CVE-2019-6293](https://nvd.nist.gov/vuln/detail/CVE-2019-6293) | host-flex | flex | 2.6.4 |
| [CVE-2021-4336](https://nvd.nist.gov/vuln/detail/CVE-2021-4336) | host-ninja | ninja | 1.13.2 |

Buildroot `cve-check` はCPE照合に基づきます。CPEを持たない外部ツールチェーン内部やM5配布ファイルは検出できず、一覧にないことは安全の証明ではありません。
[SBOMの対象範囲と限界](https://github.com/uist1idrju3i/MSD-Linux/blob/main/docs/research/operations/sbom-coverage.md)
