---
description: Answers to common questions about Cloudflare Web Analytics.
title: FAQs
image: https://developers.cloudflare.com/web-analytics/faq/og.png?v=28065b596b989c98
---

[Skip to content](#main-content)

> Documentation Index  
> Fetch the complete documentation index at: https://developers.cloudflare.com/web-analytics/llms.txt  
> Use this file to discover all available pages before exploring further.

# FAQs

Last updated Jul 14, 2026|Copy as Markdown| [View as Markdown](https://developers.cloudflare.com/web-analytics/faq/index.md)| [Agent setup](https://developers.cloudflare.com/agent-setup/)

Below you will find answers to our most commonly asked questions. If you cannot find the answer you are looking for, refer to the [community page ↗︎](https://community.cloudflare.com/) to explore more resources.

- [Errors](#errors)
- [Setup](#setup)
- [Functionality](#functionality)

## Errors

### When I add the beacon to my website and load the webpage, I see an error that includes `is not allowed by Access-Control-Allow-Origin` (CORS). What is happening?

This error usually occurs when the hostname of the site loading the analytics does not match the name of the analytics site configured in the dashboard. Double-check that they are identical.

Cloudflare matches hostnames based on a postfix. For example, if you set up analytics for `example.com`, we will allow analytics from `www.example.com`, `blog.staging.example.com`, and `fooexample.com`. However, we will not allow analytics from `example.com.br`.

You may also see this error if the site does not send a `Referer` or `Origin` header. The `Referer` header is required (do not try to use the `Referrer-policy` header instead). We have a change in-flight now that only the `Origin` header will be required – we believe there is no way to disable that in the browser.

### The analytics beacon is blocked by ad-blockers (including adblockplus, Brave, DuckDuckGo extension, etc). Why is that?

Cloudflare is aware that the analytics beacon is blocked by these services.

While Cloudflare Web Analytics uses a JavaScript beacon, Cloudflare’s edge analytics cannot be blocked because we can measure every request that is received. Edge analytics are available to any customer who proxies traffic through Cloudflare. Currently, users on Pro, Business, and Enterprise plans get advanced web analytics powered by our edge logs.

### Why am I not seeing all the metrics for single-page application (SPA) or multiple-page application (MPA)?

Every route change that occurs in the single-page app will send the measurement of the route before the route is changed to the beacon endpoint. The measurement for the last route change will be sent whenever the user leaves the tab or closes the browser window. That will trigger `visibilityState` to a hidden state. Whenever that happens, Beacon JS sends the payload using the [Navigator.sendBeacon method ↗︎](https://developer.mozilla.org/en-US/docs/Web/API/Navigator/sendBeacon) that should not be cancelled even when the browser window is closed. However, due to compatibility, old browsers would fallback to using AJAX (`XmlHttpRequest`), which can be cancelled when the browser window is closed, so the last payload that gets sent to the beacon endpoint can be lost. Also, due to various network conditions, there can be data loss when the payload is sent to the beacon endpoint.

### For the same site, why would I see more data reported with an automatic setup?

Unless you are using Rules to control which pages to be measured, using [automatic setup](https://developers.cloudflare.com/web-analytics/get-started/#sites-proxied-through-cloudflare) will inject the JS snippet on all pages (sub-domains) under the zone.

If you used a [manual setup](https://developers.cloudflare.com/web-analytics/get-started/#sites-not-proxied-through-cloudflare) instead, only those pages that render the JS snippet will be reported.

Note

Since only one JS snippet can be rendered and used per page, you cannot have multiple snippets on the same page.

### My website is proxied through Cloudflare, but Web Analytic's automatic setup is not working.

If you have a `Cache-Control` header set to `public, no-transform`, Cloudflare proxy will not be able to modify the original payload of the website. Therefore, the Beacon script will not be automatically injected to your site, and Web Analytics will not work. Refer to [Origin cache control](https://developers.cloudflare.com/cache/concepts/cache-control/) for more information.

### Why am I getting a `405 Method Not Allowed` error from `/cdn-cgi/rum`?

The `/cdn-cgi/rum` endpoint only accepts `POST` requests for data ingestion. If you send a request using any other HTTP method (for example, `GET`, `PUT`, or `DELETE`), the endpoint returns a `405 Method Not Allowed` response with an `Allow: POST, OPTIONS` header (`OPTIONS` is allowed for [CORS ↗︎](https://developer.mozilla.org/en-US/docs/Web/HTTP/Guides/CORS) support).

The Web Analytics beacon (`beacon.min.js`) always uses `POST` when reporting metrics. If you see `405` errors in your logs, the requests are not coming from the beacon itself.

They are most likely coming from an automated testing tool making erroneous requests, in which case you should correct it to use `POST` or ignore the errors.

We do not support custom integrations directly with the endpoint: all requests should originate from our beacon JavaScript.

### Why am I seeing syntax errors from the beacon script in Internet Explorer?

Internet Explorer 11 was the final version of Internet Explorer and it was [declared completely end-of-life (EOL) in 2022 ↗︎](https://techcommunity.microsoft.com/blog/windows-itpro-blog/internet-explorer-11-desktop-app-retirement-faq/2366549).

Our beacon script targets modern syntax which Internet Explorer does not support. This will cause a non-user-visible error when the script attempts to execute. The only functional impact is that beacons are not collected from these old browsers.

For customers using automatic-injection, Cloudflare adds `type="module"` to the `<script>` tag to prevent loading in Internet Explorer and similarly old, deprecated browsers.

For customers using the manual embed approach, you will need to add `type="module"` to the `<script>` tag manually. Our dashboard has been updated to include this attribute in the installation instructions.

---

## Setup

### I am proxying my site through Cloudflare. Should I manually add the JS beacon?

You can, but you do not have to. Cloudflare Web Analytics is designed primarily for customers who do not use Cloudflare's proxy to measure their web traffic.

Existing Cloudflare customers can access analytics collected from our edge on the **Analytics** tab of the dashboard. You can also enable Web Analytics to measure performance using JavaScript.

Using a domain proxied through Cloudflare with [automatic setup](https://developers.cloudflare.com/web-analytics/get-started/#sites-proxied-through-cloudflare) will report stats back to your own domain's `/cdn-cgi/rum` endpoint. If you have installed JS snippet yourself (a [manual setup](https://developers.cloudflare.com/web-analytics/get-started/#sites-not-proxied-through-cloudflare)), it will report back to `cloudflareinsights.com/cdn-cgi/rum` endpoint.

### Can I add Web Analytics to my site using a tag manager like Google Tag Manager (GTM)?

Yes. Instead of embedding the script using a tag manager as shown here:

```html
<script
	type="module"
	src="https://static.cloudflareinsights.com/beacon.min.js"
	data-cf-beacon='{"token": "$SITE_TOKEN"}'
></script>
```

Add the following script:

```html
<script
	type="module"
	src="https://static.cloudflareinsights.com/beacon.min.js?token=$SITE_TOKEN"
></script>
```

### What do I need to add to my Content Security Policy (CSP)?

If your site implements a Content Security Policy (CSP), you'll need to add some entries to this HTTP header to allow browsers to download the beacon script and transmit beacons to Cloudflare.

**Warning:** be sure to validate any CSP changes on a test environment before releasing an update to your production environment. You may wish to use [Content Security Rules ↗︎](https://developers.cloudflare.com/client-side-security/rules/) or trial with `Content-Security-Policy-Report-Only` first.

You'll first need to permit our script to execute by adding it to your `script-src` directive:

```plaintext
script-src [...existing values...] https://static.cloudflareinsights.com/beacon.min.js
```

*Note: if you have a query string in the script as per the example above for Google Tag Manager, then you'll need to include this in the URL too, e.g. `script-src [...existing values...] https://static.cloudflareinsights.com/beacon.min.js?token=$SITE_TOKEN`*

Secondly, you'll need to permit the endpoint we transmit the beacon data to.

For automatic injection, this will be the same domain, so ensure your `connect-src` includes `'self'`:

```plaintext
connect-src [...existing values...] 'self'
```

For manual embedding, this script instead connects to `cloudflareinsights.com`, so ensure that's included instead:

```plaintext
connect-src [...existing values...] cloudflareinsights.com
```

### How can I enforce Subresource Integrity (SRI) with the JS beacon?

If you're using the automated injection (i.e. not the manually-embedded script approach mentioned above), Cloudflare automatically includes an `integrity` attribute in the `<script>`. This ensures the script will only execute if a local hash of its downloaded contents match the integrity hash supplied in the HTML.

Unfortunately, if you're using the manually-embedded script approach, there is no current way to safely apply an `integrity` attribute because we do not support version-pinning our beacon script. We do this because it ensures we can release periodic updates to maintain security, address bugs and ensure

### Can I use the same JS Snippet for a different domain?

No. However, if the apex domain (also known as "root domain" or "naked domain") is the same, you can use the same site tag. For example, if you have provided us a hostname `example.com` when registering a site, you can use the JS snippet from that site for `abc.example.com` and `def.example.com` since they use the same apex domain. When payload gets sent to the beacon endpoint, we validate the hostname with postfix matching, so if your domain shares the same apex domain, that would work.

### Can I use automatic setup with a DNS-only domain (CNAME setup)?

No, you can only use the [automatic setup](https://developers.cloudflare.com/web-analytics/get-started/#sites-proxied-through-cloudflare) with JS snippet injection if traffic to your domain is proxied through Cloudflare (orange-clouded).

If you have a DNS-only domain, you will have to do a [manual setup](https://developers.cloudflare.com/web-analytics/get-started/#sites-not-proxied-through-cloudflare) instead.

### What prevents the JS Snippet from being added to a page?

For Cloudflare to automatically add the JavaScript snippet, your pages need to have valid HTML.

For example, Cloudflare would not be able to enable Web Analytics on a page like this:

*index.htmlhtml*

```html
Hello world.
```

For Web Analytics to correctly insert the JavaScript snippet, you would need valid HTML output, such as:

*index.htmlhtml*

```html
<!DOCTYPE html>
<html>
	<head>
		<title>Title</title>
	</head>
	<body>

		<p>Hello world.</p>

	</body>
</html>
```

### Can I use Real User Monitoring (RUM) with Cloudflare Workers?

Cloudflare's Real User Monitoring (RUM) operates exclusively on the initial client request and cannot collect metrics from Worker subrequests. This is a fundamental architectural limitation designed to ensure accurate performance measurements and prevent duplicate or misleading analytics data.

---

## Functionality

### Is the data sampled?

We retain unsampled beacon data for the past 7 days, after this point data is aggregated down to around 10%.

When aggregating metrics in the Cloudflare Dashboard or querying the GraphQL API, a level of sampling (between 0.0001% and 100%) will be dynamically selected based on the filters applied and the volume of matching rows. This ensures a high confidence in the accuracy of figures while maintaining a reasonable response time. You can [read more about this approach on the Cloudflare blog ↗︎](https://blog.cloudflare.com/explaining-cloudflares-abr-analytics/).

Note: the GraphQL API exposes a `sampleInterval` field to indicate which level of sampling has been applied to the query.

- The beacon script will fire on every pageview.
- The data ingestion pipeline does not apply sampling—every received beacon will be recorded.
- We store the unsampled data for 7 days.
- We also aggregate it down so it's around 10% of the original volume for long-term storage.
- Sites with very low traffic volumes are sampled to greater percentages to maintain high confidence in aggregate figures.

### Can I see server-side analytics by URL?

Web Analytics only displays client-side analytics. All Cloudflare customers who proxy their traffic also get analytics based on traffic at their edge.

Currently, users on Pro, Business, and Enterprise plans get advanced HTTP traffic analytics, which is the only way to see features like a breakdown of traffic by URL based on server-side analytics.

### What is the period of time I can access data in Web Analytics?

Currently, you can access data for the previous six months.

### Does Cloudflare Web Analytics support UTM parameters?

Not yet. UTM parameters are special query string parameters that can help track where traffic is coming from. Currently, Cloudflare Web Analytics do not log query strings to avoid collecting potentially sensitive data, but we may add support for this in the future.

### Does Web Analytics support custom events?

Not yet, but we may add support for this in the future.

### Can I track more than one website with Web Analytics?

Yes. Right now there is a soft limit of ten sites per account, but that can be adjusted by contacting Cloudflare support.

### When does the beacon send metrics to the `/cdn-cgi/rum/` endpoint?

For traditional websites, not Single Page Applications (SPAs), the Web Analytics beacon reports to the `/cdn-cgi/rum/` endpoint when the page has finished loading (load event) and when the user leaves the page. For Single Page Applications, additional metrics are sent for every route change to capture the page load event.

Was this helpful?

YesNo

## On this page

[![](https://developers.cloudflare.com/_astro/logo.te5VL_aD.svg)Docs](https://developers.cloudflare.com/)

```json
{"@context":"https://schema.org","@type":"TechArticle","@id":"https://developers.cloudflare.com/web-analytics/faq/#page","headline":"FAQs","description":"Answers to common questions about Cloudflare Web Analytics.","url":"https://developers.cloudflare.com/web-analytics/faq/","inLanguage":"en","image":"https://developers.cloudflare.com/web-analytics/faq/og.png?v=28065b596b989c98","dateModified":"2026-07-14","publisher":{"@type":"Organization","name":"Cloudflare","description":"One platform for your apps, agents, and workforce. Build, secure, and scale without managing infrastructure","url":"https://www.cloudflare.com/","sameAs":["https://github.com/cloudflare","https://www.linkedin.com/company/cloudflare","https://x.com/cloudflare"],"logo":{"@type":"ImageObject","url":"https://developers.cloudflare.com/logo.svg"},"address":{"@type":"PostalAddress","streetAddress":"101 Townsend St","addressLocality":"San Francisco","addressRegion":"CA","postalCode":"94107","addressCountry":"US"},"contactPoint":[{"@type":"ContactPoint","contactType":"Customer Support","url":"https://support.cloudflare.com/","availableLanguage":["English"]},{"@type":"ContactPoint","contactType":"Sales","url":"https://www.cloudflare.com/contact/","availableLanguage":["English"]}]},"isPartOf":{"@type":"WebSite","@id":"https://developers.cloudflare.com/#website","name":"Cloudflare Docs","url":"https://developers.cloudflare.com/"}}
```
