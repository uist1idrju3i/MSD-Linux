#
# Automatically generated file; DO NOT EDIT.
#

BR2_EXTERNAL ?= /work
export BR2_EXTERNAL_NAMES = 
BR2_EXTERNAL_DIRS = 
BR2_EXTERNAL_MKS = 

BR2_EXTERNAL_NAMES += MSD
BR2_EXTERNAL_DIRS += /work
BR2_EXTERNAL_MKS += /work/external.mk
export BR2_EXTERNAL_MSD_PATH = /work
export BR2_EXTERNAL_MSD_DESC = MSD-Linux Buildroot external tree
export BR2_EXTERNAL_MSD_VERSION = v0.0.0-51-g8a4f3cb-dirty
