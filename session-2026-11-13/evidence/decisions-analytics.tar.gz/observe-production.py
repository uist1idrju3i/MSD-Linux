import asyncio
import datetime
import json
from pathlib import Path
from playwright.async_api import async_playwright

async def main():
    out = Path(__file__).parent / "production"
    requests = []
    results = []
    async with async_playwright() as p:
        browser = await p.chromium.launch(executable_path="/usr/bin/google-chrome", args=["--no-sandbox"])
        context = await browser.new_context()
        context.on("request", lambda r: requests.append({"url": r.url, "method": r.method, "type": r.resource_type}))
        page = await context.new_page()
        console = []
        page.on("console", lambda m: console.append({"type": m.type, "text": m.text}))
        for name, url in [
            ("browser-index", "https://muromi.moe/"),
            ("browser-404", "https://muromi.moe/__msd-analytics-probe-20261113-not-found"),
        ]:
            response = await page.goto(url, wait_until="networkidle")
            (out / (name + ".html")).write_bytes(await response.body())
            results.append({
                "name": name, "url": url, "utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
                "status": response.status, "headers": await response.all_headers(),
                "user_agent": await page.evaluate("navigator.userAgent"),
                "scripts": await page.locator("script").evaluate_all("(xs) => xs.map(x => ({src: x.src, beacon: x.getAttribute('data-cf-beacon')}))"),
            })
        await page.goto("about:blank")
        await context.close()
        await browser.close()
    (out / "browser.json").write_text(json.dumps({"pages": results, "requests": requests, "console": console}, indent=2) + "\n")
    for r in results:
        print(r["name"], "status", r["status"], "scripts", r["scripts"])
    print("RUM requests:", [r for r in requests if "/cdn-cgi/rum" in r["url"]])

asyncio.run(main())
