import csv
import datetime
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess

repo = Path("/home/devin-worker/repos/MSD-Linux")
fs = Path("/home/devin-worker/fscmp")
data = repo.parent / "MSD-Linux-session-data/session-2026-11-13/evidence"
manifest = data / "remaining-binaries-sha256.csv"
snapshot = subprocess.check_output(["git", "-C", str(data), "rev-parse", "HEAD"], text=True).strip()
remote = subprocess.check_output(["git", "-C", str(data), "ls-remote", "origin", "refs/heads/data/fs-compare-experiments"], text=True).split()[0]
assert remote == snapshot == "5375e420a6d0704f651f5f285c8345d658f88b34"
saved = subprocess.check_output(["git", "-C", str(data), "cat-file", "blob", snapshot + ":session-2026-11-13/evidence/remaining-binaries-sha256.csv"])
assert saved == manifest.read_bytes()
rows = list(csv.DictReader(manifest.open()))
original = list(csv.DictReader((data / "remaining-binaries.csv").open()))
assert len(rows) == len({r["path"] for r in rows}) == 251
assert [r["path"] for r in rows] == [r["path"] for r in original]
tracked = set(subprocess.check_output(["git", "-C", str(repo), "ls-files"], text=True).splitlines())
paths = []
for row in rows:
    prefix, relative = row["path"].split("/", 1)
    assert prefix in {"repo", "fs-compare-local"} and ".." not in Path(relative).parts
    p = (repo if prefix == "repo" else fs) / relative
    assert prefix != "repo" or relative not in tracked
    assert not any(x.is_symlink() for x in [p, *p.parents])
    assert p.suffix not in {".pem", ".key"} and "private" not in p.name.lower()
    s = p.stat()
    assert stat.S_ISREG(s.st_mode)
    assert (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns) == tuple(int(row[k]) for k in ("device", "inode", "size", "mtime_ns", "ctime_ns")), p
    paths.append(p)
open_paths = []
unreadable_processes = 0
for process in Path("/proc").iterdir():
    if not process.name.isdecimal():
        continue
    try:
        fds = list((process / "fd").iterdir())
    except FileNotFoundError:
        continue
    except PermissionError:
        unreadable_processes += 1
        continue
    for fd in fds:
        try:
            target = Path(os.readlink(fd))
        except (FileNotFoundError, PermissionError):
            continue
        if target in paths:
            open_paths.append(str(target))
assert not open_paths, open_paths
report = {
    "user_approval_date": "2026-11-13",
    "snapshot_commit": snapshot,
    "snapshot_sha256": hashlib.sha256(saved).hexdigest(),
    "snapshot_scope": "pre-deletion; not proof of identity with measurement-time state",
    "apparent_bytes": sum(int(r["size"]) for r in rows),
    "per_path_allocated_bytes": sum(int(r["allocated_bytes"]) for r in rows),
    "unreadable_process_fd_directories": unreadable_processes,
    "kept": [],
    "deleted": [],
}
os.sync()
report["before_utc"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
report["df_before"] = subprocess.check_output(["df", "-B1", "--output=source,size,used,avail,target", str(repo), str(fs)], text=True)
for row, p in zip(rows, paths):
    s = p.stat()
    assert not p.is_symlink()
    assert (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns) == tuple(int(row[k]) for k in ("device", "inode", "size", "mtime_ns")), p
    p.unlink()
    report["deleted"].append(row["path"])
assert all(not p.exists() for p in paths)
os.sync()
report["after_utc"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
report["df_after"] = subprocess.check_output(["df", "-B1", "--output=source,size,used,avail,target", str(repo), str(fs)], text=True)
output = data / "binary-deletion-report.json"
assert not output.exists()
output.write_text(json.dumps(report, indent=2) + "\n")
print("ok - exact inventory paths deleted:", len(report["deleted"]))
print("kept:", report["kept"])
print("apparent bytes:", report["apparent_bytes"])
print("per-path allocated bytes:", report["per_path_allocated_bytes"])
print(report["df_before"], report["df_after"])
