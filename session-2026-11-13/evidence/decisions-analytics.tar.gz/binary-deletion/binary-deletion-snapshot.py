import concurrent.futures
import csv
import datetime
import hashlib
import json
import os
from pathlib import Path
import stat

repo = Path("/home/devin-worker/repos/MSD-Linux")
data = repo.parent / "MSD-Linux-session-data/session-2026-11-13/evidence"
rows = list(csv.DictReader((data / "remaining-binaries.csv").open()))
assert len(rows) == 251 and len({r["path"] for r in rows}) == 251

def resolve(name):
    if name.startswith("repo/"):
        p = repo / name.removeprefix("repo/")
    elif name.startswith("fs-compare-local/"):
        p = Path("/home/devin-worker/fscmp") / name.removeprefix("fs-compare-local/")
    else:
        raise ValueError(name)
    assert ".." not in p.parts
    assert not any(x.is_symlink() for x in [p, *p.parents])
    assert p.suffix not in {".pem", ".key"} and "private" not in p.name.lower()
    assert stat.S_ISREG(p.stat().st_mode)
    return p

paths = [resolve(r["path"]) for r in rows]
def snapshot(item):
    row, p = item
    before = p.stat()
    with p.open("rb") as f:
        assert (os.fstat(f.fileno()).st_dev, os.fstat(f.fileno()).st_ino) == (before.st_dev, before.st_ino)
        digest = hashlib.file_digest(f, "sha256").hexdigest()
    after = p.stat()
    assert (before.st_size, before.st_mtime_ns, before.st_ctime_ns, before.st_ino) == (after.st_size, after.st_mtime_ns, after.st_ctime_ns, after.st_ino), p
    return {
        "path": row["path"], "sha256": digest, "size": after.st_size,
        "allocated_bytes": after.st_blocks * 512,
        "mtime_ns": after.st_mtime_ns,
        "mtime_utc": datetime.datetime.fromtimestamp(after.st_mtime, datetime.timezone.utc).isoformat(),
        "device": after.st_dev, "inode": after.st_ino, "ctime_ns": after.st_ctime_ns,
        "snapshot_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    }

with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    results = []
    for result in pool.map(snapshot, zip(rows, paths)):
        results.append(result)
        if len(results) % 25 == 0:
            print("hashed", len(results), "of 251", flush=True)
with (data / "remaining-binaries-sha256.csv").open("w", newline="") as f:
    writer = csv.DictWriter(f, fieldnames=list(results[0]), lineterminator="\n")
    writer.writeheader()
    writer.writerows(results)
print("ok - pre-deletion hashes, size and mtime recorded:", len(results), flush=True)
