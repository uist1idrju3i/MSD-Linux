import asyncio
import functools
import http.server
import json
from pathlib import Path
import shutil
import subprocess
import threading
from playwright.async_api import async_playwright

async def main():
    out = Path(__file__).parent / "site"
    shutil.copytree("public_html", out / "after" / "public_html")
    summary = {"text": [], "pixels": [], "self_fetch": []}
    servers = []
    for stage in ("before", "after"):
        directory = out / stage / "public_html"
        for name in ("index.html", "404.html"):
            for kind, args in [
                ("w3m40", ["w3m", "-T", "text/html", "-dump", "-cols", "40", "-o", "display_charset=UTF-8"]),
                ("w3m80", ["w3m", "-T", "text/html", "-dump", "-cols", "80", "-o", "display_charset=UTF-8"]),
                ("lynx80", ["lynx", "-stdin", "-dump", "-nolist", "-width=80", "-display_charset=utf-8", "-assume_charset=utf-8"]),
            ]:
                result = subprocess.run(args, input=(directory/name).read_bytes(), capture_output=True, check=True)
                (out / f"{stage}-{name}.{kind}.txt").write_bytes(result.stdout)
        handler = functools.partial(http.server.SimpleHTTPRequestHandler, directory=str(directory.resolve()))
        server = http.server.ThreadingHTTPServer(("127.0.0.1", 0), handler)
        threading.Thread(target=server.serve_forever, daemon=True).start()
        servers.append(server)
    modes = [
        (320,170,"light","none"), (320,170,"dark","none"),
        (800,360,"light","none"), (800,360,"dark","none"),
        (1280,800,"light","none"), (1280,800,"dark","none"),
        (320,170,"light","active"),
    ]
    async with async_playwright() as p:
        browser = await p.chromium.launch(executable_path="/usr/bin/google-chrome", args=["--no-sandbox"])
        for stage, server in zip(("before","after"), servers):
            for name in ("index.html", "404.html"):
                for width,height,scheme,forced in modes:
                    context = await browser.new_context(viewport={"width":width,"height":height}, color_scheme=scheme, forced_colors=forced)
                    page = await context.new_page()
                    await page.goto(f"http://127.0.0.1:{server.server_port}/{name}", wait_until="networkidle")
                    stem = f"{name}-{width}x{height}-{scheme}-{forced}"
                    ranges = ("first","full") if width==320 and forced=="none" else (("full",) if width==1280 else ("first",))
                    for scope in ranges:
                        await page.screenshot(path=str(out/f"{stage}-{stem}-{scope}.png"), full_page=scope=="full")
                    if (width,scheme,forced)==(320,"light","none"):
                        result = await page.evaluate("fetch('site.css').then(r=>r.status).catch(e=>e.name)")
                        assert result == ("TypeError" if stage=="before" else 200), (stage,name,result)
                        summary["self_fetch"].append({"stage":stage,"page":name,"result":result})
                    await context.close()
        await browser.close()
    for before in sorted(out.glob("before-*.txt")):
        after = out / before.name.replace("before-","after-",1)
        assert before.read_bytes() == after.read_bytes(), before
        summary["text"].append(before.name)
    for before in sorted(out.glob("before-*.png")):
        after = out / before.name.replace("before-","after-",1)
        assert before.read_bytes() == after.read_bytes(), before
        summary["pixels"].append(before.name)
    for server in servers:
        server.shutdown()
        server.server_close()
    summary["versions"] = {
        "w3m": subprocess.run(["w3m","-version"],capture_output=True,text=True).stderr,
        "lynx": subprocess.check_output(["lynx","-version"],text=True),
        "chrome": subprocess.check_output(["google-chrome","--version"],text=True),
        "playwright": subprocess.check_output(["output-pqc-decision-analytics/venv/bin/playwright","--version"],text=True),
    }
    (out/"results.json").write_text(json.dumps(summary,indent=2)+"\n")
    print("ok - text browser before/after pairs identical:", len(summary["text"]))
    print("ok - screenshot before/after pairs byte-identical (pixel difference 0):",len(summary["pixels"]))
    print("ok - same-origin fetch blocked before and permitted after:",len(summary["self_fetch"]),"cases")

asyncio.run(main())
