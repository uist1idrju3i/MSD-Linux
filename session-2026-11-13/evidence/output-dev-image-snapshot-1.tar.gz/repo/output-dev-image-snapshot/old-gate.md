## 開発用イメージの検査結果

| 区分 | 検出数 | 公開ゲート対象 |
|---|---:|---:|
| 脆弱性 | 1732 | 6 |
| 秘密情報 | 0 | 0 |
| 設定不備 | 0 | 0 |

### 検出事項
- HIGH Vulnerability `CVE-2026-109518`（apt）、対象 `/work/old.tar (debian 13.7)`（修正版: `3.0.4`）
- HIGH Vulnerability `CVE-2026-109518`（libapt-pkg7.0）、対象 `/work/old.tar (debian 13.7)`（修正版: `3.0.4`）
- HIGH Vulnerability `CVE-2026-76844`（zlib1g）、対象 `/work/old.tar (debian 13.7)`（修正版: `1:1.3.dfsg+really1.3.1-1+deb13u1`）
- HIGH Vulnerability `CVE-2026-85091`（zlib1g）、対象 `/work/old.tar (debian 13.7)`（修正版: `1:1.3.dfsg+really1.3.1-1+deb13u1`）
- HIGH Vulnerability `CVE-2026-76844`（zlib1g-dev）、対象 `/work/old.tar (debian 13.7)`（修正版: `1:1.3.dfsg+really1.3.1-1+deb13u1`）
- HIGH Vulnerability `CVE-2026-85091`（zlib1g-dev）、対象 `/work/old.tar (debian 13.7)`（修正版: `1:1.3.dfsg+really1.3.1-1+deb13u1`）
