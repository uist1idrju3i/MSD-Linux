# 利用者が行う作業（2026-11-15 セッション終了時点）

## PR のマージ（stacked、順序注意）
下から順にマージしてください。base は GitHub が自動で付け替えます。

1. PR #245 — /data 初回起動書き込み帰属 + zram 起動時間比較（base: main）
   https://github.com/uist1idrju3i/MSD-Linux/pull/245
2. PR #246 — verity+FEC / LUKS+btrfs 設計調査と測定計画（base: #245 のブランチ）
   https://github.com/uist1idrju3i/MSD-Linux/pull/246
3. PR #247 — kernel 構成 + verityfmt + 測定 harness + B2/B3 実験記録（base: #246 のブランチ）
   https://github.com/uist1idrju3i/MSD-Linux/pull/247
4. PR #248 — E34 matrix 実験記録（base: main、独立）
   https://github.com/uist1idrju3i/MSD-Linux/pull/248

- CVE scan の失敗は NVD feed 鮮度の既知インフラ問題（main でも同じ）で、変更とは無関係です。
- PR #247 にはセッション終了直前の push（f4d6af6）に対する Devin Review が走っています。新しい指摘が出た場合は次セッションで対応します。

## 判断をお願いしたいこと（design doc の「未解決」節より）

- rootfs verity の hash_alg: 暫定 crc32c（formatter 自前実装済み・QEMU 起動確認済み）。最終は実機での全ハッシュ throughput 計測後に確定。
- verity error mode: 暫定 panic_on_corruption → tryboot → A/B 切り戻し。F3（最上位 hash block 破損）は FEC で修復できず panic になることを確認済み。
- SquashFS zstd level: l19 vs l22 で展開側差なしを測定済み。l22 採用可否のご確認。
- LUKS cipher: 暫定 aes-xts-plain64。実機で全 cipher/全 hash をベンチしてセキュリティビット数と性能で最終決定（Camellia 等も対象）。
- btrfs data=metadata dup の容量倍率、compress-force の採否、LUKS keyfile の保管場所、zswap/zram 併存の可否。
- btrfs 移行後に CONFIG_EXT4_FS + e2fsprogs を削る方針のご承認。

## 実機が手元に届いたら
docs/research/verification/hardware-measurements.md の「storage 完全性・暗号化（2026-11-15 方針分）」の 11 項目を実施してください（cipher/hash 全ベンチ、verity+FEC 起動・破損時挙動、tryboot 連携、btrfs dup/圧縮、電源断反復など）。QEMU の性能値は参考順位のみです。
