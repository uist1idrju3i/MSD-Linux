# 復元限界: msd-linux-plan-2026-11-15.md

これは添付の原文コピーではない。提供dumpのcreate/editイベントは本文を含まずcontents_keyのみであり、認証付き添付本文も未取得。以下は確認できるメタデータと会話原文の再収録。欠損箇所を創作していない。

添付URL: `https://app.devin.ai/attachments/f6c4be80-12ae-42b7-a8da-61aa6f1e15bb/msd-linux-plan-2026-11-15.md`

期待hash: `e65483c909da2fb7ea7614f467e7edae874711ce8fc5eef9f925cb470ab73d14`

## ファイル書き込みイベント

```json
[
  {
    "id": "event-01a1dd589b0f710296a8b058cd929632",
    "data": {
      "type": "multi_edit_result",
      "timestamp": "2026-11-15T03:55:34.031000Z",
      "is_major_action": true,
      "file_updates": [
        {
          "action_type": "create",
          "file_path": "/home/ubuntu/handoff/msd-linux-plan-2026-11-15.md",
          "lines_added": 189,
          "contents_key": "editor_files/devin-03914d06ecff4447a74024c8c9c5eabc/9d60b499-81d4-46a2-ab70-8c2972521166.txt"
        }
      ],
      "has_write": true,
      "action_uuid": "write:41"
    }
  }
]
```

## 関連する会話原文

### event-01a1dd58c2c0773096adfed6d54ffa28

全体計画（`docs/research/roadmap.md` + <ref_file file="/home/ubuntu/repos/MSD-Linux/docs/research/pending-work.csv" live="true"/> の R01–R44）と origin/main `733d27e` の実装・CI・進行中 PR を照合しました。監査結果と今後の深い計画を添付の計画書にまとめました。

要点：
- リリース（v0.1.0）は未達。現行は「RO rootfs + ext4 /data + A/B + 手動署名更新」まで。ネットワーク・認可・暗号化・自動更新は未実装。
- 2026-11-15 の新方針（rootfs=verity+FEC、/data=LUKS+btrfs）が stacked PR #245–#247 で進行中。台帳の R16/R36/R37 行はこの方針転換を未反映。
- product CVE scan が現在失敗中：上流 NVD feed が 2 日停滞（正しく検出して落としている）。feed 冗長化・代替を検討候補に。
- 計画は Phase S（進行中 stack の完了と B1–B7 測定）→ A（認可・境界・通信、R03→R02→R04→R07→R05/06）→ B（ストレージ製品化）→ H（実機）→ R（release readiness）→ M（保守監視）の順。実機を待たずに進められるものを先に潰す構成です。

計画を進める前に、下の4点を確認させてください。

ATTACHMENT:{"url":"https://app.devin.ai/attachments/f6c4be80-12ae-42b7-a8da-61aa6f1e15bb/msd-linux-plan-2026-11-15.md","fileSize":17224}

