# 復元限界: msd-boot-slot-display-memo-2026-11-15.md

これは添付の原文コピーではない。提供dumpのcreate/editイベントは本文を含まずcontents_keyのみであり、認証付き添付本文も未取得。以下は確認できるメタデータと会話原文の再収録。欠損箇所を創作していない。

添付URL: `https://app.devin.ai/attachments/1ea71a54-a87b-4724-9c36-f2404ddc1509/msd-boot-slot-display-memo-2026-11-15.md`

期待hash: `ad23993a93ea9e1eec00418dbb58dc7302057631db961afab9a6c89878f55e7a`

## ファイル書き込みイベント

```json
[
  {
    "id": "event-01a1ddd8cc117892aaa597179096843f",
    "data": {
      "type": "multi_edit_result",
      "timestamp": "2026-11-15T06:15:35.185000Z",
      "is_major_action": true,
      "file_updates": [
        {
          "action_type": "create",
          "file_path": "/home/ubuntu/handoff/msd-boot-slot-display-memo-2026-11-15.md",
          "lines_added": 36,
          "contents_key": "editor_files/devin-03914d06ecff4447a74024c8c9c5eabc/2ebc4bb2-dfdc-47b1-bce6-4546397197a9.txt"
        }
      ],
      "has_write": true,
      "action_uuid": "write:55"
    }
  }
]
```

## 関連する会話原文

### event-01a1ddc9b20a7fd1b8102b6fc1e82631

起動 slot の識別方法（/proc/cmdline の root= 等）とバナー表示位置を調べて、A=青丸/B=緑丸の実装可否を確認します。

### event-01a1ddcae0897ee289aaf05edb3c3cb3

調査の結果、**可能です**。起動 slot は既に確実に判定できる経路があり、表示位置と色の実装も既存の仕組みで実現できます。

**判定方法（実装済みの経路を再利用）**
- `/proc/device-tree/chosen/bootloader/partition`（BE32）：firmware tryboot が書き込む起動 partition（2=A / 3=B）。`msd-update status` が既に同じ node を読んでいます。隣の `tryboot` node で「試行起動か確定済みか」も分かります。
- fallback：`/proc/cmdline` の `root=`（`cmdline_rootfs_a.txt`=`mmcblk0p5`、b=`p6`）。QEMU も `root=$ROOT_DEVICE` を append するので QEMU で検証可能。DT node が無い環境（QEMU 含む）の代替として使えます。

**表示位置**
`MSD/Linux ready` は `S98msd-ready` が `/dev/console` へ出す最後の行です。バナーより前に出すなら、`S00msd-slot`（仮名）を新設して rcS の `mount -a` 直後に出すのが自然です。`/proc` は fstab で既に mount 済みなのでその時点で DT node を読めます。`quiet` 指定なので LCD 上は最初に見える行になります。

**色の出し方**
- `console=tty1`（LCD の fbcon）と `serial0` の両方が `quiet` 下でも userspace 出力を通します。色付きは `/dev/tty1` へ ANSI escape（例: `\033[34m●\033[0m`）、serial には色なし文字を出すのがきれいです。
- 注意点：fbcon の kernel 内蔵 font は glyph が少なく、`●`(U+25CF) が描画されるかは要確認です。安全な案は**色付きの `A`/`B` 文字または色背景**（青=A、緑=B）。kbd は既に入っているので `setfont` で ● を含む font を読み込む強化案もあります。
- `tryboot=1` の試行起動は表示を変えられます（確定=●、試行=○、または `B(try)` 等）。
- §10 の英日併記ルールにより、文字を出すなら例えば `Slot A / A面` 形式。色の丸だけなら記号扱いで解釈の余地があります。

**利用者判断（実装に進む場合）**
1. 表示内容：色だけの丸か、`Slot A` 等の文字か、両方（英日併記）か
2. 文字の形：● が描画されなければ色付き `A`/`B` 文字に倒すか、setfont 対応するか
3. tryboot 試行の区別を出すか
4. 表示位置は `S00`（起動最初）でよいか

QEMU では cmdline fallback 側の動作確認が可能、色と glyph の見え方は実機確認が必要です。今は調査・計画のみの範囲として回答しています。実装する場合は設計メモを先に出します。

### event-01a1ddcdc39f7cb3a57564f185bc5bb3

現在のバナー相当の表示を確認しました。

**現在の起動表示（console=tty1 / serial、quiet 指定）**
1. init script 出力が数行：`msd-data: /data ...`、`MSD hardware: ...`、（module 検査行）
2. **`MSD/Linux ready`**（`S98msd-ready` が出す最後の1行）← 実質のバナー
3. getty の `/etc/issue`（Buildroot 既定の `Welcome to Buildroot`）+ `buildroot login:`

つまり「MSD/Linux の文字」を含む表示は `MSD/Linux ready` の1行だけなので、`(A) MSD/Linux ready` または `MSD/Linux ready (A)` のように**同じ1行に前後どちらでも収まります**（20 文字前後）。

**実装上の確認済みポイント**
- この文字列は test-powerfail / test-watchdog / test-qemu / boottime 測定が marker として grep していますが、すべて部分一致なので、行に `(A)` を足しても `MSD/Linux ready` が残る限り既存試験は壊れません。
- `msd.sweep=1` 時は kmsg 経由（`<6>MSD/Linux ready`）なので、そちらにも同じ slot 付与を行うか決めます（QEMU 時刻測定用）。付けるなら `<6>(A) MSD/Linux ready` で同様に部分一致維持。
- 判定：実機は `/proc/device-tree/chosen/bootloader/partition`（+`tryboot` node で小文字判定）、QEMU 用 fallback は `/proc/cmdline` の `root=/dev/mmcblk0p5`(A)/`p6`(B)。tryboot=1 なら `(a)`/`(b)`。
- 判定不能時の表示：`(?)` にするか marker を出さないか（提案：見えない失敗より `(?)` を出す）。

形式の確定案：**`(A) MSD/Linux ready`**（先頭に slot 表示）。実装自体は S98msd-ready の printf 1 行＋判定の数行です。

これは実装に進めますか？（今のご指示は「調査と計画まで、コミット・プッシュなし」なので、実装する場合もブランチ作成・PR までは行わず、変更箇所の提示までに留めることもできます）

### event-01a1ddcfbc01789293503dc74c10d2ef

ご認識のとおりでした。コミットハッシュが出るのは `MSD/Linux ready` ではなく、**getty のログインバナー `/etc/issue`** でした。`write-version-info.sh` がビルド時に `MSD/Linux vX.Y.Z (YYYY-MM-DD HH:MM:SS JST, commit abc1234)`（または `unreleased (commit unknown)`）を書き込みます。`MSD/Linux ready` は version なしの literal です。

起動時の「MSD/Linux」表示は実は2箇所あります：

| 表示 | 内容 | slot 付与の方法 |
|---|---|---|
| `MSD/Linux ready`（S98、毎回の起動時に console へ） | 固定1行 | `(A) MSD/Linux ready` —— printf に前置するだけ |
| `/etc/issue`（login prompt の直前） | `MSD/Linux vX.Y.Z (…, commit abc1234)` | 静的ファイルなので、init script が起動時に `/etc/issue` を生成し直して ` (A)` を末尾に付ける（/etc overlay の tmpfs upper へ書くので実機 SD への書込みなし） |

形式の提案：
- ready 行: `(A) MSD/Linux ready` / tryboot 中 `(a) MSD/Linux ready`
- issue: `MSD/Linux v0.1.0 (2026-11-15 ..., commit abc1234) (A)` / tryboot 中 `(a)`

どちらに付けますか？（ready 行のみ / issue のみ / 両方）ready 行は起動のたびに必ず出ますが、issue は login prompt 表示時のみです。

### event-01a1ddd2fae77d11ab977dce803d17b8

重要な点を確認しました。`/dev/console` は cmdline の**最後の** `console=`（serial0）に向くため、userspace の出力は LCD には出ません。以下が再構成した全行です。

**serial0（/dev/console 宛。実質ここに全出力）**

```
（kernel printk。quiet 指定なので ERR 以上のみ、通常ほぼ無し）
data: clean, 36/65536 files, 7239/262144 blocks        ← S02 の fsck.ext4 -p（初回起動は mkfs.ext4 + resize2fs の出力）
msd-data: /data rw,noatime,nodev,nosuid,data=ordered    ← S02msd-data
MSD hardware: model=standard imu=present                ← S97msd-hwinfo（非同期なので出現位置は不定）
MSD/Linux ready                                         ← S98msd-ready
（tryboot 試行起動時のみ追加）Committed slot A (boot partition 2).  ← S99msd-health → msd-update commit

MSD/Linux v0.0.0 (2026-11-03 16:38:xx JST, commit abc1234)  ← /etc/issue（getty、write-version-info.sh 生成）
msd login:                                                ← getty（hostname=msd）
```

**LCD（tty1）**: kernel printk のみ。`quiet` で警告未満は非表示なので、現状ほぼ真っ暗のままです。`/dev/console` への userspace 出力（`MSD/Linux ready` 含む）は**LCD に出ません**。

**QEMU（ttyAMA1 のみ・quiet 無し）**: kernel 全メッセージ + 上記 userspace 出力 + `msd-module-check: <mod> loaded...` 3 行（試験用 append）。

つまり「`(A)` を LCD の起動画面に出す」場合は `/dev/console` ではなく **`/dev/tty1` へ明示的に書く必要があります**（fbcon 経由）。serial 側にも出すなら両方へ書けばよいです。

案（ご希望の形式で）:
- serial の ready 行: `(A) MSD/Linux ready`（`MSD/Linux ready` の substring は維持＝試験安全）
- LCD: `(A)` を `/dev/tty1` に S 番号の早い段階 or S98 で表示。tryboot 中は `(a)`
- issue（serial の login 前）にも付けるなら `MSD/Linux v0.0.0 (…, commit abc1234) (A)` —— init で再生成が必要

実測の全行はビルド（約1〜2時間）または実機が必要です（v0.0.0 release に asset 未添付）。QEMU で実測を取るならビルドを開始しますが、どうしますか？また表示位置は「ready 行の先頭 + LCD への `/dev/tty1` 出力」で進めてよいですか？

### event-01a1ddd6a4517750a1cbde0a4c5db7f2

了解です。serial と LCD 両方に出し、issue には付けません。ワーディング案を絞りました。

**候補（通常起動 / tryboot 試行）**

| 案 | 通常 | tryboot 中 |
|---|---|---|
| A | `Boot from slot A` | `Boot from slot A (try)` |
| B | `Booted from slot A` | `Booted from slot A (trial)` |
| C | `Boot: slot A` | `Boot: slot A (tryboot)` |

推奨は **A**（ご提示の形で簡潔、`try` が短い）。trial/commit は update の用語と揃えて `(try)` or `(trial)` に留めるのが自然です。

**1点確認：LCD の英日併記（AGENTS.md §10）**
LCD は製品画面なので、利用者向け文言は英日併記がルールです。案：
- 併記1行： `Boot from slot A (try) / A面から起動（試行）`
- 2行： `Boot from slot A (try)` の下に `A面から起動（試行）`
- serial は従来どおり英語のみ（boot log も既に英語）、LCD だけ英日にするか、両方同じ併記にするか

**表示の形（serial 側）**
`MSD/Linux ready` は試験 marker なので温存し、その前に別行で：
```
Boot from slot A
MSD/Linux ready
```
という形が最も安全です（ready 行を変更しない）。

決めてほしいのは2点：①ワーディング案（A/B/C）、②英日併記の仕方（serial は英語のみ＋LCD は英日併記、または両方併記）。実装は指示なしでは始めません（コミット・プッシュもしません）。

### event-01a1ddd8e7e37132ac9569295e9817d6

A案・LCD英語のみで設計メモを作りました（添付）。

要点：
- `S98msd-ready` に追加（新規 script なし）。serial は `Boot from slot A` を `MSD/Linux ready` の直前に別行、LCD は `/dev/tty1` に2行（slot 行＋ready 行）。QEMU 等 tty1 無しは skip。
- 判定は `msd-update status`（DT node、tryboot 含む）を再利用し、失敗時は `/proc/cmdline` の `root=p5/p6` で fallback。判定不能は `Boot from slot ?`。
- QEMU では fallback 経路を serial log で確認可能。DT 経路と LCD 表示は実機確認項目。

この設計で実装に進めますか？（指示があればブランチで変更します。コミット・プッシュは指示があるまで行いません）

ATTACHMENT:{"url":"https://app.devin.ai/attachments/1ea71a54-a87b-4724-9c36-f2404ddc1509/msd-boot-slot-display-memo-2026-11-15.md","fileSize":2670}

