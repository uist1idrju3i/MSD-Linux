# 2026-11-15 中断メモと新タスク計画

## 1. 中断した作業: E3/E4 fs-compare matrix

- 状態: **中断済み**（driver に SIGTERM、全 QEMU 停止）。監視 reminder `e34-matrix-progress-check` 削除済み。
- 進捗: **87/174 run 記録**（83 ok + 4 件が `fail:terminated_signal_15`）。0 件の真の失敗なし。
- 場所: `/home/devin-worker/fscmp/MSD-Linux/output-e34/runs/e34-2026-11-15/`（progress.log, matrix-summary.csv, plan.tsv）。plan は `/home/devin-worker/fscmp/plans/e34-2026-11-15.tsv`。
- 残り: 87 run（T5 主体）。ETA は中断時点で約5時間（-j4）。
- **再開手順**: matrix script は再開対応済み（summary.csv のある run は skip、fail は再実行）。
  ```sh
  cd /home/devin-worker/fscmp/MSD-Linux
  docker/msd-dev bash board/cardputerzero/tools/bench/fs-compare-matrix.sh -j 4 \
    --matrix-id e34-2026-11-15 --runs-dir /work/output-e34/runs /work/output-e34/plan.tsv \
    > output-e34/driver-resume.log 2>&1
  ```
- **完了後の残作業**: matrix-summary.csv 集計 → `docs/experiments/2026-11-15-fs-compare-matrix.md` + 同名 csv → output-e34 を data/fs-compare-experiments 枝（/home/devin-worker/repos/MSD-Linux-session-data、worktree）に archive（`*.img`・`image-build*`・`target` 除外、各 file <100MB、SHA256SUMS 更新）→ experiments README 索引更新 → `devin/1794692686-measure-2026-11-15` を base に stacked PR。

## 2. その他の未解決事項（中断時点）

- PR #245（E1/E2 記録）: open。Devin Review が 8b26e9a で走行中の可能性。新しい findings が来たら triage。
- CI「product CVE scan」失敗 = main 枝でも同じ失敗を確認済み（NVD feed 鮮度の infra 問題、PR 無関係）。
- data 枝: e1/e2 archive push 済み（tip 0899f05）。
- 未測定の blocked 項目: P085（btrfs-progs が option 非対応）、P087/T6（harness 非対応）。

## 3. 新タスク（ユーザー指示 2026-11-15 10:44 JST）

製品設計を次の方針にするための**深い調査・深い検討・深い計画と実施**、結果は research に保存：

- **root**: SquashFS + zstd + dm-verity（crc32c）+ FEC。破損検出時は A/B boot で切り戻し。
- **data**: LUKS + btrfs（metadata も data も dup）、checksum は xxhash64。**btrfs zstd 透過圧縮も使う**（2026-11-15 10:50 JST 追記）。
- **SquashFS, zstd, dm-verity, LUKS, btrfs の全オプションを測定**する。zstd は zram/zswap 側（comp_algorithm・kernel パラメータ）も全オプション測定対象。

### Phase A で確認済みの事実（2026-11-15 時点）

- 固定版: squashfs-tools 4.7.5、zstd 1.5.7、cryptsetup 2.8.7（dev image は 2.7.5）、btrfs-progs 6.10、kernel 6.18.59-v8 (rpi `b3495ea`)、Buildroot 2026.08.1-27。
- 現行 rootfs は既に `BR2_TARGET_ROOTFS_SQUASHFS4_ZSTD` + `EXTREME_COMP`（= `-comp zstd -b 128K -Xcompression-level 22`）。
- **veritysetup は userspace hash 計算で crc32c/xxhash64 を拒否**（sha1/sha256/sha512/ripemd160 のみ）。kernel crypto API には crc32c があるので dm table 自体は作れるが、hash tree + FEC 生成は cryptsetup の crypto backend 経由なので、自前 formatter（または cryptsetup patch）が必要な可能性が高い。
- dm-verity opt_params（kernel 6.18 doc）: ignore_corruption / restart_on_corruption / panic_on_corruption / restart_on_error / panic_on_error / ignore_zero_blocks / use_fec_from_device + fec_roots(2..24, RS(255,N)) + fec_blocks + fec_start / check_at_most_once / root_hash_sig_key_desc / try_verify_in_tasklet。
- veritysetup open/format option: --hash, --no-superblock, --format 0|1, --data-block-size, --hash-block-size, --data-blocks, --hash-offset, --salt, --uuid, --root-hash-file, --fec-device, --fec-offset, --fec-roots, --error-as-corruption, --ignore-zero-blocks, --check-at-most-once, --root-hash-signature, --use-tasklets, --shared, --deferred。
- mksquashfs 4.7.5 全 option 取得済み（`-help-all`）。zstd comp は `-Xcompression-level 1..22`（既定15、EXTREME=22）。
- genimage: p5/p6 rootfs は 256M partition 固定、squashfs image がそのまま入る。hash tree/FEC の収容設計が必要。
- 2026-10-21 実験済み: dm-verity+sha256+panic_on_corruption+dm-mod.create で T0 起動 OK、T1-T5 検出動作確認。FEC と crc32c は未試行。
- btrfs xxhash64: `mkfs.btrfs --csum xxhash`（alias=xxhash64）、kernel は `CONFIG_BTRFS_FS`+`XXHASH`。現行 fragment は `# CONFIG_BTRFS_FS is not set`。
- DM 系は linux.fragment に一切記述なし。実測 `.config`（output-zram-m、rpi 6.18.59 + fragment）: `DM_VERITY=m` / `DM_CRYPT=m` / `DM_INTEGRITY=m`（=m で起動時検証には initramfs か =y 化が必要）、`DM_VERITY_FEC`・`DM_VERITY_VERIFY_ROOTHASH_SIG` 未設定、`CRYPTO_CRC32C=m`、`XXHASH=y`、`REED_SOLOMON=y`、`CRYPTO_ZSTD=m`、`ZRAM=m`（multi_comp、既定 zstd、backend lz4/zstd/lzo）、`ZSWAP=y`（既定 lzo・default_on 未設定）、`BTRFS_FS` 未設定。
- 必要 kernel 差分: DM_VERITY=y / DM_VERITY_FEC=y / DM_CRYPT=y / CRYPTO_CRC32C=y / XXHASH（済み）/ BTRFS_FS=y / CRYPTO_ZSTD=y（btrfs zstd 圧縮に必要）。

### Phase A 完了・Phase B 進捗（2026-11-15 13:00 JST 頃）

- **Phase A 完了**: `docs/research/storage/` に3文書（rootfs-squashfs-verity-fec-design.md、data-luks-btrfs-design.md、zstd-usage-and-options.md）+ product-decisions 3行記録。[PR #246](https://github.com/uist1idrju3i/MSD-Linux/pull/246)（stacked on `devin/1794692686-measure-2026-11-15`）。review 指摘5件を修正（dm-mod.create 構文、ZRAM=y、blake2b、事前登録明記、文書名）→ commit `77bf8a9`。
- **Phase B 着手**: mksquashfs 圧縮 matrix（host 側速報）を `/home/devin-worker/fscmp/MSD-Linux/output-opt-mtx/` で実行完了（46 run、target=output-fscmp/target 46MB）。
  - `cryptsetup benchmark`: host の algif_skcipher 非搭載で cipher throughput は測れず（PBKDF のみ出力、`output-opt-mtx/cryptsetup-benchmark.txt`）→ cipher 測定は QEMU guest 側で行う必要。
  - 速報値: xz 128K=22.21MB / zstd 128K default=23.90MB / **zstd 1M l19=l22=22.37MB（xzにほぼ匹敵）** / zstd 512K l22=22.97MB / lz4=30.84MB / gzip=25.11MB。build 1-3s/個。
  - 本データは単発の速報。正式記録は experiment-record 事前登録後に docs/experiments/ + data 枝へ。
- 残 Phase B: QEMU guest での verity/FEC/LUKS/btrfs/zram/zswap 実測。dev image に mkfs.btrfs・zstd CLI が無い（要 tool 追加）、verity crc32c formatter 要自前。E34 matrix 87/174 は中断中（再開コマンド前文）。
- **事前登録済み**: `docs/experiments/2026-11-15-storage-options-prereg.md`（B1 SquashFS matrix / B2 QEMU read / B3 verity+FEC+破損注入 / B4 LUKS cipher / B5 btrfs / B6 zram/zswap / B7 boot統合影響、各5回以上・採否基準明記）。commit `5a1a086`、実験README索引更新済み。
- **次の実装作業（Phase B の前提）**: ①kernel fragment に DM_VERITY=y/DM_VERITY_FEC/DM_CRYPT=y/CRYPTO_CRC32C=y/BTRFS_FS=y/CRYPTO_ZSTD=y 追加 ②defconfig に btrfs-progs・cryptsetup・zstd CLI の target 追加 ③crc32c verity formatter を `board/cardputerzero/tools/` に新規実装（hash tree + RS(255,N) parity）。これらは別 branch で stacked PR にする。
- **実装 branch 作成**: `devin/1794708015-kernel-config-integrity`（stacked on `devin/1794707609-verity-fec-luks-btrfs-design`）。linux.fragment に DM_VERITY/DM_VERITY_FEC/DM_CRYPT/CRYPTO_CRC32C/CRYPTO_ZSTD=y、BTRFS_FS=y 追加、defconfig に btrfs-progs/cryptsetup/zstd CLI 追加。`output-integrity` でフルビルド実行中（**shell 311b4b**、/tmp/build-integrity.log）。注意: ビルドは `docker/msd-dev` 内で行うこと（host の make は unzip 不在で即失敗した）。defconfig も /work パスで再実行済み。ビルド完了後: カーネル .config で symbol 確認→QEMU 起動確認→stacked PR 作成（base=design branch）。
- **CI 修正**: prereg doc 内の VM パスを除去（根拠ルール違反で check job 失敗、commit `67a5e4f`）。2 回目の review 指摘 2 件（zram mem_limit は sysfs、idle は WRITEBACK 不要）修正済み commit `22b6ac1`。
- 残: crc32c verity formatter 実装（`board/cardputerzero/tools/`）、QEMU 実測 B2-B7、E34 matrix 87/174 再開。

- `docs/research/storage/filesystem-options-btrfs.md` + `-btrfs-progs.md`: btrfs mkfs/mount/csum option の一次資料照合済み（crc32c/xxhash/sha256/blake2, DUP/RAID1 等）。新タスクの btrfs 方針（dup+xxhash64）はこれらに追記・更新する形で。
- `docs/research/storage/filesystem-options-luks.md`: LUKS2 全 option 照合済み（cipher, pbkdf, sector-size, integrity）。
- `docs/research/storage/filesystem-options-dm-integrity.md`, `filesystem-candidates.md`, `layout-and-flash.md`, `ab-design-history.md`, `recovery-and-watchdog.md`。
- `docs/research/pending-work.csv`: R36（dm-verity/secure boot の信頼起点、conditional・実機boot未確認）。
- 既存 bench: `tools/bench/s12-squashfs-codec`（SquashFS codec 比較）, `tools/bench/dm-verity`, `tools/bench/s17-dm-log-writes`, `tools/bench/fs-compare*`（btrfs/LUKS variant 測定済み: B1-B5, L1-L3, I1-I2）。
- fs-compare 結果: B2（btrfs dup+crc32c）は matrix 内で T4-sync/T5 対象として測定中だった。

### 深い計画（ドラフト）

**Phase A: 一次資料調査と option 全網羅**（research 保存）
1. SquashFS: mksquashfs 全 option（-comp, -b block size, -Xcompression-level, -Xhc, fragments, xattrs, exports, reproducible, offset 等）— mksquashfs man/ソース照合。
2. zstd: compression level 1-22（+ negative fast levels）、long mode、device 上の kernel decompressor の対応 level 範囲。
3. dm-verity: veritysetup format 全 option（--hash, --data-block-size, --hash-block-size, --data-blocks, --salt, --uuid, --no-superblock, --fec-device, --fec-roots, --hash-offset, --format 等）、FEC（Reed-Solomon）パラメータ、kernel dm-verity 起動時 option（panic_on_corruption, restart_on_corruption, ignore_zero_blocks, check_at_most_once, try_verify_in_tasklet, error_correction 等）。crc32c hash 対応状況（kernel + veritysetup）。
4. LUKS: 既存 filesystem-options-luks.md と照合、cipher（aes-xts vs xchacha12/20-adiantum、ARM CE の有無）、pbkdf、integrity 併用可否（btrfs の自前 csum との重複検討）。
5. btrfs: 既存 doc と照合、dup data+metadata、xxhash64 csum、mount option 全網羅。
6. 破損検出→A/B 切り戻し: dm-verity 検出時の kernel 動作（panic/restart mode）、bootloader/firmware tryboot との接続、既存 ab-design-history・recovery-and-watchdog・msd-update との整合。

**Phase B: 測定計画**（experiment-record 準拠）
- QEMU での測定 matrix: SquashFS（codec×level×block size→圧縮率・起動 read 時間・mount 時間）、zstd level 分布、dm-verity（hash algo×block size→生成時間・サイズ・起動時検証コスト、FEC overhead、破損注入での検出+訂正）、LUKS cipher（throughput）、btrfs csum（xxhash64 vs crc32c throughput）、dup の書き込み倍率。
- 「全オプション測定」の解釈: 仕様上の全 option token を網羅した測定表（測定不能は理由付き）を作る。fs-compare の既存 variant 結果を再利用。

**Phase C: 設計検討**
- product-decisions.md / write-policy.md への影響整理、pending-work.csv の R36 等との関連、懸念（btrfs の idle 書き込み規則との整合、LUKS 鍵管理、FEC の superblock 構造、A/B 切り戻しの trigger 条件）。

### 実行順序
1. このメモ + 計画ファイルを永続化
2. Phase A の調査（一次資料 + 既存 research 照合）
3. 調査結果を `docs/research/` に保存（新規 doc または既存 doc 追記）
4. Phase B の測定 script を `docs/experiments/` に準備・実行（時間のかかるものはバックグラウンド+reminder 監視）
5. 結果を実験記録 + research に保存、PR 作成

## 4. 制約・注意

- AGENTS.md: main 直 push 禁止、PR merge 禁止、実行中 script 編集禁止、証拠は data 枝、QEMU≠実機を分けて書く。
- ドキュメント・PR は日本語、JIS X 0213。20KB 超は分割検討、40KB 超は必須。
- experiment-record: ≥5 回・median/min/max・失敗試行も記録・既存 log 上書き禁止。
- 新規 PR は stacked PR（base = `devin/1794692686-measure-2026-11-15`）。
- 外部 repo への書き込みは事前承認。upstream への issue/PR はしない。

## 2026-11-15 11:45 JST 追記
- arm64-neon-crypto.md + ext4無効化方針 + B2 scripts commit push 済み（a3b773e, 9f9e96f on devin/1794708015-kernel-config-integrity）
- F0-F6 case を kmsg marker 版で再生成済み（verityfmt-bin 含む）
- B2 squashfs-opts suite 実行中: shell 556022, log /tmp/b2-run.log（7 variants x 5 boots, cases-b2/, results-b2/）
- integrity build まだ kernel compile 中（311b4b）。完了後: Image を各 F-case images/ にコピー → F0/F2 smoke → stacked PR → B3 suite
- 監視 reminder: auto-7b4faac85fdc4a46a71c5d0429cee010（45分間隔）
- E34: 95/174

## 2026-11-15 12:20 JST 追記
- integrity build 完了（BUILD_OK）。config: DM_VERITY=y, DM_VERITY_FEC=y, DM_CRYPT=y, CRYPTO_CRC32C=y, CRYPTO_ZSTD=y, BTRFS_FS=y。Image → 全 F-case + T0 にコピー済み
- F0-A2 smoke boot 成功（ready, /dev/dm-0, `device-mapper: verity: crc32c using "crc32c-lib"`, Btrfs loaded）— crc32c verity 実機構築確認
- run-boots.sh serial log 名を ROOT_DEVICE basename 由来に修正（06a39dc push 済み、repos copy のみ）。**fscmp copy は B2 suite 終了後に同期すること**（実行中スクリプトを編集しない）。B2 側は mmcblk0p5 なので影響なし
- B2 の S-z1M-l19 は case 名 regex（小文字のみ）で reject 済み → suite 終了後に `S-z1m-l19` として手動 generate+boot して補完
- docker/msd-dev に OUTPUT_DIR 等の env を外側で渡すと mount 解釈で失敗する → env は docker 内の bash -c 内で設定する
- B3 起動手順: `docker/msd-dev bash board/cardputerzero/tools/bench/dm-verity-fec/run-all.sh /work/output-fscmp /work/output-b3/cases /work/output-b3/results 4 480`（fscmp checkout から、run-boots.sh 同期後）
