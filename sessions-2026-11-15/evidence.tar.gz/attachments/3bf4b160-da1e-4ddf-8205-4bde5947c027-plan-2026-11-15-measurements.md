# 2026-11-15 実測・実験セッションの計画

参照: セッション d05e7065 の引き継ぎメモ（2026-11-13）残タスク 1, 5, 11 と、タスク 4/6/10 のうち測定系。
すべて単純作業で時間のかかる測定であり、方針判断（mount 方針、暗号化設計、RAUC 比較など）は本セッションの対象外。

## E1: `/data` 初回起動の 8320 sector（約 4.1 MiB）書き込みの帰属

仮説の分解対象: sfdisk（partition table 更新）/ resize2fs / ext4lazyinit（mkfs の lazy inode table init）/ journal などその他。

手順（全て write-inventory harness、120 秒区間、QEMU raspi3ap、TCG）:

| variant | 内容 | 期待される分離 |
|---|---|---|
| `base` | 現行 main の image のまま | 基準（前回 8320/8304 の再確認） |
| `nolazy` | data.ext4 を `lazy_itable_init=0,lazy_journal_init=0` で作り直して sdcard.img へ差し替え | 元 FS の lazy init と journal 遅延 init の寄与 |
| `grown-fs64` | partition table だけ host で拡張（FS は 64 MiB のまま） | sfdisk と resize2fs の分離 |
| `pregrown` | partition 拡張 + resize2fs まで host で済ませる | resize 機構全体を host 側へ移した残り |
| `pregrown-nolazy` | p7 を最終サイズ・lazy off の FS で作り直し | 理論下限（journal/mkdir 等のみ） |
| `mature` | 成長済み image の再起動を 5 区間 | 残存 64 sector が毎回か一回か |

各 variant は同一の測定用 image で独立 boot を 3 回（初回書き込みは boot ごとに 1 区間）。
相補的に、post-boot の p7 を dd 抽出して host 側の対応物と block 単位で差分を取り、
inode table / GDT / journal のどこに書き込まれたかを写像する（dd/sfdisk/e2image/cmp のみ、loop mount 不使用）。

製品 file は変更しない。variant image は測定用の写しに対して host 側で作る。

## E2: zram `=y` vs `=m` の起動時間比較（引き継ぎタスク 5）

- `=y`（現行）と `=m`（linux.fragment を一時的に dirty 変更 + 実験用に S99msd-zram 冒頭で insmod）を同じ warm 出力先（`output-openssl-lts`）で順に build。
- boottime harness（TCG）で初回 1 回 + 通常 5 回、ready/kernel-init/crng の中央値・最小・最大と kernel Image byte 数を比較。
- 測定は他の QEMU・build と並行させない。module は同じ tree の署名で入る（CONFIG_MODULE_SIG_ALL=y）。

## E3: fs-compare T5 の反復測定（引き継ぎタスク 11）

- phase2 で base 平均から 10% 以上ずれた 18 variant + 対応 base 6 構成（E1,F1,F3,B2,I1,L1）の T5 を各 5 回反復（約 120 run、`-j 4`、数時間）。
- `~/fscmp/MSD-Linux` を origin/main の harness に揃え（TSV は P110/P118 修正済みの main 版）、plan TSV は T5 行だけ生成する。build tree `output-fscmp` は phase2 と同じものを使い回す（warm、defconfig 世代が古いことは記録に明記）。
- 1 回値だった値を中央値・範囲へ置き換え、比率の解釈を更新する。

## E4: T4-sync で idle 書き込みが出た variant の再測定（同じ matrix に同梱）

- phase2 で idle write が非 zero だった 12 variant（P044,P070-P073,P097,P113,P120-P122,P140,P141）の T4-sync を各 3 回反復し、idle 書き込みが一過性か継続的かを確認（§10 評価の材料）。

## 対象外と理由

- P085：guest の btrfs-progs 6.10 が `--enable-simple-quota` を持たない（tool 更新が必要）。記録だけ残す。
- P087/T6：T6 harness が `--mixed` に非対応（harness 改修が必要）。計画として残す。
- OpenSSL 削減・dm-verity・SSH client 比較・RAUC/SWUpdate：設計・判断を伴うため本セッションでは手つかず。
- mount 方針・`/data` 暗号化：利用者の判断が先。

## 記録と成果物

- 各実験は `docs/experiments/2026-11-15-*.md` + 同名 `.csv`（experiment-record スキルの手順）。
- 生 log・image 写しの hash は `data/fs-compare-experiments` branch へ保存して照合してから VM 側を整理。
- `docs/experiments/README.md` の一覧へ行を追加し、PR は stacked PR として作る（merge は利用者）。
- 日本語文書は yomiyasu lint を通す。QEMU の値と実機の値は分けて書く。
