#!/usr/bin/env python3
# Vectorized FEC parity checker for verityfmt images (numpy).
import sys
import numpy as np

def mod255(x):
    while x >= 255:
        x = (x >> 8) + (x & 255)
    return x

def make_rs(nroots=8, nn=255, gfpoly=0x11d):
    alpha_to = np.zeros(nn + 1, dtype=np.int64)
    index_of = np.zeros(nn + 1, dtype=np.int64)
    index_of[0] = nn
    alpha_to[nn - 1] = 0
    sr = 1
    for i in range(nn):
        index_of[sr] = i
        alpha_to[i] = sr
        sr <<= 1
        if sr & 256:
            sr ^= gfpoly
        sr &= nn
    assert sr == 1
    genpoly = np.zeros(nroots + 1, dtype=np.int64)
    genpoly[0] = 1
    root = 0
    for i in range(nroots):
        genpoly[i + 1] = 1
        for j in range(i, 0, -1):
            if genpoly[j] != 0:
                genpoly[j] = genpoly[j - 1] ^ alpha_to[mod255(index_of[genpoly[j]] + root)]
            else:
                genpoly[j] = genpoly[j - 1]
        genpoly[0] = alpha_to[mod255(index_of[genpoly[0]] + root)]
        root += 1
    genpoly_log = np.array([index_of[g] for g in genpoly], dtype=np.int64)
    return alpha_to, index_of, genpoly_log, nroots, nn

def encode_cols(rs, data):
    """data: uint8 array shape (rsn, cols). Returns parity array (roots, cols)."""
    alpha_to, index_of, genpoly_log, nroots, nn = rs
    rsn, cols = data.shape
    parity = np.zeros((nroots, cols), dtype=np.uint8)
    for i in range(rsn):
        feedback = index_of[data[i].astype(np.int64) ^ parity[0].astype(np.int64)]
        live = feedback != nn  # columns where data^p0 != 0
        fb = feedback.copy()
        fb[~live] = 0
        for j in range(1, nroots):
            g = genpoly_log[nroots - j]
            if g != nn:
                parity[j] ^= alpha_to[(fb + g) % 255][live].astype(np.uint8) if False else np.where(live, alpha_to[(fb + g) % 255].astype(np.uint8), 0)
        parity[:-1] = parity[1:]
        parity[nroots - 1] = np.where(live, alpha_to[(fb + genpoly_log[0]) % 255].astype(np.uint8), 0)
    return parity

def main(path, data_blocks, hash_start, hash_area, fec_area_off, bs=4096, roots=8):
    rsn = 255 - roots
    covered = data_blocks + hash_area
    rounds = (covered + rsn - 1) // rsn
    rs = make_rs(nroots=roots)
    print(f"covered={covered} rounds={rounds} rsn={rsn}", flush=True)
    img = np.memmap(path, dtype=np.uint8, mode='r')
    bad_total = 0
    for n in range(rounds):
        inputs = np.zeros((rsn, bs), dtype=np.uint8)
        for i in range(rsn):
            blk = i * rounds + n
            if blk >= covered:
                continue
            if blk < data_blocks:
                inputs[i] = img[blk * bs:(blk + 1) * bs]
            else:
                hb = hash_start + blk - data_blocks
                inputs[i] = img[hb * bs:(hb + 1) * bs]
        par = encode_cols(rs, inputs)
        stored = img[fec_area_off + n * roots * bs:fec_area_off + (n + 1) * roots * bs]
        stored = np.asarray(stored).reshape(bs, roots).T
        bad = int(np.count_nonzero(np.any(par != stored, axis=0)))
        bad_total += bad
        if bad:
            print(f"round {n}: {bad}/{bs} bad columns", flush=True)
    print(f"total bad cols={bad_total} / {rounds * bs}")
    if bad_total == 0:
        print("ALL PARITY OK")

if __name__ == "__main__":
    main(sys.argv[1], int(sys.argv[2]), int(sys.argv[3]), int(sys.argv[4]), int(sys.argv[5]))
