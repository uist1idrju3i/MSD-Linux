#!/usr/bin/env python3
# FEC parity checker for verityfmt images.
# Re-encodes every (round, byte-column) RS(255,247) codeword and compares with
# stored parity. Uses the identical LFSR encoder + genpoly as verityfmt.c
# (GF poly 0x11d, fcr=0, prim=1, nroots configurable).
import sys

def mod255(x, nn=255):
    while x >= nn:
        x = (x >> 8) + (x & nn)
    return x

def make_rs(gfpoly=0x11d, fcr=0, prim=1, nroots=8, nn=255):
    alpha_to = [0] * nn
    index_of = [0] * (nn + 1)
    index_of[0] = nn
    alpha_to[nn - 1] = 0
    sr = 1
    for i in range(nn):
        index_of[sr] = i
        alpha_to[i] = sr
        sr <<= 1
        if sr & 256:
            sr ^= gfpoly
        sr &= nn
    assert sr == 1
    genpoly = [0] * (nroots + 1)
    genpoly[0] = 1
    root = fcr * prim
    for i in range(nroots):
        genpoly[i + 1] = 1
        for j in range(i, 0, -1):
            if genpoly[j] != 0:
                genpoly[j] = genpoly[j - 1] ^ alpha_to[mod255(index_of[genpoly[j]] + root)]
            else:
                genpoly[j] = genpoly[j - 1]
        genpoly[0] = alpha_to[mod255(index_of[genpoly[0]] + root)]
        root += prim
    genpoly_log = [index_of[g] for g in genpoly]
    return alpha_to, index_of, genpoly_log, nroots, nn

def encode(rs, data):
    alpha_to, index_of, genpoly, nroots, nn = rs
    parity = [0] * nroots
    for d in data:
        feedback = index_of[d ^ parity[0]]
        if feedback != nn:  # nn marker for zero
            for j in range(1, nroots):
                g = genpoly[nroots - j]
                if g != nn:
                    parity[j] ^= alpha_to[mod255(feedback + g)]
        parity[:-1] = parity[1:]
        if feedback != nn:
            parity[nroots - 1] = alpha_to[mod255(feedback + genpoly[0])]
        else:
            parity[nroots - 1] = 0
    return bytes(parity)

def main(path, data_blocks, hash_start, hash_area, fec_area_off, bs=4096, roots=8):
    rsn = 255 - roots
    covered = data_blocks + hash_area
    rounds = (covered + rsn - 1) // rsn
    rs = make_rs(nroots=roots)
    print(f"covered={covered} rounds={rounds} rsn={rsn}")
    img = open(path, 'rb')
    total_cols = 0
    bad_cols = 0
    bad_rounds = {}
    for n in range(rounds):
        inputs = []
        for i in range(rsn):
            blk = i * rounds + n
            if blk >= covered:
                inputs.append(bytes(bs))
            elif blk < data_blocks:
                img.seek(blk * bs)
                inputs.append(img.read(bs))
            else:
                hb = hash_start + blk - data_blocks
                img.seek(hb * bs)
                inputs.append(img.read(bs))
        img.seek(fec_area_off + n * roots * bs)
        stored = img.read(roots * bs)
        first_bad = None
        cnt = 0
        for b in range(bs):
            msg = bytes(inputs[i][b] for i in range(rsn))
            if encode(rs, msg) != stored[b * roots:(b + 1) * roots]:
                cnt += 1
                if first_bad is None:
                    first_bad = b
        total_cols += bs
        bad_cols += cnt
        if cnt:
            bad_rounds[n] = cnt
            print(f"round {n}: {cnt} bad columns (first byte {first_bad})")
    print(f"total cols={total_cols} bad={bad_cols}")
    if not bad_rounds:
        print("ALL PARITY OK")

if __name__ == "__main__":
    main(sys.argv[1], int(sys.argv[2]), int(sys.argv[3]), int(sys.argv[4]), int(sys.argv[5]))
