/* Verify stored FEC parity in a verityfmt image by re-encoding.
 * Same RS codec as verityfmt.c. Usage:
 *   check_fec <img> <data_blocks> <hash_start> <hash_area> <fec_area_off> [bs] [roots]
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

struct rs_codec { uint8_t alpha_to[256], index_of[256], genpoly[64]; int nn, nroots; };

static int mod255(const struct rs_codec *rs, int x){ while(x>=rs->nn){x-=rs->nn;x=(x>>8)+(x&rs->nn);} return x; }

static int rs_init(struct rs_codec *rs,int gfpoly,int fcr,int prim,int nroots){
	int i,j,sr,root;
	rs->nn=255; rs->nroots=nroots;
	memset(rs->index_of,0,sizeof(rs->index_of));
	rs->index_of[0]=255; rs->alpha_to[255]=0; sr=1;
	for(i=0;i<rs->nn;i++){rs->index_of[sr]=i;rs->alpha_to[i]=sr;sr<<=1;if(sr&256)sr^=gfpoly;sr&=rs->nn;}
	if(sr!=1)return -1;
	rs->genpoly[0]=1;
	for(i=0,root=fcr*prim;i<nroots;i++,root+=prim){
		rs->genpoly[i+1]=1;
		for(j=i;j>0;j--){
			if(rs->genpoly[j]!=0)rs->genpoly[j]=rs->genpoly[j-1]^rs->alpha_to[mod255(rs,rs->index_of[rs->genpoly[j]]+root)];
			else rs->genpoly[j]=rs->genpoly[j-1];
		}
		rs->genpoly[0]=rs->alpha_to[mod255(rs,rs->index_of[rs->genpoly[0]]+root)];
	}
	for(i=0;i<=nroots;i++)rs->genpoly[i]=rs->index_of[rs->genpoly[i]];
	return 0;
}

static void rs_encode(const struct rs_codec *rs,const uint8_t *data,uint8_t *parity){
	int i,j; uint8_t feedback; int rsn=rs->nn-rs->nroots;
	memset(parity,0,rs->nroots);
	for(i=0;i<rsn;i++){
		feedback=rs->index_of[data[i]^parity[0]];
		if(feedback!=255){
			for(j=1;j<rs->nroots;j++)
				parity[j]^=rs->alpha_to[mod255(rs,feedback+rs->genpoly[rs->nroots-j])];
		}
		memmove(&parity[0],&parity[1],rs->nroots-1);
		parity[rs->nroots-1]=feedback!=255?rs->alpha_to[mod255(rs,feedback+rs->genpoly[0])]:0;
	}
}

int main(int argc,char**argv){
	if(argc<6){fprintf(stderr,"usage: check_fec img data_blocks hash_start hash_area fec_area_off [bs] [roots]\n");return 2;}
	const char*path=argv[1];
	uint64_t data_blocks=strtoull(argv[2],0,0),hash_start=strtoull(argv[3],0,0),
	         hash_area=strtoull(argv[4],0,0),fec_area=strtoull(argv[5],0,0);
	uint64_t bs=argc>6?strtoull(argv[6],0,0):4096;
	int roots=argc>7?atoi(argv[7]):8;
	int rsn=255-roots;
	uint64_t covered=data_blocks+hash_area, rounds=(covered+rsn-1)/rsn;
	fprintf(stderr,"covered=%llu rounds=%llu rsn=%d\n",(unsigned long long)covered,(unsigned long long)rounds,rsn);
	struct rs_codec rs; if(rs_init(&rs,0x11d,0,1,roots)){fprintf(stderr,"rs_init\n");return 1;}
	FILE*f=fopen(path,"rb"); if(!f){perror(path);return 1;}
	uint8_t*bufs=malloc((size_t)rsn*bs),*par=malloc((size_t)roots*bs),*calc=malloc(roots);
	uint64_t bad=0;
	for(uint64_t n=0;n<rounds;n++){
		for(int i=0;i<rsn;i++){
			uint64_t blk=(uint64_t)i*rounds+n; uint8_t*dst=bufs+(size_t)i*bs;
			if(blk>=covered){memset(dst,0,bs);}
			else if(blk<data_blocks){fseeko(f,(off_t)(blk*bs),SEEK_SET);if(fread(dst,1,bs,f)!=bs)goto eof;}
			else{uint64_t hb=hash_start+blk-data_blocks;fseeko(f,(off_t)(hb*bs),SEEK_SET);if(fread(dst,1,bs,f)!=bs)goto eof;}
		}
		fseeko(f,(off_t)(fec_area+n*roots*bs),SEEK_SET);
		if(fread(par,1,(size_t)roots*bs,f)!=(size_t)roots*bs)goto eof;
		for(uint64_t b=0;b<bs;b++){
			uint8_t msg[247]; for(int i=0;i<rsn;i++)msg[i]=bufs[(size_t)i*bs+b];
			rs_encode(&rs,msg,calc);
			if(memcmp(calc,par+b*roots,roots)){ if(bad<20)fprintf(stderr,"round %llu byte %llu mismatch\n",(unsigned long long)n,(unsigned long long)b); bad++; }
		}
	}
	fprintf(stderr,"bad=%llu / %llu\n",(unsigned long long)bad,(unsigned long long)(rounds*bs));
	if(bad==0)printf("ALL PARITY OK\n");
	fclose(f);return bad?1:0;
eof: fprintf(stderr,"unexpected EOF\n");return 1;
}
